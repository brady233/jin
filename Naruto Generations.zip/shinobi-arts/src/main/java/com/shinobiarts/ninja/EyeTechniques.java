package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.block.AmaterasuFireBlock;
import com.shinobiarts.jutsu.JutsuEffects;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.registry.ModBlocks;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.registry.ModEffects;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * The techniques of an active Sharingan, on the Jutsu 1 / Jutsu 2 / Jutsu 3 keys (R / Y / U by default):
 * <ul>
 *   <li>Jutsu 1, Genjutsu with 1-3 tomoe. With the Mangekyou: Amaterasu (Itachi, Sasuke and Eternal Mangekyou),
 *       black flames on the spot you look at and on the creature there; Sneak + Jutsu 1 puts out every black flame
 *       around you. No cooldown by default.</li>
 *   <li>Jutsu 2, Kamui (Obito's Mangekyou): held. While the key is down you're intangible: you fly through blocks,
 *       and attacks, projectiles and jutsu pass through you. Letting go brings you back (to the nearest open spot if
 *       you're inside a wall). Sneak + Jutsu 2 is the Kamui snap: it tears at the creature you look at for half its
 *       max health.</li>
 *   <li>Jutsu 3, Genjutsu with the Mangekyou: traps the creature you look at in an illusion.</li>
 * </ul>
 * Each costs a share of max chakra and has its own cooldown (config section {@code eyeTechniques}).
 * The client uses {@link #technique} too, to draw the HUD's technique slots.
 */
public final class EyeTechniques {
    private static final DustParticleOptions BLACK_FLAME = new DustParticleOptions(new Vector3f(0.06f, 0.0f, 0.08f), 2.0f);
    private static final DustParticleOptions KAMUI_DUST = new DustParticleOptions(new Vector3f(0.12f, 0.05f, 0.2f), 1.3f);
    private static final DustParticleOptions TSUKUYOMI_DUST = new DustParticleOptions(new Vector3f(0.7f, 0.0f, 0.04f), 1.7f);

    public enum Technique {
        AMATERASU("amaterasu", 1),
        AMATERASU_OUT("amaterasu_out", 1),
        KAMUI("kamui", 2),
        KAMUI_SNAP("kamui_snap", 2),
        KAMUI_WARP("kamui_warp", 1),
        KAMUI_ABDUCT("kamui_abduct", 1),
        TSUKUYOMI("tsukuyomi", 2),
        BLAZE("blaze", 2),
        BLAZE_WALL("blaze_wall", 2),
        GENJUTSU("genjutsu", 3),
        // Byakugan
        PALMS_64("palms_64", 1),
        AIR_PALM("air_palm", 2),
        ALL_SEEING("all_seeing", 3);

        private final String id;
        private final int key;

        Technique(String id, int key) {
            this.id = id;
            this.key = key;
        }

        public String id() {
            return id;
        }

        /** Which Jutsu key (1-3) uses it. */
        public int key() {
            return key;
        }

        /** A Byakugan technique (needs the Byakugan on), as opposed to a Sharingan one. */
        public boolean byakugan() {
            return this == PALMS_64 || this == AIR_PALM || this == ALL_SEEING;
        }

        public String cooldownId() {
            return "eye_" + id;
        }

        public MutableComponent displayName() {
            return Component.translatable("eye.shinobiarts." + id);
        }

        /** The HUD icon: textures/gui/eye_<id>.png (64 x 64). */
        public ResourceLocation icon() {
            return ShinobiArts.id("textures/gui/eye_" + id + ".png");
        }

        /** Share of max chakra it costs. */
        public float cost() {
            return switch (this) {
                case AMATERASU -> Config.f(Config.AMATERASU_COST);
                case AMATERASU_OUT -> 0f;
                case KAMUI -> Config.f(Config.KAMUI_COST);
                case KAMUI_SNAP -> Config.f(Config.KAMUI_SNAP_COST);
                case KAMUI_WARP -> Config.f(Config.KAMUI_WARP_COST);
                case KAMUI_ABDUCT -> Config.f(Config.KAMUI_ABDUCT_COST);
                case TSUKUYOMI -> Config.f(Config.TSUKUYOMI_COST);
                case BLAZE -> Config.f(Config.BLAZE_COST);
                case BLAZE_WALL -> Config.f(Config.BLAZE_WALL_COST);
                case GENJUTSU -> Config.f(Config.GENJUTSU_COST);
                case PALMS_64 -> Config.f(Config.PALMS_COST);
                case AIR_PALM -> Config.f(Config.AIR_PALM_COST);
                case ALL_SEEING -> Config.f(Config.ALL_SEEING_COST);
            };
        }

        /** Cooldown in ticks (scaled by cooldownMultiplier). Kamui's starts when the intangibility ends. */
        public long cooldownTicks() {
            int seconds = switch (this) {
                case AMATERASU -> Config.i(Config.AMATERASU_COOLDOWN);
                case AMATERASU_OUT -> 0;
                case KAMUI -> Config.i(Config.KAMUI_COOLDOWN);
                case KAMUI_SNAP -> Config.i(Config.KAMUI_SNAP_COOLDOWN);
                case KAMUI_WARP -> Config.i(Config.KAMUI_WARP_COOLDOWN);
                case KAMUI_ABDUCT -> Config.i(Config.KAMUI_ABDUCT_COOLDOWN);
                case TSUKUYOMI -> Config.i(Config.TSUKUYOMI_COOLDOWN);
                case BLAZE -> Config.i(Config.BLAZE_COOLDOWN);
                case BLAZE_WALL -> Config.i(Config.BLAZE_WALL_COOLDOWN);
                case GENJUTSU -> Config.i(Config.GENJUTSU_COOLDOWN);
                case PALMS_64 -> Config.i(Config.PALMS_COOLDOWN);
                case AIR_PALM -> Config.i(Config.AIR_PALM_COOLDOWN);
                case ALL_SEEING -> Config.i(Config.ALL_SEEING_COOLDOWN);
            };
            return Math.max(0L, Math.round(seconds * 20 * Config.d(Config.COOLDOWN_MULTIPLIER)));
        }
    }

    private EyeTechniques() {}

    /**
     * Whether the Jutsu keys use the Byakugan's techniques: while the Byakugan is on, or when it's the only eye the
     * player has.
     */
    public static boolean usesByakugan(NinjaData d) {
        return d.getActiveDojutsu() == Dojutsu.BYAKUGAN
                || (d.getSharinganStage() <= 0 && d.availableDojutsu().contains(Dojutsu.BYAKUGAN));
    }

    /** The technique a Jutsu key (1-3) gives this player's eyes, or null. Doesn't check whether the eyes are on. */
    @Nullable
    public static Technique technique(NinjaData d, int key, boolean sneaking) {
        if (usesByakugan(d)) return byakuganTechnique(key);
        return technique(d.activeSharinganStage(), d.getMangekyouDesign(), key, sneaking);
    }

    /** The Byakugan's techniques: 64 Palms, Air Palm, All-Seeing Eye. */
    @Nullable
    public static Technique byakuganTechnique(int key) {
        return switch (key) {
            case 1 -> Technique.PALMS_64;
            case 2 -> Technique.AIR_PALM;
            case 3 -> Technique.ALL_SEEING;
            default -> null;
        };
    }

    /** Whether the eyes a technique needs are switched on. */
    public static boolean eyesOn(NinjaData d, Technique t) {
        return t.byakugan() ? d.getActiveDojutsu() == Dojutsu.BYAKUGAN : d.isSharinganActive();
    }

    /** The technique a Jutsu key (1-3) gives a Sharingan of this stage and pattern, or null. */
    @Nullable
    public static Technique technique(int stage, MangekyouDesign design, int key, boolean sneaking) {
        if (stage <= 0) return null;
        boolean mangekyou = stage == Dojutsu.MANGEKYOU;
        return switch (key) {
            // 1-3 tomoe: Genjutsu. Mangekyou with Amaterasu: the black flames (Sneak: put them out)
            case 1 -> !mangekyou ? Technique.GENJUTSU
                    : design.hasAmaterasu() ? (sneaking ? Technique.AMATERASU_OUT : Technique.AMATERASU)
                    : design.hasKamui() ? Technique.KAMUI_WARP : null;
            case 2 -> {
                if (!mangekyou) yield null;
                if (design.hasKamui()) yield sneaking ? Technique.KAMUI_SNAP : Technique.KAMUI;
                if (design.hasTsukuyomi()) yield Technique.TSUKUYOMI;
                if (design.hasBlaze()) yield sneaking ? Technique.BLAZE_WALL : Technique.BLAZE;
                yield null;
            }
            case 3 -> mangekyou ? Technique.GENJUTSU : null;
            default -> null;
        };
    }

    // ================================================================ describing the eyes (item tooltips)

    /**
     * How a key shows up in tooltips, by id: jutsu_1, jutsu_2, jutsu_3, dojutsu, sneak. The client replaces this with
     * the player's own key bindings (ClientSetup); tooltips are only ever built on the client.
     */
    public static java.util.function.Function<String, Component> keyName =
            id -> Component.translatable(id.equals("sneak") ? "key.sneak" : "key.shinobiarts." + id);

    private static MutableComponent key(String... ids) {
        MutableComponent out = Component.literal("[");
        for (int i = 0; i < ids.length; i++) {
            if (i > 0) out.append(" + ");
            out.append(keyName.apply(ids[i]));
        }
        return out.append("]").withStyle(ChatFormatting.GOLD);
    }

    private static MutableComponent line(String id, Object... args) {
        return Component.literal(" ").append(Component.translatable("tooltip.shinobiarts.eye_ability." + id, args)).withStyle(ChatFormatting.GRAY);
    }

    /**
     * Lists what a pair of eyes can do and which key does it, for the eye items' tooltips: a Sharingan of this stage
     * and pattern, or the Byakugan.
     */
    public static void describe(int stage, MangekyouDesign design, boolean byakugan, java.util.List<Component> out) {
        out.add(Component.translatable("tooltip.shinobiarts.eye_abilities").withStyle(ChatFormatting.DARK_AQUA));
        if (byakugan) {
            out.add(line("palms_64", key("jutsu_1")));
            out.add(line("air_palm", key("jutsu_2")));
            out.add(line("all_seeing", key("jutsu_3")));
            out.add(line("byakugan_sight"));
            out.add(line("gentle_fist"));
        } else if (stage > 0) {
            boolean mangekyou = stage == Dojutsu.MANGEKYOU;
            if (technique(stage, design, 1, false) == Technique.AMATERASU) {
                out.add(line("amaterasu", key("jutsu_1")));
                out.add(line("amaterasu_out", key("sneak", "jutsu_1")));
            } else if (technique(stage, design, 1, false) == Technique.KAMUI_WARP) {
                out.add(line("kamui_warp", key("jutsu_1")));
            }
            Technique two = technique(stage, design, 2, false);
            if (two == Technique.KAMUI) {
                out.add(line("kamui", key("jutsu_2")));
                out.add(line("kamui_snap", key("sneak", "jutsu_2")));
            } else if (two == Technique.TSUKUYOMI) {
                out.add(line("tsukuyomi", key("jutsu_2")));
            } else if (two == Technique.BLAZE) {
                out.add(line("blaze", key("jutsu_2")));
                out.add(line("blaze_wall", key("sneak", "jutsu_2")));
            }
            out.add(line("genjutsu", key(mangekyou ? "jutsu_3" : "jutsu_1")));
            if (mangekyou) {
                out.add(line("susanoo", key("susanoo")));
                out.add(line("susanoo_release", key("sneak", "susanoo")));
            }
            out.add(line("sharingan_passive"));
            if (mangekyou) out.add(line(design.strainsEyes() ? "strain" : "eternal"));
            else out.add(line("next_stage"));
        }
        out.add(Component.translatable(byakugan ? "tooltip.shinobiarts.eye_ability.toggle_byakugan" : "tooltip.shinobiarts.eye_ability.toggle",
                key(byakugan ? "byakugan" : "dojutsu")).withStyle(ChatFormatting.DARK_GRAY));
    }

    // ================================================================ using a technique

    /** A Jutsu key was pressed. Everything is checked here; the client only says which key. */
    public static void use(ServerPlayer p, int key, boolean sneaking) {
        NinjaData d = NinjaData.get(p);
        if (d == null || !d.isInitialized() || !p.isAlive() || p.isSpectator()) return;
        long now = p.level().getGameTime();
        Technique t = technique(d, key, sneaking || p.isShiftKeyDown());
        if (t == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.no_eye_technique", key).withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (t == Technique.KAMUI && d.getIntangibleUntil() != 0) return; // already held
        if (d.getIntangibleUntil() != 0 && t == Technique.KAMUI_SNAP) return; // nothing to tear at from inside Kamui
        if (!Afflictions.canAct(p)) return;
        if (!eyesOn(d, t)) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.eyes_off", t.displayName()).withStyle(ChatFormatting.RED), true);
            return;
        }
        long remaining = d.cooldownRemaining(t.cooldownId(), now);
        if (remaining > 0) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.cooldown", t.displayName(),
                    String.format("%.1f", remaining / 20.0f)).withStyle(ChatFormatting.GRAY), true);
            return;
        }
        boolean creative = p.getAbilities().instabuild;
        float cost = d.maxChakra() * t.cost();
        if (!creative && d.getChakra() < cost) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_chakra",
                    (int) d.getChakra(), (int) Math.ceil(cost)).withStyle(ChatFormatting.RED), true);
            return;
        }
        boolean done = switch (t) {
            case AMATERASU -> amaterasu(p, d);
            case AMATERASU_OUT -> {
                if (extinguish(p) == 0) {
                    p.displayClientMessage(Component.translatable("message.shinobiarts.amaterasu_none").withStyle(ChatFormatting.GRAY), true);
                }
                yield true;
            }
            case KAMUI -> startKamui(p, d);
            case KAMUI_SNAP -> kamuiSnap(p, d);
            case KAMUI_WARP -> KamuiDimension.warp(p, d);
            case KAMUI_ABDUCT -> KamuiDimension.warp(p, d);
            case TSUKUYOMI -> tsukuyomi(p, d);
            case BLAZE -> blaze(p, d);
            case BLAZE_WALL -> blazeWall(p, d);
            case GENJUTSU -> genjutsu(p, d);
            case PALMS_64 -> palms64(p, d);
            case AIR_PALM -> airPalm(p, d);
            case ALL_SEEING -> allSeeing(p, d);
        };
        if (!done) return;
        com.shinobiarts.registry.ModSounds.eye(p, t.id());
        if (!creative) d.consumeChakra(cost);
        if (t != Technique.KAMUI) d.setCooldown(t.cooldownId(), now + t.cooldownTicks());
        p.displayClientMessage(t.displayName().withStyle(t.byakugan() ? ChatFormatting.LIGHT_PURPLE : ChatFormatting.RED), true);
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
    }

    private static void noTarget(ServerPlayer p) {
        p.displayClientMessage(Component.translatable("message.shinobiarts.no_target").withStyle(ChatFormatting.GRAY), true);
    }

    /** Using the Mangekyou's techniques hurts the eyes (not the Eternal Mangekyou's). */
    private static void strainEyes(ServerPlayer p, NinjaData d) {
        if (!d.getMangekyouDesign().strainsEyes()) return;
        p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0));
        p.hurt(p.damageSources().magic(), 2.0f);
    }

    // ---------------------------------------------------------------- Amaterasu

    /** Black flames on the block you look at (and on the creature you look at, if any). */
    private static boolean amaterasu(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        double range = Config.i(Config.AMATERASU_RANGE);
        Vec3 eye = p.getEyePosition();
        Vec3 end = eye.add(p.getLookAngle().scale(range));
        BlockHitResult blockHit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        LivingEntity target = JutsuUtil.rayTarget(p, range);

        BlockPos center;
        if (target != null) {
            int amplifier = Math.min(3, d.stat(Stat.GENJUTSU) / 25);
            target.addEffect(new MobEffectInstance(ModEffects.AMATERASU.get(), Math.round(200 * d.genjutsuMultiplier()), amplifier), p);
            target.hurt(ModDamage.jutsu(level, p, p), JutsuUtil.dmg(4f));
            level.sendParticles(BLACK_FLAME, target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(), 80,
                    target.getBbWidth() * 0.6, target.getBbHeight() * 0.4, target.getBbWidth() * 0.6, 0.0);
            center = target.blockPosition();
        } else if (blockHit.getType() == HitResult.Type.BLOCK) {
            Direction face = blockHit.getDirection();
            center = blockHit.getBlockPos().relative(face);
        } else {
            center = BlockPos.containing(JutsuUtil.aimAnywhere(p, 30));     // nothing there: it still burns, in mid-air
        }

        int placed = placeFlames(level, p, center);
        if (placed == 0 && target == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.amaterasu_no_room").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        Vec3 c = Vec3.atBottomCenterOf(center);
        level.sendParticles(BLACK_FLAME, c.x, c.y + 0.5, c.z, 60, 1.0, 0.5, 1.0, 0.0);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, c.x, c.y + 0.5, c.z, 20, 0.8, 0.4, 0.8, 0.02);
        JutsuUtil.sound(level, c, SoundEvents.FIRECHARGE_USE, 1.2f, 0.4f);
        JutsuUtil.sound(level, c, SoundEvents.BLAZE_SHOOT, 0.8f, 0.5f);
        strainEyes(p, d);
        return true;
    }

    /** Lights black flames on and around a spot (a small patch, each on solid ground). Returns how many were lit. */
    private static int placeFlames(ServerLevel level, ServerPlayer p, BlockPos center) {
        int placed = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                boolean middle = dx == 0 && dz == 0;
                if (!middle && level.getRandom().nextFloat() < 0.35f) continue; // ragged edges
                for (int dy = 1; dy >= -4; dy--) {
                    BlockPos pos = center.offset(dx, dy, dz);
                    if (AmaterasuFireBlock.canBurnAt(level, pos) && level.mayInteract(p, pos)) {
                        level.setBlock(pos, ModBlocks.AMATERASU_FIRE.get().defaultBlockState(), 3);
                        placed++;
                        break;
                    }
                }
            }
        }
        return placed;
    }

    /** Sneak + Jutsu 1 with Amaterasu's Mangekyou on: every black flame within the radius goes out, ground and creatures. */
    public static int extinguish(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        int r = Config.i(Config.AMATERASU_EXTINGUISH_RADIUS);
        BlockPos c = p.blockPosition();
        int count = 0;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (dx * dx + dz * dz > r * r) continue;
                for (int dy = -r; dy <= r; dy++) {
                    pos.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (level.getBlockState(pos).is(ModBlocks.AMATERASU_FIRE.get())) {
                        AmaterasuFireBlock.putOut(level, pos.immutable());
                        count++;
                    }
                }
            }
        }
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c).inflate(r))) {
            double hx = e.getX() - p.getX(), hz = e.getZ() - p.getZ();
            if (hx * hx + hz * hz <= r * r && e.hasEffect(ModEffects.AMATERASU.get())) {
                e.removeEffect(ModEffects.AMATERASU.get());
                level.sendParticles(ParticleTypes.LARGE_SMOKE, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 8, 0.3, 0.3, 0.3, 0.01);
                count++;
            }
        }
        if (count > 0) {
            JutsuUtil.sound(level, p.position(), SoundEvents.FIRE_EXTINGUISH, 1.0f, 0.6f);
            p.displayClientMessage(Component.translatable("message.shinobiarts.amaterasu_extinguished").withStyle(ChatFormatting.DARK_GRAY), true);
        }
        return count;
    }

    // ---------------------------------------------------------------- Kamui

    /** Kamui starts when Jutsu 2 goes down and lasts while it's held (see {@link #release}). */
    private static boolean startKamui(ServerPlayer p, NinjaData d) {
        long now = p.level().getGameTime();
        d.setIntangibleUntil(now + Config.i(Config.KAMUI_SECONDS) * 20L);
        // Flying, so you can pass through floors and ceilings without falling through the world.
        if (!p.getAbilities().mayfly) {
            p.getAbilities().mayfly = true;
            d.setKamuiGaveFlight(true);
        }
        p.getAbilities().flying = true;
        p.onUpdateAbilities();
        p.noPhysics = true;
        swirl(p.serverLevel(), p.position().add(0, 1, 0), 1.2, 40);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ENDERMAN_TELEPORT, 1.0f, 0.5f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.kamui_on").withStyle(ChatFormatting.DARK_PURPLE), true);
        return true;
    }

    /** A Jutsu key came up. Letting go of Jutsu 2 ends Kamui. */
    public static void release(ServerPlayer p, int key) {
        NinjaData d = NinjaData.get(p);
        if (d != null && key == Technique.KAMUI.key() && d.getIntangibleUntil() != 0) endIntangible(p, d);
    }

    /**
     * Ends Kamui (key let go, time up, out of chakra, eyes off): takes back the flight it gave, moves you out of any
     * wall you're inside, and starts its cooldown.
     */
    public static void endIntangible(ServerPlayer p, NinjaData d) {
        long now = p.level().getGameTime();
        d.setIntangibleUntil(0);
        p.noPhysics = p.isSpectator();
        restoreFlight(p, d);
        d.setCooldown(Technique.KAMUI.cooldownId(), now + Technique.KAMUI.cooldownTicks());
        Vec3 safe = openSpot(p);
        if (safe != null && safe.distanceToSqr(p.position()) > 1e-4) JutsuUtil.teleport(p, safe);
        p.resetFallDistance();
        d.setFallProtectUntil(now + 60);
        swirl(p.serverLevel(), p.position().add(0, 1, 0), 0.8, 25);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ENDERMAN_TELEPORT, 0.8f, 0.8f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.kamui_off").withStyle(ChatFormatting.GRAY), true);
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
    }

    /** Takes away the flight Kamui gave (not flight the player had anyway, like in creative). */
    private static void restoreFlight(ServerPlayer p, NinjaData d) {
        if (!d.kamuiGaveFlight()) return;
        d.setKamuiGaveFlight(false);
        if (!p.isCreative() && !p.isSpectator()) {
            p.getAbilities().mayfly = false;
            p.getAbilities().flying = false;
            p.onUpdateAbilities();
        }
    }

    /**
     * Where the player can stand after Kamui: where they are if that's open, else the nearest open spot (searching up
     * to 8 blocks around, closest first, a little in favour of going up), else the top of the column.
     */
    @Nullable
    private static Vec3 openSpot(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        net.minecraft.world.entity.EntityDimensions dims = p.getDimensions(net.minecraft.world.entity.Pose.STANDING);
        if (fitsAt(level, p, p.position(), dims)) return p.position();
        BlockPos base = p.blockPosition();
        Vec3 best = null;
        double bestScore = Double.MAX_VALUE;
        for (int r = 1; r <= 8 && best == null; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz))) != r) continue;
                        Vec3 c = Vec3.atBottomCenterOf(base.offset(dx, dy, dz));
                        if (!fitsAt(level, p, c, dims)) continue;
                        double score = c.distanceToSqr(p.position()) - (dy > 0 ? 0.5 : 0);
                        if (score < bestScore) {
                            bestScore = score;
                            best = c;
                        }
                    }
                }
            }
        }
        if (best != null) return best;
        int top = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING, base.getX(), base.getZ());
        return new Vec3(base.getX() + 0.5, top, base.getZ() + 0.5);
    }

    private static boolean fitsAt(ServerLevel level, ServerPlayer p, Vec3 feet, net.minecraft.world.entity.EntityDimensions dims) {
        AABB box = dims.makeBoundingBox(feet).deflate(1.0E-5);
        return level.noCollision(p, box)
                && !level.getFluidState(BlockPos.containing(feet)).is(net.minecraft.tags.FluidTags.LAVA)
                && !level.getFluidState(BlockPos.containing(feet).above()).is(net.minecraft.tags.FluidTags.LAVA);
    }

    /** Tears at the creature you look at: half its max health (capped for bosses), ignoring armor. */
    private static boolean kamuiSnap(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, Config.i(Config.KAMUI_SNAP_RANGE));
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        float damage = target.getMaxHealth() * Config.f(Config.KAMUI_SNAP_DAMAGE);
        if (target.getType().is(net.minecraftforge.common.Tags.EntityTypes.BOSSES)) {
            damage = Math.min(damage, Config.f(Config.KAMUI_SNAP_BOSS_MAX));
        }
        Vec3 c = target.getBoundingBox().getCenter();
        swirl(level, c, Math.max(0.8, target.getBbWidth()), 60);
        level.sendParticles(ParticleTypes.PORTAL, c.x, c.y, c.z, 60, 0.4, 0.4, 0.4, 0.6);
        target.hurt(ModDamage.kamui(level, p), damage);
        JutsuUtil.sound(level, c, SoundEvents.ENDERMAN_TELEPORT, 1.2f, 0.4f);
        JutsuUtil.sound(level, c, SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.5f);
        strainEyes(p, d);
        return true;
    }

    /** A dark spiral, Kamui's warp. */
    private static void swirl(ServerLevel level, Vec3 c, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double t = i / (double) points;
            double a = t * Math.PI * 6;
            double r = radius * (1 - t);
            level.sendParticles(KAMUI_DUST, c.x + Math.cos(a) * r, c.y + (t - 0.5) * 0.6, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    // ---------------------------------------------------------------- Tsukuyomi (Itachi)

    /**
     * Traps the creature or player you look at in Tsukuyomi: they're frozen (can't move, attack or use jutsu) and
     * players lose part of their chakra. When the illusion ends, the days of torture land at once: a share of their
     * max health (capped for bosses), then nausea and slowness. A Sharingan that's on sees through half of it.
     */
    private static boolean tsukuyomi(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, Config.i(Config.TSUKUYOMI_RANGE));
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        int ticks = Math.max(10, Math.round((float) Config.d(Config.TSUKUYOMI_SECONDS) * 20f * d.genjutsuMultiplier()));
        if (target instanceof ServerPlayer victim) {
            NinjaData vd = NinjaData.get(victim);
            if (vd != null) {
                if (vd.isSharinganActive()) ticks /= 2;
                vd.consumeChakra(vd.getChakra() * Config.f(Config.TSUKUYOMI_CHAKRA_DRAIN));
            }
            victim.displayClientMessage(Component.translatable("message.shinobiarts.caught_in_tsukuyomi", p.getDisplayName())
                    .withStyle(ChatFormatting.DARK_RED), true);
        }
        Afflictions.stun(target, ticks, Afflictions.STUN_TSUKUYOMI);
        Vec3 e = target.getEyePosition();
        JutsuUtil.line(level, TSUKUYOMI_DUST, p.getEyePosition(), e, 0.6, 1, 0.04);
        level.sendParticles(TSUKUYOMI_DUST, e.x, e.y, e.z, 40, 0.4, 0.4, 0.4, 0.0);
        level.sendParticles(ParticleTypes.SQUID_INK, e.x, e.y, e.z, 12, 0.3, 0.3, 0.3, 0.01);
        JutsuUtil.sound(level, target.position(), SoundEvents.ELDER_GUARDIAN_CURSE, 0.9f, 0.5f);
        JutsuUtil.sound(level, target.position(), SoundEvents.WITHER_AMBIENT, 0.4f, 0.4f);

        float damage = target.getMaxHealth() * Config.f(Config.TSUKUYOMI_DAMAGE);
        if (target.getType().is(net.minecraftforge.common.Tags.EntityTypes.BOSSES)) damage = Math.min(damage, Config.f(Config.TSUKUYOMI_BOSS_MAX));
        float hit = damage;
        com.shinobiarts.util.Scheduler.later(ticks, () -> {
            if (!target.isAlive() || target.isRemoved()) return;
            target.hurt(ModDamage.tsukuyomi(target.level(), p), hit);
            target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0));
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
            if (target.level() instanceof ServerLevel l) {
                Vec3 c = target.getEyePosition();
                l.sendParticles(TSUKUYOMI_DUST, c.x, c.y, c.z, 30, 0.5, 0.5, 0.5, 0.0);
            }
        });
        strainEyes(p, d);
        return true;
    }

    // ---------------------------------------------------------------- Blaze Release (Sasuke, Eternal)

    /** The ground height to stand a flame on near {@code at} (searching a few blocks up and down), or null. */
    @Nullable
    private static Double groundY(ServerLevel level, Vec3 at, double fromY) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int dy = 3; dy >= -6; dy--) {
            pos.set(net.minecraft.util.Mth.floor(at.x), net.minecraft.util.Mth.floor(fromY) + dy, net.minecraft.util.Mth.floor(at.z));
            if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) continue;
            BlockPos below = pos.below();
            if (!level.getBlockState(below).getCollisionShape(level, below).isEmpty()) return (double) pos.getY();
        }
        return null;
    }

    private static Vec3 flatLook(ServerPlayer p) {
        Vec3 look = p.getLookAngle();
        Vec3 dir = new Vec3(look.x, 0, look.z);
        return dir.lengthSqr() < 1e-4 ? new Vec3(-Math.sin(Math.toRadians(p.getYRot())), 0, Math.cos(Math.toRadians(p.getYRot()))) : dir.normalize();
    }

    /** Spikes of black flame burst out of the ground in a line toward where you look; everything they hit catches Amaterasu. */
    private static boolean blaze(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 dir = flatLook(p);
        Vec3 start = p.position();
        double fromY = p.getY();
        int range = Config.i(Config.BLAZE_RANGE);
        float damage = JutsuUtil.dmg(Config.f(Config.BLAZE_DAMAGE));
        int burn = Math.round(200 * d.genjutsuMultiplier());
        int amplifier = Math.min(3, d.stat(Stat.GENJUTSU) / 25);
        java.util.Set<Integer> hit = new java.util.HashSet<>();
        com.shinobiarts.util.Scheduler.repeat(0, 1, Math.max(1, range - 1), i -> {
            Vec3 at = start.add(dir.scale(i + 2));
            Double ground = groundY(level, at, fromY);
            if (ground == null) return;
            Vec3 base = new Vec3(at.x, ground, at.z);
            for (int j = 0; j < 9; j++) {                     // a spike: wide at the root, sharp at the top
                double spread = 0.3 * (1 - j / 9.0);
                level.sendParticles(BLACK_FLAME, base.x, base.y + j * 0.32, base.z, 3, spread, 0.08, spread, 0.0);
            }
            level.sendParticles(ParticleTypes.LARGE_SMOKE, base.x, base.y + 1.2, base.z, 2, 0.2, 0.4, 0.2, 0.01);
            if (i % 3 == 0) JutsuUtil.sound(level, base, SoundEvents.BLAZE_SHOOT, 0.7f, 0.5f);
            AABB box = new AABB(base, base).inflate(1.2, 0, 1.2).expandTowards(0, 3, 0);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, cand -> JutsuUtil.isValidTarget(p, cand))) {
                if (!hit.add(e.getId())) continue;
                e.hurt(ModDamage.jutsu(level, p, p), damage);
                e.addEffect(new MobEffectInstance(ModEffects.AMATERASU.get(), burn, amplifier), p);
                JutsuUtil.push(e, new Vec3(0, 0.45, 0));
            }
        });
        JutsuUtil.sound(level, p.position(), SoundEvents.FIRECHARGE_USE, 1.0f, 0.4f);
        strainEyes(p, d);
        return true;
    }

    /**
     * A wall of black flames across your path, a few blocks ahead. Anything that walks into it burns with Amaterasu
     * and is thrown back, and arrows and jutsu thrown at you burn up in it.
     */
    private static boolean blazeWall(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 dir = flatLook(p);
        Vec3 side = new Vec3(-dir.z, 0, dir.x);
        Vec3 center = p.position().add(dir.scale(3));
        Double ground = groundY(level, center, p.getY());
        double baseY = ground != null ? ground : p.getY();
        double half = Config.i(Config.BLAZE_WALL_WIDTH) / 2.0;
        int steps = Config.i(Config.BLAZE_WALL_SECONDS) * 4;
        float damage = JutsuUtil.dmg(4f);
        int burn = Math.round(140 * d.genjutsuMultiplier());
        java.util.Map<Integer, Long> lastHit = new java.util.HashMap<>();
        AABB box = new AABB(center.add(side.scale(half)), center.add(side.scale(-half))).inflate(1.0, 0, 1.0)
                .setMinY(baseY).setMaxY(baseY + 3.2);
        com.shinobiarts.util.Scheduler.repeat(0, 5, steps, i -> {
            for (double w = -half; w <= half + 1e-3; w += 1.0) {
                Vec3 col = center.add(side.scale(w));
                level.sendParticles(BLACK_FLAME, col.x, baseY + 1.5, col.z, 4, 0.3, 0.9, 0.3, 0.0);
            }
            if (i % 4 == 0) {
                level.sendParticles(ParticleTypes.LARGE_SMOKE, center.x, baseY + 2.6, center.z, 4, half * 0.5, 0.3, half * 0.5, 0.01);
                JutsuUtil.sound(level, center, SoundEvents.FIRE_AMBIENT, 1.0f, 0.5f);
            }
            long now = level.getGameTime();
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, cand -> JutsuUtil.isValidTarget(p, cand))) {
                Vec3 rel = e.position().subtract(center);
                if (Math.abs(rel.dot(side)) > half + 0.5 || Math.abs(rel.dot(dir)) > 0.9) continue;
                if (lastHit.getOrDefault(e.getId(), -100L) > now - 20) continue;
                lastHit.put(e.getId(), now);
                e.hurt(ModDamage.jutsu(level, p, p), damage);
                e.addEffect(new MobEffectInstance(ModEffects.AMATERASU.get(), burn, 0), p);
                double away = Math.signum(rel.dot(dir));
                JutsuUtil.push(e, dir.scale((away == 0 ? 1 : away) * 0.7).add(0, 0.3, 0));
            }
            for (net.minecraft.world.entity.projectile.Projectile pr : level.getEntitiesOfClass(net.minecraft.world.entity.projectile.Projectile.class, box)) {
                Vec3 rel = pr.position().subtract(center);
                if (pr.getOwner() == p || Math.abs(rel.dot(side)) > half + 0.5 || Math.abs(rel.dot(dir)) > 1.0) continue;
                level.sendParticles(ParticleTypes.LARGE_SMOKE, pr.getX(), pr.getY(), pr.getZ(), 4, 0.1, 0.1, 0.1, 0.01);
                pr.discard();
            }
        });
        JutsuUtil.sound(level, center, SoundEvents.BLAZE_SHOOT, 1.0f, 0.4f);
        strainEyes(p, d);
        return true;
    }

    // ---------------------------------------------------------------- Genjutsu

    /** An illusion on the creature you look at: longer and farther with each stage; the Mangekyou also roots them. */
    /**
     * Genjutsu (Itachi's crow clone): the target looks at you and sees you burst into a flock of crows that scatter
     * and fly away; that is all they see. You are already behind them. They stand caught in the illusion for a moment
     * (longer with each tomoe, the Mangekyou and the Genjutsu stat), with no other sign of it.
     */
    private static boolean genjutsu(ServerPlayer p, NinjaData d) {
        int stage = d.activeSharinganStage();
        LivingEntity target = JutsuUtil.rayTarget(p, 10 + 4 * stage);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        Vec3 was = p.position();
        // behind them: opposite the way they face, turned to look at their back
        float yaw = target.getYRot() * net.minecraft.util.Mth.DEG_TO_RAD;
        Vec3 facing = new Vec3(-net.minecraft.util.Mth.sin(yaw), 0, net.minecraft.util.Mth.cos(yaw));
        Vec3 spot = target.position().subtract(facing.scale(target.getBbWidth() / 2 + 1.1));
        Vec3 safe = JutsuUtil.findSafe(p, spot);
        if (safe == null) safe = JutsuUtil.findSafe(p, target.position().subtract(facing.scale(0.6)));
        if (safe != null) {
            Vec3 to = target.getEyePosition().subtract(safe.add(0, p.getEyeHeight(), 0));
            float ty = (float) Math.toDegrees(Math.atan2(-to.x, to.z));
            float tp = (float) -Math.toDegrees(Math.atan2(to.y, Math.sqrt(to.x * to.x + to.z * to.z)));
            p.stopRiding();
            p.connection.teleport(safe.x, safe.y, safe.z, ty, tp);
            p.setYHeadRot(ty);
            p.resetFallDistance();
        }
        // where you stood, you come apart into crows that fly off away from them
        Vec3 away = was.subtract(target.position());
        away = new Vec3(away.x, 0, away.z);
        away = away.lengthSqr() < 1e-4 ? facing : away.normalize();
        Vec3 c = was.add(0, p.getBbHeight() * 0.55, 0);
        com.shinobiarts.fx.Fx.line(level, com.shinobiarts.fx.Fx.Visual.CROWS, c, c.add(away), 1f, 45);
        JutsuUtil.sound(level, c, SoundEvents.PARROT_FLY, 1.2f, 0.6f);
        JutsuUtil.sound(level, c, SoundEvents.ENDER_DRAGON_FLAP, 0.5f, 2.0f);
        JutsuUtil.sound(level, c, SoundEvents.PHANTOM_FLAP, 0.9f, 1.3f);
        // caught: frozen for a moment, no other effects
        int duration = Math.round((20 + 10 * stage) * d.genjutsuMultiplier());
        if (stage == Dojutsu.MANGEKYOU) duration += 20;
        Afflictions.stun(target, duration, Afflictions.STUN_NONE);
        if (target instanceof net.minecraft.world.entity.Mob mob) {
            mob.getNavigation().stop();
            mob.setTarget(null);
        }
        if (stage == Dojutsu.MANGEKYOU) strainEyes(p, d);
        return true;
    }

    // ================================================================ Byakugan

    /**
     * Eight Trigrams 64 Palms: you dash to the creature or player in front of you and strike their chakra points in a
     * rapid flurry. Their chakra points are sealed (no jutsu, eye techniques or Susanoo for a while) and players lose
     * part of their chakra; creatures are slowed and weakened.
     */
    /** How many palms each flurry of Eight Trigrams 64 Palms lands, and the tick (from the start) it lands on. */
    private static final int[] PALM_COUNTS = {2, 4, 8, 16, 32, 64};
    private static final int[] PALM_TICKS = {10, 19, 27, 34, 40, 46};

    /**
     * Eight Trigrams 64 Palms: the user steps in front of the target and the Eight Trigrams field spreads under them
     * both. Then the palms land in doublings, each called out (two, four, eight, sixteen, thirty-two, sixty-four),
     * every one closing a chakra point, the target held in place; the sixty-fourth drives them back. Their chakra is
     * sealed for a while afterwards.
     */
    private static boolean palms64(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, Config.i(Config.PALMS_RANGE));
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        Vec3 away = p.position().subtract(target.position());
        away = new Vec3(away.x, 0, away.z);
        away = away.lengthSqr() < 1e-4 ? flatLook(p).scale(-1) : away.normalize();
        Vec3 spot = target.position().add(away.scale(target.getBbWidth() / 2 + 0.9));
        Vec3 safe = JutsuUtil.findSafe(p, spot);
        if (safe != null) {
            Vec3 to = target.getEyePosition().subtract(safe.add(0, p.getEyeHeight(), 0));
            float yaw = (float) Math.toDegrees(Math.atan2(-to.x, to.z));
            float pitch = (float) -Math.toDegrees(Math.atan2(to.y, Math.sqrt(to.x * to.x + to.z * to.z)));
            p.stopRiding();
            p.connection.teleport(safe.x, safe.y, safe.z, yaw, pitch);
        }
        int total = PALM_TICKS[PALM_TICKS.length - 1] + 14;
        Vec3 mid = target.position().add(p.position()).scale(0.5);
        com.shinobiarts.fx.Fx.at(level, com.shinobiarts.fx.Fx.Visual.TRIGRAM_FIELD, mid, 3.6f, total);
        JutsuUtil.sound(level, p.position(), SoundEvents.ILLUSIONER_PREPARE_BLINDNESS, 0.8f, 1.4f);
        JutsuUtil.sound(level, p.position(), SoundEvents.BEACON_ACTIVATE, 0.8f, 1.5f);
        shout(p, target, Component.translatable("message.shinobiarts.palms_field"));
        // both held in the stance while it lasts
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, total, 6, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, total - 10, 3, false, false));
        float damage = JutsuUtil.dmg(Config.f(Config.PALMS_DAMAGE));
        for (int w = 0; w < PALM_COUNTS.length; w++) {
            int count = PALM_COUNTS[w];
            boolean last = w == PALM_COUNTS.length - 1;
            int next = last ? 8 : PALM_TICKS[w + 1] - PALM_TICKS[w];
            com.shinobiarts.util.Scheduler.later(PALM_TICKS[w], () -> {
                if (!target.isAlive() || !p.isAlive() || target.level() != p.level()) return;
                com.shinobiarts.fx.Fx.send(level, com.shinobiarts.fx.Fx.Visual.PALM_FLURRY, target.position(), target.position(),
                        p.getId(), target.getId(), count, Math.max(6, next));
                shout(p, target, Component.translatable("message.shinobiarts.palms_count", count));
                target.setDeltaMovement(0, Math.min(0, target.getDeltaMovement().y), 0);
                target.hurtMarked = true;
                int hits = Math.min(count, 8);
                for (int h = 0; h < hits; h++) {
                    int hh = h;
                    com.shinobiarts.util.Scheduler.later(Math.max(1, next * h / hits), () -> {
                        if (!target.isAlive() || !p.isAlive()) return;
                        target.invulnerableTime = 0;
                        target.hurt(ModDamage.jutsu(level, p, p), damage * count / 126f / hits);
                        p.swing(hh % 2 == 0 ? net.minecraft.world.InteractionHand.MAIN_HAND : net.minecraft.world.InteractionHand.OFF_HAND, true);
                    });
                }
                JutsuUtil.sound(level, target.position(), SoundEvents.PLAYER_ATTACK_STRONG, 0.8f, 0.9f + count / 64f * 0.8f);
                JutsuUtil.sound(level, target.position(), SoundEvents.PLAYER_ATTACK_CRIT, 0.6f, 1.0f + count / 64f);
                if (last) com.shinobiarts.util.Scheduler.later(next, () -> palmsFinish(p, target));
            });
        }
        return true;
    }

    /** The 64th palm: the target is driven back and its chakra points stay sealed. */
    private static void palmsFinish(ServerPlayer p, LivingEntity target) {
        if (!target.isAlive() || !p.isAlive()) return;
        if (target instanceof ServerPlayer victim) {               // sixty-four points closed: the network is damaged for sure
            ChakraPoints.strike(victim, p, 1.0, true);
            ChakraPoints.strike(victim, p, Config.d(Config.TENKETSU_CHANCE_HIGH), true);
        }
        ServerLevel level = p.serverLevel();
        Vec3 dir = target.position().subtract(p.position());
        dir = new Vec3(dir.x, 0, dir.z);
        dir = dir.lengthSqr() < 1e-4 ? flatLook(p) : dir.normalize();
        Vec3 c = target.getBoundingBox().getCenter();
        com.shinobiarts.fx.Fx.line(level, com.shinobiarts.fx.Fx.Visual.PALM_FINISH, c.subtract(dir.scale(target.getBbWidth() * 0.5)), c.add(dir), 1f, 14);
        target.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        JutsuUtil.push(target, dir.scale(1.9).add(0, 0.45, 0));
        p.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        JutsuUtil.sound(level, c, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.2f, 0.7f);
        JutsuUtil.sound(level, c, SoundEvents.GENERIC_EXPLODE, 0.4f, 1.6f);
        int seal = Config.i(Config.PALMS_SEAL_SECONDS) * 20;
        if (target instanceof ServerPlayer victim) {
            NinjaData vd = NinjaData.get(victim);
            if (vd != null) vd.consumeChakra(vd.getChakra() * Config.f(Config.PALMS_CHAKRA_DRAIN));
            victim.displayClientMessage(Component.translatable("message.shinobiarts.points_sealed_by", p.getDisplayName())
                    .withStyle(ChatFormatting.DARK_PURPLE), true);
        } else {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, seal, 1));
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, seal, 1));
        }
        Afflictions.seal(target, seal);
    }

    /** A call-out over the user's and the target's hotbars. */
    private static void shout(ServerPlayer p, LivingEntity target, MutableComponent text) {
        MutableComponent t = text.withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD);
        p.displayClientMessage(t, true);
        if (target instanceof ServerPlayer victim) victim.displayClientMessage(t, true);
    }

    /**
     * Air Palm: a thrust of the palm compresses the air in front of it into a pressure wave that flies out and
     * slams into whatever it reaches, throwing it back.
     */
    private static boolean airPalm(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        double range = Config.i(Config.AIR_PALM_RANGE);
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity target = JutsuUtil.rayTarget(p, range);
        Vec3 end;
        if (target != null) {
            end = target.getBoundingBox().getCenter();
        } else {
            BlockHitResult hit = JutsuUtil.rayBlock(p, range);
            end = hit.getType() == HitResult.Type.MISS ? eye.add(look.scale(range)) : hit.getLocation();
        }
        Vec3 from = eye.add(look.scale(0.8)).subtract(0, 0.3, 0);
        double length = end.distanceTo(from);
        int travel = Math.max(2, (int) Math.ceil(length / 2.4));
        com.shinobiarts.fx.Fx.line(level, com.shinobiarts.fx.Fx.Visual.AIR_PALM, from, end, 1f, travel + 8);
        p.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        JutsuUtil.sound(level, p.position(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.0f, 0.6f);
        JutsuUtil.sound(level, p.position(), SoundEvents.ENDER_DRAGON_FLAP, 0.6f, 1.6f);
        Vec3 push = look.normalize().scale(2.0).add(0, 0.45, 0);
        float damage = JutsuUtil.dmg(Config.f(Config.AIR_PALM_DAMAGE));
        com.shinobiarts.util.Scheduler.later(travel, () -> {
            JutsuUtil.sound(level, end, SoundEvents.GENERIC_EXPLODE, 0.5f, 1.7f);
            if (target == null || !target.isAlive() || !p.isAlive()) return;
            target.hurt(ModDamage.jutsu(level, p, p), damage);
            JutsuUtil.push(target, push);
        });
        return true;
    }

    private static boolean allSeeing(ServerPlayer p, NinjaData d) {
        long now = p.level().getGameTime();
        d.setAllSeeingUntil(now + Config.i(Config.ALL_SEEING_SECONDS) * 20L);
        ServerLevel level = p.serverLevel();
        com.shinobiarts.fx.Fx.on(level, com.shinobiarts.fx.Fx.Visual.BYAKUGAN_SIGHT, p, null, Config.i(Config.ALL_SEEING_RANGE), 30);
        JutsuUtil.sound(level, p.position(), SoundEvents.BEACON_POWER_SELECT, 0.7f, 1.6f);
        revealAround(p);
        return true;
    }

    /** Makes everything living within the All-Seeing Eye's range glow for a moment. */
    private static void revealAround(ServerPlayer p) {
        double r = Config.i(Config.ALL_SEEING_RANGE);
        for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r), cand -> cand != p && cand.isAlive())) {
            if (e.distanceToSqr(p) <= r * r) e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 30, 0, false, false, false));
        }
    }

    // ================================================================ every tick

    /** Sneak-to-extinguish, Kamui's upkeep and timer, and keeping other players' view of this player up to date. */
    public static void tick(ServerPlayer p, NinjaData d, long now) {
        DojutsuSlot.sync(p);
        if (p.tickCount % 20 == 0) DojutsuSlot.removeStrayEyes(p);
        d.setWasCrouching(p.isShiftKeyDown());   // (black flames now go out only with Sneak + Jutsu 1)

        if (d.getIntangibleUntil() != 0) {
            if (now >= d.getIntangibleUntil() || !d.isMangekyouActive() || !d.getMangekyouDesign().hasKamui()) {
                endIntangible(p, d);
            } else {
                if (p.tickCount % 20 == 0 && !p.getAbilities().instabuild) {
                    float drain = Config.f(Config.KAMUI_DRAIN);
                    if (d.getChakra() < drain) {
                        endIntangible(p, d);
                        return;
                    }
                    d.consumeChakra(drain);
                }
                // stay flying (double-tapping jump would otherwise drop you through the floor)
                if (!p.getAbilities().flying || !p.getAbilities().mayfly) {
                    if (!p.getAbilities().mayfly) {
                        p.getAbilities().mayfly = true;
                        d.setKamuiGaveFlight(true);
                    }
                    p.getAbilities().flying = true;
                    p.onUpdateAbilities();
                }
                if (p.tickCount % 3 == 0) {
                    double a = p.tickCount * 0.5;
                    p.serverLevel().sendParticles(KAMUI_DUST, p.getX() + Math.cos(a) * 0.7, p.getY() + 0.2 + (p.tickCount % 18) / 10.0,
                            p.getZ() + Math.sin(a) * 0.7, 2, 0.05, 0.05, 0.05, 0.0);
                }
                p.resetFallDistance();
            }
        } else if (d.kamuiGaveFlight()) {
            restoreFlight(p, d); // e.g. Kamui was cut short by logging out
        }
        if (d.getAllSeeingUntil() != 0) {
            if (d.getAllSeeingUntil() <= now || d.getActiveDojutsu() != Dojutsu.BYAKUGAN) {
                d.setAllSeeingUntil(0);
                ModNetwork.sync(p);
            } else if (p.tickCount % 10 == 0) {
                revealAround(p);
            }
        }
        if (p.tickCount % 5 == 0) SharinganManager.updateLook(p);
    }

    /** Tells a player what their Mangekyou's pattern lets them do. */
    public static void explain(ServerPlayer p, NinjaData d) {
        p.sendSystemMessage(Component.translatable("message.shinobiarts.mangekyou_techniques." + d.getMangekyouDesign().id())
                .withStyle(ChatFormatting.GOLD));
    }
}
