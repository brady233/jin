package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Chakra Control, switched on and off with its own key (N by default):
 * <ul>
 *   <li>Tree (wall) walking: walk into a wall while looking at it (or up) to walk up it. Sneak to cling in place;
 *       otherwise you slide down slowly, without fall damage.</li>
 *   <li>Ceiling walking: jump or climb into a ceiling and you hang from it upside down; walk around as usual and sneak
 *       to drop off ("ceilingWalking" in the config).</li>
 *   <li>Water walking: you stand and walk on water. Sneak to sink in and swim; Ninja Jump works from the water too.</li>
 * </ul>
 * The local player's movement is client-side in Minecraft, so {@link #move} runs on the client (from a LivingTickEvent,
 * before the player moves that tick); the server drains chakra while it's in use and stops fall damage.
 */
public final class ChakraControl {
    /** Below this much chakra Chakra Control stops working until it regenerates. */
    public static final float MIN_CHAKRA = 1f;

    private ChakraControl() {}

    /** The Chakra Control key. Anyone can use it; it only costs chakra while climbing or standing on water. */
    public static void toggle(ServerPlayer p, NinjaData d) {
        boolean on = !d.isChakraControl();
        d.setChakraControl(on);
        p.displayClientMessage(Component.translatable(on ? "message.shinobiarts.chakra_control_on" : "message.shinobiarts.chakra_control_off")
                .withStyle(on ? ChatFormatting.AQUA : ChatFormatting.GRAY), true);
        if (on) {
            p.serverLevel().sendParticles(ParticleTypes.GLOW, p.getX(), p.getY() + 0.1, p.getZ(), 12, 0.3, 0.05, 0.3, 0.01);
            JutsuUtil.sound(p.level(), p.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 0.8f, 1.4f);
        }
        ModNetwork.sync(p);
    }

    /** Whether the player can use it right now (on, enough chakra, not flying, riding or a spectator). */
    public static boolean usable(Player p, NinjaData d) {
        return d.isChakraControl() && (d.getChakra() >= MIN_CHAKRA || p.getAbilities().instabuild)
                && !p.getAbilities().flying && !p.isPassenger() && !p.isSpectator() && !p.isFallFlying();
    }

    /**
     * Client side, before the local player moves this tick: walking up walls, hanging from ceilings and standing on
     * water. Returns true if Chakra Control did something this tick.
     */
    public static boolean move(Player p, NinjaData d) {
        if (!usable(p, d)) {
            d.setOnCeiling(false);
            return false;
        }
        Vec3 v = p.getDeltaMovement();

        // ceiling walking: once you're pressed against a ceiling (jumping or climbing into it, or looking up at it) you
        // hang there until you sneak or walk out from under it
        if (Config.b(Config.CHAKRA_CONTROL_CEILINGS) && !p.onGround() && !p.isInWater() && !p.isInLava() && !p.isShiftKeyDown()
                && touchingCeiling(p) && (d.isOnCeiling() || v.y > 0 || p.getXRot() < -30f)) {
            d.setOnCeiling(true);
            p.setDeltaMovement(v.x, 0.1, v.z);       // pressed up against it (gravity can't pull you off)
            p.resetFallDistance();
            return true;
        }
        d.setOnCeiling(false);

        // tree walking: walking into a wall while looking at it (or looking up) walks you up it
        boolean touching = p.horizontalCollision || (p.zza > 0 && touchingWall(p));
        if (touching && !p.isInWater() && !p.isInLava()) {
            double y;
            if (p.getXRot() < -15f || lookingAtWall(p)) {
                y = Config.d(Config.CHAKRA_CONTROL_CLIMB_SPEED);      // looking at the wall (or up): walk up
            } else if (p.isShiftKeyDown()) {
                y = Math.max(v.y, 0.0);                                // sneaking: cling
            } else {
                y = Math.max(v.y, -0.15);                              // otherwise slide down slowly
            }
            p.setDeltaMovement(v.x, y, v.z);
            p.resetFallDistance();
            return true;
        }

        // water walking (sneak to go into the water)
        if (!p.isShiftKeyDown()) {
            double surface = waterSurface(p.level(), p.position());
            if (!Double.isNaN(surface) && p.getY() >= surface - 0.6 && p.getY() + Math.min(v.y, 0) <= surface + 0.01 && v.y <= 0.01) {
                if (p.getY() < surface) p.setPos(p.getX(), surface, p.getZ()); // pop back up onto the surface
                p.setDeltaMovement(v.x, 0, v.z);
                p.setOnGround(true);
                p.resetFallDistance();
                return true;
            }
        }
        return false;
    }

    /** A solid block right above the player's head. */
    public static boolean touchingCeiling(Player p) {
        return !p.level().noCollision(p, p.getBoundingBox().move(0, 0.12, 0))
                && p.level().noCollision(p, p.getBoundingBox());
    }

    /** A solid block right beside the player (within a few hundredths of a block). */
    public static boolean touchingWall(Player p) {
        AABB box = p.getBoundingBox();
        return !p.level().noCollision(p, box.inflate(0.06, -0.1, 0.06));
    }

    /** True if the player is looking at the side of a block close in front of them (the wall they want to walk up). */
    public static boolean lookingAtWall(Player p) {
        Vec3 eye = p.getEyePosition();
        Vec3 end = eye.add(p.getLookAngle().scale(2.0));
        BlockHitResult hit = p.level().clip(new net.minecraft.world.level.ClipContext(eye, end,
                net.minecraft.world.level.ClipContext.Block.COLLIDER, net.minecraft.world.level.ClipContext.Fluid.NONE, p));
        if (hit.getType() != HitResult.Type.BLOCK || hit.getDirection().getAxis().isVertical()) return false;
        // the block must be the one you're up against, not one further off
        return p.getBoundingBox().inflate(0.3, 0, 0.3).intersects(new AABB(hit.getBlockPos()));
    }

    /** Standing on the water, or just under its surface (sinking in while sneaking): Ninja Jump still works from there. */
    public static boolean nearWaterSurface(Player p) {
        double surface = waterSurface(p.level(), p.position().add(0, 0.5, 0));
        return !Double.isNaN(surface) && p.getY() <= surface + 0.1 && p.getY() >= surface - 1.0;
    }

    /**
     * The height of the water surface under (or around) these feet, or NaN if there's no open water there:
     * the top water block in the column at the feet or the block below them, with air (no water) above it.
     */
    public static double waterSurface(Level level, Vec3 feet) {
        BlockPos at = BlockPos.containing(feet.x, feet.y - 0.01, feet.z);
        for (BlockPos pos : new BlockPos[]{at.above(), at, at.below()}) {
            FluidState fluid = level.getFluidState(pos);
            if (fluid.is(FluidTags.WATER) && !level.getFluidState(pos.above()).is(FluidTags.WATER)
                    && level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty()) {
                return pos.getY() + fluid.getHeight(level, pos);
            }
        }
        return Double.NaN;
    }

    /** True if the player is standing on (or right at) a water surface. */
    public static boolean onWater(Player p) {
        double surface = waterSurface(p.level(), p.position());
        return !Double.isNaN(surface) && Math.abs(p.getY() - surface) < 0.08;
    }

    /** A ceiling close above the player (a little slack, since the server sees the client's position a tick late). */
    public static boolean ceilingNear(Player p) {
        return !p.level().noCollision(p, p.getBoundingBox().move(0, 0.45, 0));
    }

    /**
     * The client hangs from ceilings itself (it moves its own player), and says when it starts and stops: the server
     * takes its word if there really is a ceiling just above, and everyone else then sees the player upside down.
     */
    public static void clientSaysCeiling(ServerPlayer p, NinjaData d, boolean on) {
        boolean ceiling = on && usable(p, d) && Config.b(Config.CHAKRA_CONTROL_CEILINGS) && ceilingNear(p);
        if (ceiling != d.isOnCeiling()) {
            d.setOnCeiling(ceiling);
            SharinganManager.updateLook(p);
        }
    }

    /** Server side, every tick: chakra drain while climbing, on a ceiling or on water, and no fall damage from them. */
    public static void serverTick(ServerPlayer p, NinjaData d) {
        if (!usable(p, d)) {
            if (d.isOnCeiling()) {
                d.setOnCeiling(false);
                SharinganManager.updateLook(p);
            }
            return;
        }
        // the client says when it starts and stops hanging (clientSaysCeiling); here it's only checked as a fallback:
        // turned on if the server sees it too, turned off once there's clearly no ceiling above any more
        boolean seen = Config.b(Config.CHAKRA_CONTROL_CEILINGS) && !p.onGround() && !p.isInWater() && !p.isShiftKeyDown()
                && touchingCeiling(p);
        boolean ceiling = seen || (d.isOnCeiling() && Config.b(Config.CHAKRA_CONTROL_CEILINGS) && !p.onGround() && !p.isInWater()
                && ceilingNear(p));
        if (ceiling != d.isOnCeiling()) {
            d.setOnCeiling(ceiling);
            SharinganManager.updateLook(p);                // everyone else sees you hanging upside down
        }
        boolean climbing = p.horizontalCollision && !p.onGround() && !p.isInWater();
        boolean water = !p.isShiftKeyDown() && onWater(p);
        if (!climbing && !water && !ceiling) return;
        p.resetFallDistance();
        if (!p.getAbilities().instabuild) d.consumeChakra(Config.f(Config.CHAKRA_CONTROL_DRAIN) / 20f);
        if (water && p.tickCount % 8 == 0) { // ripples under your feet
            p.serverLevel().sendParticles(ParticleTypes.SPLASH, p.getX(), p.getY() + 0.05, p.getZ(), 4, 0.25, 0.0, 0.25, 0.0);
        }
    }

    /** Landing on water with Chakra Control on doesn't hurt, nor does sliding down a wall. */
    public static boolean cushionsFall(ServerPlayer p, NinjaData d) {
        if (!usable(p, d)) return false;
        return p.horizontalCollision || !Double.isNaN(waterSurface(p.level(), p.position()));
    }
}
