package com.shinobiarts.ninja;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;

/**
 * The chakra natures (five elements + Yin Yang), plus NONE which is the general "Ninjutsu" release
 * (non-elemental and clan techniques), plus the five clan releases (Wood, Ice, Magnet, Bone, Sealing): each belongs to
 * one clan, is given to its members once their clan is locked in, and only they can learn its jutsu.
 * Each value is also a release the player can equip.
 * To add a nature: add it here, add its icon to textures/nature/, its release item model and its lang entries.
 * Ids are saved with each player, so never rename one.
 */
public enum ChakraNature {
    FIRE("fire", ChatFormatting.RED, 0xD9301C),
    WATER("water", ChatFormatting.BLUE, 0x2A8CF0),
    WIND("wind", ChatFormatting.GREEN, 0x22B97A),
    LIGHTNING("lightning", ChatFormatting.YELLOW, 0xDCCB12),
    EARTH("earth", ChatFormatting.GOLD, 0x8E5A24),
    YIN_YANG("yin_yang", ChatFormatting.DARK_PURPLE, 0x7A4FB0),
    NONE("ninjutsu", ChatFormatting.LIGHT_PURPLE, 0xB07CF0),

    // clan releases (kekkei genkai): only the clan named here can use them
    WOOD("wood", ChatFormatting.GREEN, 0x70A83C, "senju"),
    ICE("ice", ChatFormatting.AQUA, 0x96DEF6, "yuki"),
    MAGNET("magnet", ChatFormatting.GRAY, 0x6E7386, "kazekage"),
    BONE("bone", ChatFormatting.WHITE, 0xE8E0C6, "kaguya"),
    SEALING("sealing", ChatFormatting.RED, 0xCC3C5C, "uzumaki"),
    SHADOW("shadow", ChatFormatting.DARK_GREEN, 0x3E5A34, "nara"),
    MIND("mind", ChatFormatting.LIGHT_PURPLE, 0xC890E8, "yamanaka"),
    GENTLE_FIST("gentle_fist", ChatFormatting.WHITE, 0xDCD8F0, "hyuga"),
    SPACE_TIME("space_time", ChatFormatting.YELLOW, 0xF2D24A, "namikaze"),
    // every other clan's own release (one signature technique each)
    UCHIHA_CLAN("uchiha_clan", ChatFormatting.DARK_RED, 0xC03028, "uchiha"),
    SARUTOBI_CLAN("sarutobi_clan", ChatFormatting.GOLD, 0xB5562A, "sarutobi"),
    HATAKE_CLAN("hatake_clan", ChatFormatting.WHITE, 0xE8E8F0, "hatake"),
    INUZUKA_CLAN("inuzuka_clan", ChatFormatting.RED, 0xB84C3C, "inuzuka"),
    AKIMICHI_CLAN("akimichi_clan", ChatFormatting.GOLD, 0xE8A838, "akimichi"),
    ABURAME_CLAN("aburame_clan", ChatFormatting.DARK_GRAY, 0x5A5F52, "aburame"),
    KURAMA_CLAN("kurama_clan", ChatFormatting.DARK_PURPLE, 0x8A4CC0, "kurama"),
    CHINOIKE_CLAN("chinoike_clan", ChatFormatting.DARK_RED, 0x8E1420, "chinoike"),
    HOZUKI_CLAN("hozuki_clan", ChatFormatting.AQUA, 0x7CC8E8, "hozuki"),
    HOSHIGAKI_CLAN("hoshigaki_clan", ChatFormatting.DARK_BLUE, 0x2C5AA8, "hoshigaki"),
    KARATACHI_CLAN("karatachi_clan", ChatFormatting.BLUE, 0x4C7CD8, "karatachi"),
    FUMA_CLAN("fuma_clan", ChatFormatting.DARK_AQUA, 0x3C8E8E, "fuma"),
    SHIMURA_CLAN("shimura_clan", ChatFormatting.DARK_GRAY, 0x6E7276, "shimura"),
    IBURI_CLAN("iburi_clan", ChatFormatting.GRAY, 0x9A9A9E, "iburi"),
    TSUCHIGUMO_CLAN("tsuchigumo_clan", ChatFormatting.DARK_GREEN, 0x4A6E3C, "tsuchigumo"),
    FUNATO_CLAN("funato_clan", ChatFormatting.DARK_AQUA, 0x3C6E8E, "funato"),
    TAKETORI_CLAN("taketori_clan", ChatFormatting.GREEN, 0x7CB850, "taketori"),
    SHIROGANE_CLAN("shirogane_clan", ChatFormatting.GRAY, 0xC0C4CC, "shirogane"),
    YOTSUKI_CLAN("yotsuki_clan", ChatFormatting.YELLOW, 0xE8D848, "yotsuki"),
    KAMIZURU_CLAN("kamizuru_clan", ChatFormatting.GOLD, 0xD8A828, "kamizuru"),
    OTSUTSUKI_CLAN("otsutsuki_clan", ChatFormatting.LIGHT_PURPLE, 0xD8C8F0, "otsutsuki"),

    // Medical Release: everyone's, like Ninjutsu (its jutsu are learned from scrolls)
    MEDICAL("medical", ChatFormatting.GREEN, 0x5ED68C),

    // Rinnegan: the Rinnegan's own release (Shinra Tensei, Bansho Ten'in, Chibaku Tensei); only its wielders have it
    RINNEGAN("rinnegan", ChatFormatting.LIGHT_PURPLE, 0x9C80DC),

    // Advanced natures (kekkei genkai of two elements at once): in the blood, not a clan's. Awakened from DNA or a
    // kekkei genkai scroll; their jutsu come with them.
    LAVA("lava", ChatFormatting.GOLD, 0xE8541C, FIRE, EARTH),
    STORM("storm", ChatFormatting.AQUA, 0x8AD4FF, LIGHTNING, WATER),
    BOIL("boil", ChatFormatting.WHITE, 0xD8E4EA, FIRE, WATER),
    SCORCH("scorch", ChatFormatting.YELLOW, 0xFFA040, FIRE, WIND);

    /** The five basic elements a ninja can be born with. */
    public static final ChakraNature[] ELEMENTS = {FIRE, WATER, WIND, LIGHTNING, EARTH};
    /** All natures: the five elements plus Yin Yang (one combined release). */
    public static final ChakraNature[] NATURES = {FIRE, WATER, WIND, LIGHTNING, EARTH, YIN_YANG};
    /** The clan releases: Wood (Senju), Ice (Yuki), Magnet (Kazekage), Bone (Kaguya), Sealing (Uzumaki). */
    public static final ChakraNature[] CLAN_RELEASES = {WOOD, ICE, MAGNET, BONE, SEALING, SHADOW, MIND, GENTLE_FIST, SPACE_TIME,
            UCHIHA_CLAN, SARUTOBI_CLAN, HATAKE_CLAN, INUZUKA_CLAN, AKIMICHI_CLAN, ABURAME_CLAN, KURAMA_CLAN, CHINOIKE_CLAN, HOZUKI_CLAN, HOSHIGAKI_CLAN, KARATACHI_CLAN, FUMA_CLAN, SHIMURA_CLAN, IBURI_CLAN, TSUCHIGUMO_CLAN, FUNATO_CLAN, TAKETORI_CLAN, SHIROGANE_CLAN, YOTSUKI_CLAN, KAMIZURU_CLAN, OTSUTSUKI_CLAN};
    /** The advanced natures, kekkei genkai of two elements: Lava (Fire + Earth), Storm (Lightning + Water), Boil (Fire + Water), Scorch (Fire + Wind). */
    public static final ChakraNature[] ADVANCED = {LAVA, STORM, BOIL, SCORCH};
    /** Every equippable release: the natures, Ninjutsu and the clan releases. */
    public static final ChakraNature[] RELEASES = {FIRE, WATER, WIND, LIGHTNING, EARTH, YIN_YANG, NONE, MEDICAL, WOOD, ICE, MAGNET, BONE, SEALING, SHADOW, MIND, GENTLE_FIST, SPACE_TIME,
            UCHIHA_CLAN, SARUTOBI_CLAN, HATAKE_CLAN, INUZUKA_CLAN, AKIMICHI_CLAN, ABURAME_CLAN, KURAMA_CLAN, CHINOIKE_CLAN, HOZUKI_CLAN, HOSHIGAKI_CLAN, KARATACHI_CLAN, FUMA_CLAN, SHIMURA_CLAN, IBURI_CLAN, TSUCHIGUMO_CLAN, FUNATO_CLAN, TAKETORI_CLAN, SHIROGANE_CLAN, YOTSUKI_CLAN, KAMIZURU_CLAN, OTSUTSUKI_CLAN, LAVA, STORM, BOIL, SCORCH, RINNEGAN};

    private final String id;
    private final ChatFormatting color;
    private final int rgb;
    @Nullable
    private final String clanId; // by id: Clan refers to ChakraNature, so this side looks the clan up only when asked
    /** An advanced nature's two elements (null for the rest). */
    @Nullable
    private final ChakraNature partA, partB;

    ChakraNature(String id, ChatFormatting color, int rgb) {
        this(id, color, rgb, null);
    }

    ChakraNature(String id, ChatFormatting color, int rgb, @Nullable String clanId) {
        this.id = id;
        this.color = color;
        this.rgb = rgb;
        this.clanId = clanId;
        this.partA = null;
        this.partB = null;
    }

    ChakraNature(String id, ChatFormatting color, int rgb, ChakraNature a, ChakraNature b) {
        this.id = id;
        this.color = color;
        this.rgb = rgb;
        this.clanId = null;
        this.partA = a;
        this.partB = b;
    }

    /** True for Lava, Storm, Boil and Scorch: two elements combined, a kekkei genkai in the blood. */
    public boolean isAdvanced() {
        return partA != null;
    }

    /** An advanced nature's two elements (Lava: Fire and Earth), or an empty array. */
    public ChakraNature[] parts() {
        return partA == null ? new ChakraNature[0] : new ChakraNature[]{partA, partB};
    }

    public String id() {
        return id;
    }

    public ChatFormatting color() {
        return color;
    }

    /** Colour used for HUD elements (0xRRGGBB). */
    public int rgb() {
        return rgb;
    }

    /** True for the six natures a ninja can learn (five elements and Yin Yang); false for Ninjutsu, Medical and clan releases. */
    public boolean isElement() {
        return this != NONE && this != MEDICAL && this != RINNEGAN && clanId == null && partA == null;
    }

    /** A kekkei genkai's release: the clan releases and the Rinnegan. Its jutsu come with it (no scrolls). */
    public boolean isKekkeiGenkai() {
        return clanId != null || this == RINNEGAN || partA != null;
    }

    /** True for Wood, Ice, Magnet, Bone and Sealing, which belong to one clan each. */
    public boolean isClanRelease() {
        return clanId != null;
    }

    /** The clan this release belongs to, or null for everyone's releases. */
    @Nullable
    public Clan clan() {
        return clanId == null ? null : Clan.byId(clanId);
    }

    /** The clan release of a clan (Senju: Wood...), or null if the clan has none. */
    @Nullable
    public static ChakraNature forClan(@Nullable Clan clan) {
        if (clan == null) return null;
        for (ChakraNature n : CLAN_RELEASES) {
            if (clan.id().equals(n.clanId)) return n;
        }
        return null;
    }

    public MutableComponent displayName() {
        return Component.translatable("nature.shinobiarts." + id).withStyle(color);
    }

    /** 64x64 icon shown in the HUD and menus. */
    public ResourceLocation icon() {
        return new ResourceLocation("shinobiarts", "textures/nature/" + id + ".png");
    }

    @Nullable
    public static ChakraNature byId(String id) {
        for (ChakraNature n : values()) {
            if (n.id.equals(id)) return n;
        }
        // older saves used "none" for Ninjutsu and had separate Yin and Yang releases
        if ("none".equals(id)) return NONE;
        if ("yin".equals(id) || "yang".equals(id)) return YIN_YANG;
        return null;
    }
}
