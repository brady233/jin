package com.shinobiarts.ninja;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.RandomSource;

/**
 * The pattern of a player's Mangekyou Sharingan. It decides which eye techniques the Jutsu 1/2/3 keys use:
 * <ul>
 *   <li>Itachi: Amaterasu on Jutsu 1 (black flames where you look), Tsukuyomi on Jutsu 2.</li>
 *   <li>Sasuke: Amaterasu on Jutsu 1, Blaze Release on Jutsu 2 (spikes of black flame; Sneak: a wall of it).</li>
 *   <li>Obito: Kamui on Jutsu 2 (held: intangibility), and the Kamui snap on Sneak + Jutsu 2.</li>
 *   <li>Eternal: Amaterasu and Blaze Release without the strain on the eyes. Reached by implanting a second Mangekyou.</li>
 * </ul>
 * Every Sharingan, from 1 tomoe up, has Genjutsu on Jutsu 3.
 */
public enum MangekyouDesign {
    ITACHI("itachi"),
    SASUKE("sasuke"),
    OBITO("obito"),
    ETERNAL("eternal");

    private final String id;

    MangekyouDesign(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }

    public MutableComponent displayName() {
        return Component.translatable("mangekyou.shinobiarts." + id).withStyle(ChatFormatting.RED);
    }

    public boolean hasAmaterasu() {
        return this == ITACHI || this == SASUKE || this == ETERNAL;
    }

    public boolean hasKamui() {
        return this == OBITO;
    }

    public boolean hasTsukuyomi() {
        return this == ITACHI;
    }

    /** Blaze Release (Enton): shaping Amaterasu's black flames. */
    public boolean hasBlaze() {
        return this == SASUKE || this == ETERNAL;
    }

    /** The Eternal Mangekyou doesn't strain the eyes. */
    public boolean strainsEyes() {
        return this != ETERNAL;
    }

    /** The pattern a newly awakened Mangekyou takes: Itachi, Sasuke or Obito at random. */
    public static MangekyouDesign awaken(RandomSource random) {
        MangekyouDesign[] choices = {ITACHI, SASUKE, OBITO};
        return choices[random.nextInt(choices.length)];
    }

    public static MangekyouDesign byId(String id) {
        for (MangekyouDesign d : values()) {
            if (d.id.equals(id)) return d;
        }
        return ITACHI;
    }

    public static MangekyouDesign byOrdinal(int ordinal) {
        MangekyouDesign[] all = values();
        return ordinal >= 0 && ordinal < all.length ? all[ordinal] : ITACHI;
    }
}
