package com.shinobiarts.ninja;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.world.realm.MyobokuShape;
import com.shinobiarts.world.realm.RealmShape;
import com.shinobiarts.world.realm.RyuchiShape;
import com.shinobiarts.world.realm.ShikkotsuShape;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;

/**
 * The three Sage realms, each its own dimension with its own world generation (see world/realm and
 * data/shinobiarts/dimension): Mount Myoboku (toads), Ryuchi Cave (snakes) and Shikkotsu Forest (slugs).
 * <p>
 * Going in remembers exactly where the player was (saved with the player, so it survives logging out and dying), and
 * leaving puts them back there. The landmark at the middle of each realm (the toad village, the serpent temple, the
 * forest temple) is a sanctuary: only operators and creative players can break or place blocks within
 * {@link #SANCTUARY} blocks of it, and explosions there don't break blocks.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class SageRealms {
    private SageRealms() {}

    public enum Realm {
        MYOBOKU("myoboku", new MyobokuShape()),
        RYUCHI("ryuchi", new RyuchiShape()),
        SHIKKOTSU("shikkotsu", new ShikkotsuShape());

        public final String id;
        public final ResourceKey<Level> key;
        final RealmShape shape;

        Realm(String id, RealmShape shape) {
            this.id = id;
            this.key = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(ShinobiArts.MODID, id));
            this.shape = shape;
        }

        @Nullable
        public static Realm byId(String id) {
            for (Realm r : values()) if (r.id.equalsIgnoreCase(id)) return r;
            return null;
        }

        @Nullable
        public static Realm of(Level level) {
            for (Realm r : values()) if (r.key.equals(level.dimension())) return r;
            return null;
        }

        public Component title() {
            return Component.translatable("realm.shinobiarts." + id);
        }
    }

    /** Radius of the protected landmark at the middle of each realm. */
    public static final int SANCTUARY = 110;
    private static final String TAG = "ShinobiRealmReturn";

    /** Takes the player into a realm, to its arrival point. False if the realm couldn't be loaded. */
    public static boolean enter(ServerPlayer p, Realm realm) {
        ServerLevel to = p.server.getLevel(realm.key);
        if (to == null) return false;
        if (Realm.of(p.level()) == null) {                      // remember where they came from (not when hopping between realms)
            CompoundTag t = new CompoundTag();
            t.putString("Dim", p.level().dimension().location().toString());
            t.putDouble("X", p.getX());
            t.putDouble("Y", p.getY());
            t.putDouble("Z", p.getZ());
            t.putFloat("Yaw", p.getYRot());
            persisted(p).put(TAG, t);
        }
        int[] a = realm.shape.arrival();
        to.getChunk(a[0] >> 4, a[2] >> 4);                      // generate it now
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos(a[0], a[1], a[2]);
        while (m.getY() < to.getMaxBuildHeight() - 2 && !(to.isEmptyBlock(m) && to.isEmptyBlock(m.above()))) m.move(0, 1, 0);
        move(p, to, Vec3.atBottomCenterOf(m), 0f);
        p.sendSystemMessage(Component.translatable("message.shinobiarts.realm_enter", realm.title()).withStyle(ChatFormatting.GREEN));
        return true;
    }

    /** Takes the player out of whatever realm they're in, back to where they entered from. False if not in a realm. */
    public static boolean leave(ServerPlayer p) {
        if (Realm.of(p.level()) == null) return false;
        CompoundTag t = persisted(p).getCompound(TAG);
        ServerLevel to = null;
        Vec3 at = null;
        float yaw = p.getYRot();
        if (t.contains("Dim")) {
            to = p.server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(t.getString("Dim"))));
            at = new Vec3(t.getDouble("X"), t.getDouble("Y"), t.getDouble("Z"));
            yaw = t.getFloat("Yaw");
        }
        if (to == null || Realm.of(to) != null) {
            to = p.server.getLevel(p.getRespawnDimension());
            if (to == null) to = p.server.overworld();
            BlockPos spawn = p.getRespawnPosition() != null && to.dimension() == p.getRespawnDimension() ? p.getRespawnPosition() : to.getSharedSpawnPos();
            at = Vec3.atBottomCenterOf(spawn);
        }
        persisted(p).remove(TAG);
        move(p, to, at, yaw);
        p.sendSystemMessage(Component.translatable("message.shinobiarts.realm_leave").withStyle(ChatFormatting.GRAY));
        return true;
    }

    private static void move(ServerPlayer p, ServerLevel to, Vec3 at, float yaw) {
        p.stopRiding();
        p.ejectPassengers();
        p.teleportTo(to, at.x, at.y, at.z, yaw, 0f);
        p.setDeltaMovement(Vec3.ZERO);
        p.resetFallDistance();
        Fx.at(to, Fx.Visual.SMOKE_BOMB, at.add(0, 1, 0), 1.6f, 20);
        JutsuUtil.sound(to, at, SoundEvents.ENDERMAN_TELEPORT, 0.8f, 0.8f);
    }

    /** The part of the player's saved data that's kept through death. */
    private static CompoundTag persisted(Player p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(Player.PERSISTED_NBT_TAG)) root.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        return root.getCompound(Player.PERSISTED_NBT_TAG);
    }

    // ---------------------------------------------------------------- the sanctuaries

    public static boolean protectedAt(Level level, BlockPos pos) {
        return Realm.of(level) != null && Math.abs(pos.getX()) <= SANCTUARY && Math.abs(pos.getZ()) <= SANCTUARY
                && (long) pos.getX() * pos.getX() + (long) pos.getZ() * pos.getZ() <= (long) SANCTUARY * SANCTUARY;
    }

    private static boolean exempt(@Nullable Player p) {
        return p != null && (p.isCreative() || p.hasPermissions(2));
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (event.getLevel() instanceof Level level && protectedAt(level, event.getPos()) && !exempt(event.getPlayer())) {
            event.setCanceled(true);
            event.getPlayer().displayClientMessage(Component.translatable("message.shinobiarts.realm_sanctuary").withStyle(ChatFormatting.RED), true);
        }
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (event.getLevel() instanceof Level level && protectedAt(level, event.getPos())) {
            Player p = event.getEntity() instanceof Player pl ? pl : null;
            if (exempt(p)) return;
            event.setCanceled(true);
            if (p != null) p.displayClientMessage(Component.translatable("message.shinobiarts.realm_sanctuary").withStyle(ChatFormatting.RED), true);
        }
    }

    @SubscribeEvent
    public static void onExplode(ExplosionEvent.Detonate event) {
        if (Realm.of(event.getLevel()) != null) event.getAffectedBlocks().removeIf(pos -> protectedAt(event.getLevel(), pos));
    }
}
