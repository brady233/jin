package com.shinobiarts;

import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.JutsuRank;
import com.shinobiarts.jutsu.Jutsus;
import net.minecraftforge.common.ForgeConfigSpec;

import javax.annotation.Nullable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * All balance values, split over several config files kept together in the game's (or server's) config folder,
 * config/Naruto Generations/ (players who join a server are sent its files, see ConfigSyncPacket):
 * <ul>
 *   <li>Jutsus.toml: every jutsu (its own damage, cooldown, chakra cost and charge), eye techniques, Susanoo, gates...</li>
 *   <li>Weapons.toml: the ninja weapons.</li>
 *   <li>Food.toml: chakra pills and EXP bottles.</li>
 *   <li>Stats.toml: chakra, leveling, ranks and the stat points.</li>
 *   <li>Spawn weights and chances.toml: bandit spawns and drops, clan roll chances, DNA and kekkei genkai scroll drops.</li>
 *   <li>General.toml: everything else (PvP, combat tag, villages, teams, clan rolls).</li>
 * </ul>
 * Forge sends them all to every client that joins, so the HUD and menus show the same numbers the server uses.
 * Use the b()/i()/d() helpers to read values safely even before a world is loaded.
 */
public final class Config {
    /** The folder (inside config) the files live in. */
    public static final String FOLDER = "Naruto Generations/";

    private static final ForgeConfigSpec.Builder GENERAL = new ForgeConfigSpec.Builder();
    private static final ForgeConfigSpec.Builder WEAPONS = new ForgeConfigSpec.Builder();
    private static final ForgeConfigSpec.Builder FOOD = new ForgeConfigSpec.Builder();
    private static final ForgeConfigSpec.Builder STATS = new ForgeConfigSpec.Builder();
    private static final ForgeConfigSpec.Builder JUTSUS = new ForgeConfigSpec.Builder();
    private static final ForgeConfigSpec.Builder SPAWNS = new ForgeConfigSpec.Builder();

    // ================================================================================================ Jutsus.toml

    // ---------------------------------------------------------------- every jutsu
    static { JUTSUS.comment("Applies to every jutsu. Each jutsu also has its own section further down ([jutsu.fireball]...).").push("general"); }
    public static final ForgeConfigSpec.BooleanValue JUTSU_GRIEFING = JUTSUS
            .comment("Allow jutsu and explosive tags to place fire, break plants/blocks and raise earth walls over grass.",
                     "The mobGriefing gamerule must also be true.")
            .define("jutsuGriefing", true);
    public static final ForgeConfigSpec.DoubleValue DAMAGE_MULTIPLIER = JUTSUS
            .comment("Multiplier applied to all jutsu damage (on top of each jutsu's own damageMultiplier).")
            .defineInRange("damageMultiplier", 1.0, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue COOLDOWN_MULTIPLIER = JUTSUS
            .comment("Multiplier applied to all jutsu cooldowns (on top of each jutsu's own cooldownSeconds).")
            .defineInRange("cooldownMultiplier", 1.0, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue CHAKRA_COST_MULTIPLIER = JUTSUS
            .comment("Multiplier applied to every jutsu's chakra cost (on top of each jutsu's own chakraCost).")
            .defineInRange("chakraCostMultiplier", 1.0, 0.0, 10.0);
    public static final ForgeConfigSpec.BooleanValue CHARGE_ENABLED = JUTSUS
            .comment("Hold right-click to charge jutsu that deal damage; let go to cast. If false, every jutsu casts on click.")
            .define("chargingEnabled", true);
    /** Whether the server has banned this jutsu ("bannedJutsu" in Jutsus.toml). */
    public static boolean banned(String jutsuId) {
        try {
            return BANNED_JUTSU.get().contains(jutsuId);
        } catch (IllegalStateException notLoaded) {
            return false;
        }
    }

    public static final ForgeConfigSpec.DoubleValue KAMUI_SHURIKEN_HEAD = JUTSUS
            .comment("Obito's Perfect Susanoo throws Kamui shuriken (right-click). Share of a player's max health a hit to the",
                     "head takes (1.1 = always fatal).").defineInRange("kamuiShurikenPlayerHead", 1.1, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue KAMUI_SHURIKEN_BODY = JUTSUS
            .comment("Share of a player's max health a Kamui shuriken hit to the body takes.").defineInRange("kamuiShurikenPlayerBody", 0.15, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue KAMUI_SHURIKEN_MOB = JUTSUS
            .comment("Share of a mob's max health a Kamui shuriken takes (head or body).").defineInRange("kamuiShurikenMob", 0.10, 0.0, 10.0);
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> BANNED_JUTSU = JUTSUS
            .comment("Jutsu nobody can use on this server, by id (e.g. [\"chibaku_tensei\", \"rock_golem\"]). Their ids are the",
                     "[jutsu.<id>] section names below. Banned jutsu can't be cast or learned and their scrolls do nothing.")
            .defineList("bannedJutsu", List.of(), o -> o instanceof String);
    public static final ForgeConfigSpec.DoubleValue MAX_CHARGE = JUTSUS
            .comment("Keep holding past a full charge to overcharge: the counter climbs from the jutsu's chargeMaxPower (1.5)",
                     "up to this. Overcharging adds no damage; it only makes the jutsu bigger (its size and radius grow by",
                     "charge / chargeMaxPower, so 10 makes it about 6.7 times as big).")
            .defineInRange("maxCharge", 10.0, 1.0, 50.0);
    public static final ForgeConfigSpec.DoubleValue OVERCHARGE_SECONDS = JUTSUS
            .comment("Seconds of holding after a full charge to reach maxCharge.")
            .defineInRange("overchargeSeconds", 4.0, 0.1, 60.0);
    public static final ForgeConfigSpec.DoubleValue OVERCHARGE_CHAKRA = JUTSUS
            .comment("Extra chakra an overcharged jutsu costs, per extra size (0.15: a jutsu 6.7 times as big costs 1.85 times as much).")
            .defineInRange("overchargeChakraPerSize", 0.15, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue BANDIT_JUTSU_DAMAGE = JUTSUS
            .comment("Damage of the Ninja Bandits' jutsu.").defineInRange("banditJutsuDamage", 6.0, 0.0, 1000.0);
    static { JUTSUS.pop(); }

    // ---------------------------------------------------------------- jutsu ranks
    static { JUTSUS.push("jutsuRanks"); }
    public static final ForgeConfigSpec.BooleanValue RANK_REQUIREMENTS = JUTSUS
            .comment("If true, A-rank and S-rank jutsu scrolls need a minimum player level to learn (D, C and B never do).",
                     "With the default rank level caps (Genin 75, Chunin 150), A-rank needs a Chunin and S-rank a Jonin.")
            .define("rankRequirements", true);
    public static final ForgeConfigSpec.IntValue RANK_A_LEVEL = JUTSUS.defineInRange("minLevelA", 90, 1, 100000);
    public static final ForgeConfigSpec.IntValue RANK_S_LEVEL = JUTSUS.defineInRange("minLevelS", 175, 1, 100000);
    static { JUTSUS.pop(); }

    // ---------------------------------------------------------------- jutsu upgrades
    static { JUTSUS.comment("Jutsu Points: a chance to earn some on each level-up, spent to upgrade a jutsu's damage.").push("jutsuUpgrades"); }
    public static final ForgeConfigSpec.DoubleValue JUTSU_POINT_CHANCE = JUTSUS
            .comment("Chance (0-1) of earning Jutsu Points on each level-up.").defineInRange("pointChance", 0.35, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue JUTSU_POINTS_MIN = JUTSUS.defineInRange("pointsMin", 2, 0, 1000);
    public static final ForgeConfigSpec.IntValue JUTSU_POINTS_MAX = JUTSUS.defineInRange("pointsMax", 6, 0, 1000);
    public static final ForgeConfigSpec.IntValue JUTSU_UPGRADE_COST = JUTSUS
            .comment("Jutsu Points needed for one upgrade.").defineInRange("upgradeCost", 20, 1, 100000);
    public static final ForgeConfigSpec.DoubleValue JUTSU_UPGRADE_DAMAGE = JUTSUS
            .comment("Extra damage per upgrade (0.15 = +15%).").defineInRange("damagePerUpgrade", 0.15, 0.0, 10.0);
    public static final ForgeConfigSpec.IntValue JUTSU_MAX_UPGRADES = JUTSUS
            .comment("How many times one jutsu can be upgraded.").defineInRange("maxUpgrades", 5, 1, 100);
    static { JUTSUS.pop(); }

    // ---------------------------------------------------------------- jutsu tuning
    static { JUTSUS.push("jutsuTuning"); }
    public static final ForgeConfigSpec.IntValue SUBSTITUTION_BACK = JUTSUS
            .comment("Substitution: how many blocks back (away from the attacker) you jump when it takes a hit.")
            .defineInRange("substitutionBlocksBack", 4, 0, 16);
    public static final ForgeConfigSpec.IntValue SUBSTITUTION_UP = JUTSUS
            .comment("...and how many blocks up.").defineInRange("substitutionBlocksUp", 2, 0, 16);
    public static final ForgeConfigSpec.IntValue SUBSTITUTION_LOG_SECONDS = JUTSUS
            .comment("How long the 2 logs left behind stay before they vanish.").defineInRange("substitutionLogSeconds", 10, 1, 600);
    public static final ForgeConfigSpec.IntValue SHADOW_CLONE_COUNT = JUTSUS
            .comment("Clones made by the Shadow Clone Jutsu (Uzumaki get twice as many).").defineInRange("shadowClones", 2, 1, 50);
    public static final ForgeConfigSpec.IntValue MULTI_SHADOW_CLONE_COUNT = JUTSUS
            .comment("Clones made by the Multi Shadow Clone Jutsu (Uzumaki get twice as many).").defineInRange("multiShadowClones", 10, 1, 50);
    public static final ForgeConfigSpec.DoubleValue SHADOW_POSSESSION_SECONDS = JUTSUS
            .comment("How long Shadow Possession holds its target, in seconds. While it holds, the target",
                     "copies every step and turn the caster makes.")
            .defineInRange("shadowPossessionDuration", 10.0, 0.5, 120.0);
    public static final ForgeConfigSpec.IntValue SHADOW_POSSESSION_RANGE = JUTSUS
            .comment("How far the shadow reaches to catch a target, and how far it stretches before it snaps.")
            .defineInRange("shadowPossessionRange", 24, 4, 64);
    public static final ForgeConfigSpec.DoubleValue WATER_PRISON_SECONDS = JUTSUS
            .comment("Water Prison lasts as long as you hold right-click (and stay put, or it bursts), up to this many seconds.",
                     "The target takes the jutsu's damage once every second inside it (half as much again once its air runs out).")
            .defineInRange("waterPrisonMaxSeconds", 120.0, 1.0, 3600.0);
    public static final ForgeConfigSpec.DoubleValue MIND_TRANSFER_SECONDS = JUTSUS
            .comment("How long Mind Body Transfer (Yamanaka) keeps your mind in the other body (sneak to come back sooner).")
            .defineInRange("mindTransferSeconds", 15.0, 1.0, 600.0);
    public static final ForgeConfigSpec.DoubleValue MIND_TRANSFER_SHARE = JUTSUS
            .comment("Share of the damage the borrowed body takes that your own body feels too (1 = all of it, 0 = none).")
            .defineInRange("mindTransferPainShare", 0.5, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue WATER_PRISON_DRAIN = JUTSUS
            .comment("Share of max chakra Water Prison drains every second while you hold it (it bursts when you run out).")
            .defineInRange("waterPrisonDrain", 0.03, 0.0, 1.0);
    static { JUTSUS.pop(); }

    // ---------------------------------------------------------------- sharingan
    static { JUTSUS.comment("Sharingan evolution: 1 tomoe -> 2 -> 3 -> Mangekyou, one stage at a time.").push("sharingan"); }
    public static final ForgeConfigSpec.IntValue SHARINGAN_2_LEVEL = JUTSUS.defineInRange("twoTomoeLevel", 30, 1, 100000);
    public static final ForgeConfigSpec.IntValue SHARINGAN_3_LEVEL = JUTSUS.defineInRange("threeTomoeLevel", 60, 1, 100000);
    public static final ForgeConfigSpec.IntValue MANGEKYOU_LEVEL = JUTSUS
            .comment("Level needed (with 3 tomoe) before a near-death experience awakens the Mangekyou.")
            .defineInRange("mangekyouLevel", 100, 1, 100000);
    public static final ForgeConfigSpec.DoubleValue MANGEKYOU_HEALTH = JUTSUS
            .comment("The near-death experience: surviving at or below this share of max health (0.05 = 5%).")
            .defineInRange("mangekyouNearDeathHealth", 0.05, 0.001, 0.5);
    public static final ForgeConfigSpec.BooleanValue EYE_THEFT = JUTSUS
            .comment("Defeating a Sharingan user in PvP (when the kill gives rewards) takes one of their eyes as an item.",
                     "Players who weren't born Uchiha lose their Sharingan when it's taken.")
            .define("eyeTheft", true);
    public static final ForgeConfigSpec.DoubleValue TENGAI_DAMAGE = JUTSUS
            .comment("Tengai Shinsei (Rinnegan): damage at the heart of a meteor's impact (less toward its edge; the second meteor",
                     "hits half again as hard).").defineInRange("tengaiShinseiDamage", 45.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.BooleanValue TENGAI_SECOND = JUTSUS
            .comment("Tengai Shinsei drops a second, bigger meteor right after the first.").define("tengaiShinseiSecondMeteor", true);
    public static final ForgeConfigSpec.BooleanValue TENGAI_BREAKS_BLOCKS = JUTSUS
            .comment("Tengai Shinsei's meteors blow craters in the ground.").define("tengaiShinseiCraters", false);
    public static final ForgeConfigSpec.DoubleValue SHARK_FORM_DRAIN = JUTSUS
            .comment("Shark Transformation: chakra burned every second while transformed.")
            .defineInRange("sharkFormDrainPerSecond", 6.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.DoubleValue MEDICAL_TALENT_CHANCE = JUTSUS
            .comment("Chance (0-1) that a player is born a medical ninja (rolled once, when they claim their clan). Only medical ninja can learn and use Medical Release.")
            .defineInRange("medicalTalentChance", 0.08, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue TENKETSU_CHANCE_NORMAL = JUTSUS
            .comment("Chakra points: chance that an ordinary hit from a player damages one of the victim's chakra points.")
            .defineInRange("chakraPointChanceNormal", 0.01, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue TENKETSU_CHANCE_BYAKUGAN = JUTSUS
            .comment("Chance for a Gentle Fist hit (melee with the Byakugan active).")
            .defineInRange("chakraPointChanceGentleFist", 0.3, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue TENKETSU_CHANCE_HIGH = JUTSUS
            .comment("Chance for moves made to hit chakra points: Chakra Scalpel, Rasenshuriken, Palm Rotation, Eight Trigrams 64 Palms.")
            .defineInRange("chakraPointChanceHigh", 0.55, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue TENKETSU_HEAL_MINUTES = JUTSUS
            .comment("A damaged chakra point heals by itself after this many minutes (medical ninja heal them at once).")
            .defineInRange("chakraPointHealMinutes", 10, 1, 1440);
    public static final ForgeConfigSpec.DoubleValue XP_GENIN = JUTSUS
            .comment("XP multipliers by rank and role. Only the single highest one that applies is used (they never stack).")
            .defineInRange("xpMultiplierGenin", 1.0, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue XP_CHUNIN = JUTSUS.defineInRange("xpMultiplierChunin", 1.3, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue XP_JONIN = JUTSUS.defineInRange("xpMultiplierJonin", 1.6, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue XP_ANBU = JUTSUS.defineInRange("xpMultiplierAnbu", 2.3, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue XP_SANNIN = JUTSUS.defineInRange("xpMultiplierSannin", 2.3, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue XP_ADVISOR = JUTSUS
            .comment("Village advisors also get Luck I while they hold the post.")
            .defineInRange("xpMultiplierAdvisor", 2.0, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue XP_KAGE = JUTSUS
            .comment("Kages also get Luck II and extra Ryo on level-ups (kageRyoBonus).")
            .defineInRange("xpMultiplierKage", 2.5, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue KAGE_RYO_BONUS = JUTSUS
            .comment("A Kage's Ryo from levelling up is multiplied by this.")
            .defineInRange("kageRyoBonus", 1.25, 1.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue WAR_KILL_MULTIPLIER = JUTSUS
            .comment("PvP kill rewards (XP and Ryo) between villages at war are multiplied by this.")
            .defineInRange("warKillRewardMultiplier", 1.5, 1.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue KENJUTSU_MULTIPLIER = JUTSUS
            .comment("Sword damage multiplier per Kenjutsu point (0.01 = +1% each: 175 Kenjutsu = x2.75).")
            .defineInRange("kenjutsuMultiplierPerPoint", 0.01, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue TAIJUTSU_MULTIPLIER = JUTSUS
            .comment("Eight Gates punch and strength multiplier per Taijutsu point.")
            .defineInRange("taijutsuGatesMultiplierPerPoint", 0.01, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue SENJUTSU_MULTIPLIER = JUTSUS
            .comment("Sage Mode jutsu multiplier per Senjutsu point.")
            .defineInRange("senjutsuSageMultiplierPerPoint", 0.01, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue BORROWED_EYE_DRAIN = JUTSUS
            .comment("Share of max chakra a Sharingan implanted from someone else's eye drains every second while active.")
            .defineInRange("borrowedEyeDrain", 0.10, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue EDO_SECONDS = JUTSUS
            .comment("Edo Tensei: how long a reincarnated soul stays before it's released.").defineInRange("edoTenseiSeconds", 90, 5, 3600);
    public static final ForgeConfigSpec.IntValue EDO_MAX = JUTSUS
            .comment("Edo Tensei: how many souls one cast brings back (the ninja you killed most recently first).")
            .defineInRange("edoTenseiSouls", 2, 1, 5);
    public static final ForgeConfigSpec.BooleanValue EDO_SACRIFICE = JUTSUS
            .comment("Edo Tensei needs a living sacrifice for each soul: a mob near the caster is wrapped in dust and becomes the",
                     "soul's body (off: no sacrifice needed).").define("edoTenseiNeedsSacrifice", true);
    public static final ForgeConfigSpec.DoubleValue EDO_HEALTH = JUTSUS
            .comment("Edo Tensei: a reincarnated soul's health (losing it all only breaks the body apart for a few seconds).")
            .defineInRange("edoTenseiHealth", 40.0, 1.0, 1000.0);
    public static final ForgeConfigSpec.DoubleValue EDO_DAMAGE = JUTSUS
            .comment("Edo Tensei: a reincarnated soul's melee damage (up to twice this for a soul of level 100).")
            .defineInRange("edoTenseiDamage", 7.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.DoubleValue EYE_THEFT_CHANCE = JUTSUS
            .comment("Chance that such a kill takes one of their eyes (0.02 = 2%).").defineInRange("eyeTheftChance", 0.02, 0.0, 1.0);
    static { JUTSUS.pop(); }

    // ---------------------------------------------------------------- eye techniques (Jutsu 1/2/3 keys)
    static { JUTSUS.comment("Techniques of an active Sharingan, used with the Jutsu 1/2/3 keys.",
            "Costs are shares of max chakra (0.25 = 25%). Cooldowns and durations are in seconds.").push("eyeTechniques"); }
    public static final ForgeConfigSpec.DoubleValue AMATERASU_COST = JUTSUS
            .comment("Amaterasu (Jutsu 1, Itachi/Sasuke/Eternal Mangekyou): black flames where you look.")
            .defineInRange("amaterasuCost", 0.25, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue AMATERASU_COOLDOWN = JUTSUS
            .comment("Seconds between Amaterasu casts (0 = none).").defineInRange("amaterasuCooldown", 0, 0, 3600);
    public static final ForgeConfigSpec.IntValue AMATERASU_RANGE = JUTSUS.defineInRange("amaterasuRange", 40, 4, 128);
    public static final ForgeConfigSpec.IntValue AMATERASU_FLAME_SECONDS = JUTSUS
            .comment("How long black flames burn before they die out on their own (they never spread or burn blocks).")
            .defineInRange("amaterasuFlameSeconds", 300, 5, 86400);
    public static final ForgeConfigSpec.IntValue AMATERASU_EXTINGUISH_RADIUS = JUTSUS
            .comment("Sneaking with the Mangekyou on puts out every black flame within this many blocks.")
            .defineInRange("amaterasuExtinguishRadius", 10, 1, 64);
    public static final ForgeConfigSpec.DoubleValue KAMUI_COST = JUTSUS
            .comment("Kamui (hold Jutsu 2, Obito's Mangekyou): while the key is held you're intangible. You fly through blocks",
                     "and attacks, projectiles and jutsu pass through you (you can't hurt anything either). Let go to come back.")
            .defineInRange("kamuiCost", 0.20, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue KAMUI_SECONDS = JUTSUS
            .comment("Longest Kamui can be held, in seconds (it also ends when your chakra runs out).")
            .defineInRange("kamuiMaxSeconds", 15, 1, 600);
    public static final ForgeConfigSpec.DoubleValue KAMUI_DRAIN = JUTSUS
            .comment("Chakra drained every second while intangible.").defineInRange("kamuiDrainPerSecond", 3.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.IntValue KAMUI_COOLDOWN = JUTSUS
            .comment("Cooldown after intangibility ends.").defineInRange("kamuiCooldown", 10, 0, 3600);
    public static final ForgeConfigSpec.DoubleValue KAMUI_SNAP_COST = JUTSUS
            .comment("Kamui snap (Sneak + Jutsu 2): tears at the creature you look at.").defineInRange("kamuiSnapCost", 0.30, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue KAMUI_SNAP_DAMAGE = JUTSUS
            .comment("Kamui snap damage as a share of the target's max health (0.5 = 50%). Ignores armor.")
            .defineInRange("kamuiSnapHealthShare", 0.5, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue KAMUI_SNAP_BOSS_MAX = JUTSUS
            .comment("Most damage one Kamui snap can deal to a boss (Wither, Ender Dragon and other forge:bosses).")
            .defineInRange("kamuiSnapBossMaxDamage", 20.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.IntValue KAMUI_SNAP_COOLDOWN = JUTSUS.defineInRange("kamuiSnapCooldown", 30, 0, 3600);
    public static final ForgeConfigSpec.IntValue KAMUI_SNAP_RANGE = JUTSUS.defineInRange("kamuiSnapRange", 20, 2, 128);
    public static final ForgeConfigSpec.DoubleValue KAMUI_WARP_COST = JUTSUS
            .comment("Kamui warp (Jutsu 1, Obito's Mangekyou): into the Kamui dimension, or back out.").defineInRange("kamuiWarpCost", 0.15, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue KAMUI_WARP_COOLDOWN = JUTSUS.defineInRange("kamuiWarpCooldown", 5, 0, 3600);
    public static final ForgeConfigSpec.DoubleValue KAMUI_ABDUCT_COST = JUTSUS
            .comment("Kamui abduction (Sneak + Jutsu 1): the creature you look at is taken into the Kamui dimension.")
            .defineInRange("kamuiAbductCost", 0.35, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue KAMUI_ABDUCT_COOLDOWN = JUTSUS.defineInRange("kamuiAbductCooldown", 60, 0, 3600);
    public static final ForgeConfigSpec.IntValue KAMUI_TRAP_SECONDS = JUTSUS
            .comment("How long a player taken by Kamui abduction is trapped in the Kamui dimension before being thrown back.")
            .defineInRange("kamuiTrapSeconds", 30, 1, 3600);
    public static final ForgeConfigSpec.DoubleValue GENJUTSU_COST = JUTSUS
            .comment("Genjutsu (Jutsu 3, every Sharingan): traps the creature you look at in an illusion.",
                     "Stronger and longer with each stage and with the Genjutsu stat; the Mangekyou also roots them in place.")
            .defineInRange("genjutsuCost", 0.10, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue GENJUTSU_COOLDOWN = JUTSUS.defineInRange("genjutsuCooldown", 20, 0, 3600);
    // Itachi's Mangekyou
    public static final ForgeConfigSpec.DoubleValue TSUKUYOMI_COST = JUTSUS
            .comment("Tsukuyomi (Jutsu 2, Itachi's Mangekyou): freezes the creature or player you look at (no moving, attacking",
                     "or jutsu); when it ends they take a share of their max health at once, ignoring armor. Players also lose",
                     "chakra. A victim with their Sharingan on is held half as long.")
            .defineInRange("tsukuyomiCost", 0.30, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue TSUKUYOMI_COOLDOWN = JUTSUS.defineInRange("tsukuyomiCooldown", 40, 0, 3600);
    public static final ForgeConfigSpec.IntValue TSUKUYOMI_RANGE = JUTSUS.defineInRange("tsukuyomiRange", 20, 2, 128);
    public static final ForgeConfigSpec.DoubleValue TSUKUYOMI_SECONDS = JUTSUS
            .comment("How long the victim is frozen (longer with the Genjutsu stat).").defineInRange("tsukuyomiSeconds", 4.0, 0.5, 60.0);
    public static final ForgeConfigSpec.DoubleValue TSUKUYOMI_DAMAGE = JUTSUS
            .comment("Damage when it ends, as a share of the victim's max health.").defineInRange("tsukuyomiHealthShare", 0.25, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue TSUKUYOMI_BOSS_MAX = JUTSUS.defineInRange("tsukuyomiBossMaxDamage", 20.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue TSUKUYOMI_CHAKRA_DRAIN = JUTSUS
            .comment("Share of a player victim's chakra it takes.").defineInRange("tsukuyomiChakraDrain", 0.40, 0.0, 1.0);
    // Sasuke's and the Eternal Mangekyou
    public static final ForgeConfigSpec.DoubleValue BLAZE_COST = JUTSUS
            .comment("Blaze Release (Jutsu 2, Sasuke's and the Eternal Mangekyou): spikes of black flame burst from the ground in a",
                     "line toward where you look; everything they hit catches Amaterasu.")
            .defineInRange("blazeCost", 0.25, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue BLAZE_COOLDOWN = JUTSUS.defineInRange("blazeCooldown", 20, 0, 3600);
    public static final ForgeConfigSpec.IntValue BLAZE_RANGE = JUTSUS.defineInRange("blazeRange", 15, 3, 64);
    public static final ForgeConfigSpec.DoubleValue BLAZE_DAMAGE = JUTSUS.defineInRange("blazeDamage", 9.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.DoubleValue BLAZE_WALL_COST = JUTSUS
            .comment("Black flame wall (Sneak + Jutsu 2, same eyes): a wall of black flames across your path. Anything walking into",
                     "it burns and is thrown back; arrows and jutsu thrown through it burn up.")
            .defineInRange("blazeWallCost", 0.25, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue BLAZE_WALL_COOLDOWN = JUTSUS.defineInRange("blazeWallCooldown", 30, 0, 3600);
    public static final ForgeConfigSpec.IntValue BLAZE_WALL_SECONDS = JUTSUS.defineInRange("blazeWallSeconds", 15, 1, 300);
    public static final ForgeConfigSpec.IntValue BLAZE_WALL_WIDTH = JUTSUS.defineInRange("blazeWallWidth", 7, 3, 21);
    // Byakugan
    public static final ForgeConfigSpec.DoubleValue PALMS_COST = JUTSUS
            .comment("Eight Trigrams 64 Palms (Jutsu 1, Byakugan on): dash to the target and strike 8 times. Seals their chakra",
                     "points (no jutsu, eye techniques or Susanoo); players also lose chakra, creatures are slowed and weakened.")
            .defineInRange("palmsCost", 0.20, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue PALMS_COOLDOWN = JUTSUS.defineInRange("palmsCooldown", 25, 0, 3600);
    public static final ForgeConfigSpec.IntValue PALMS_RANGE = JUTSUS.defineInRange("palmsRange", 6, 2, 32);
    public static final ForgeConfigSpec.DoubleValue PALMS_DAMAGE = JUTSUS
            .comment("Total damage of all the strikes.").defineInRange("palmsDamage", 24.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.IntValue PALMS_SEAL_SECONDS = JUTSUS.defineInRange("palmsSealSeconds", 8, 0, 300);
    public static final ForgeConfigSpec.DoubleValue PALMS_CHAKRA_DRAIN = JUTSUS.defineInRange("palmsChakraDrain", 0.5, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue AIR_PALM_COST = JUTSUS
            .comment("Air Palm (Jutsu 2, Byakugan on): a blast of air down your line of sight, with heavy knockback.")
            .defineInRange("airPalmCost", 0.08, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue AIR_PALM_COOLDOWN = JUTSUS.defineInRange("airPalmCooldown", 5, 0, 3600);
    public static final ForgeConfigSpec.IntValue AIR_PALM_RANGE = JUTSUS.defineInRange("airPalmRange", 20, 2, 64);
    public static final ForgeConfigSpec.DoubleValue AIR_PALM_DAMAGE = JUTSUS.defineInRange("airPalmDamage", 10.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.DoubleValue ALL_SEEING_COST = JUTSUS
            .comment("All-Seeing Eye (Jutsu 3, Byakugan on): for a while everything living within range glows through walls",
                     "(invisible players too), and the HUD warns you when someone is right behind you.")
            .defineInRange("allSeeingCost", 0.10, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue ALL_SEEING_COOLDOWN = JUTSUS.defineInRange("allSeeingCooldown", 40, 0, 3600);
    public static final ForgeConfigSpec.IntValue ALL_SEEING_SECONDS = JUTSUS.defineInRange("allSeeingSeconds", 20, 1, 600);
    public static final ForgeConfigSpec.IntValue ALL_SEEING_RANGE = JUTSUS.defineInRange("allSeeingRange", 60, 8, 128);
    static { JUTSUS.pop(); }

    // ---------------------------------------------------------------- Eight Inner Gates
    static { JUTSUS.push("eightGates"); }
    public static final ForgeConfigSpec.IntValue GATES_TAIJUTSU_PER_GATE = JUTSUS
            .comment("Eight Inner Gates (key I; Sneak + I closes them): Taijutsu points needed per gate (gate 8 needs 8x this).")
            .defineInRange("taijutsuPerGate", 10, 0, 1000);
    public static final ForgeConfigSpec.DoubleValue GATES_SPEED_PER_GATE = JUTSUS
            .comment("Movement speed per open gate (0.2 = +20%; the eighth gate adds another 0.6 on top).")
            .defineInRange("speedPerGate", 0.20, 0.0, 2.0);
    public static final ForgeConfigSpec.DoubleValue GATES_ATTACK_SPEED_PER_GATE = JUTSUS
            .comment("Attack speed per open gate (0.2 = +20%).").defineInRange("attackSpeedPerGate", 0.20, 0.0, 2.0);
    public static final ForgeConfigSpec.DoubleValue GATES_DAMAGE_PER_GATE = JUTSUS
            .comment("Extra bare-hand damage per open gate (doubled at the eighth).").defineInRange("punchDamagePerGate", 5.0, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue GATES_STRENGTH_PER_GATE = JUTSUS
            .comment("Extra damage with any weapon per open gate (0.15 = +15%; doubled at the eighth).")
            .defineInRange("strengthPerGate", 0.15, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue GATES_RESISTANCE_PER_GATE = JUTSUS
            .comment("Less damage taken per open gate (0.04 = 4% less; capped at 60%).").defineInRange("resistancePerGate", 0.04, 0.0, 0.2);
    public static final ForgeConfigSpec.DoubleValue GATES_DRAIN_MULTIPLIER = JUTSUS
            .comment("Scales the health the gates cost every second (gates 3-8: 0.5, 1, 1.5, 2, 3, 4).")
            .defineInRange("healthDrainMultiplier", 1.0, 0.0, 10.0);
    public static final ForgeConfigSpec.IntValue GATE8_SECONDS = JUTSUS
            .comment("How long the Gate of Death stays open (press the key again for Night Guy before it closes).")
            .defineInRange("gate8Seconds", 20, 1, 600);
    public static final ForgeConfigSpec.BooleanValue GATE8_KILLS = JUTSUS
            .comment("Opening the Gate of Death costs your life: when it closes (or after Night Guy) you wither away.",
                     "If false, you're left with one heart and weakened instead, and the gates stay locked for lockMinutes.")
            .define("gateOfDeathKills", true);
    public static final ForgeConfigSpec.DoubleValue NIGHT_GUY_DAMAGE = JUTSUS.defineInRange("nightGuyDamage", 150.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.IntValue GATES_LOCK_MINUTES = JUTSUS
            .comment("After the Gate of Death closes (and you survive it), the gates stay locked this many minutes.")
            .defineInRange("lockMinutes", 10, 0, 1440);
    static { JUTSUS.pop(); }

    // ---------------------------------------------------------------- Chakra Control
    static { JUTSUS.push("chakraControl"); }
    public static final ForgeConfigSpec.DoubleValue CHAKRA_CONTROL_DRAIN = JUTSUS
            .comment("Chakra Control (toggle key, N by default): walk up walls and trees by looking at them, hang from ceilings",
                     "and walk on water. Chakra drained every second while climbing, on a ceiling or standing on water.")
            .defineInRange("chakraControlDrainPerSecond", 0.5, 0.0, 1000.0);
    public static final ForgeConfigSpec.DoubleValue CHAKRA_CONTROL_CLIMB_SPEED = JUTSUS
            .comment("How fast you walk up a wall, in blocks per tick (a ladder is about 0.12).")
            .defineInRange("chakraControlClimbSpeed", 0.22, 0.05, 1.0);
    public static final ForgeConfigSpec.BooleanValue CHAKRA_CONTROL_CEILINGS = JUTSUS
            .comment("Let Chakra Control walk upside down on ceilings (jump or climb into one; sneak to drop off).")
            .define("ceilingWalking", true);
    static { JUTSUS.pop(); }

    // ---------------------------------------------------------------- Ninja Jump
    static { JUTSUS.push("ninjaJump"); }
    public static final ForgeConfigSpec.IntValue NINJA_JUMP_COST = JUTSUS
            .comment("Sneak + Jump from the ground (or from the water with Chakra Control on).").defineInRange("chakraCost", 15, 0, 100000);
    public static final ForgeConfigSpec.DoubleValue NINJA_JUMP_POWER = JUTSUS
            .comment("Multiplier for how far the jump launches you.").defineInRange("power", 1.0, 0.1, 5.0);
    static { JUTSUS.pop(); }

    // ---------------------------------------------------------------- Susanoo
    static { JUTSUS.comment("The Susanoo (key O with the Mangekyou Sharingan on). Lists give one value per stage:",
            "Ribcage, Skeletal, Humanoid, Armored, Perfect.").push("susanoo"); }
    public static final ForgeConfigSpec.ConfigValue<List<? extends Number>> SUSANOO_LEVELS = JUTSUS
            .comment("Ninja level needed for each stage (the Mangekyou itself is needed for all of them).")
            .defineList("stageLevels", List.of(100, 125, 150, 200, 250), o -> o instanceof Number);
    public static final ForgeConfigSpec.BooleanValue SUSANOO_PERFECT_NEEDS_ETERNAL = JUTSUS
            .comment("The Perfect Susanoo also needs the Eternal Mangekyou (switched on: triple-tap the eye key).")
            .define("perfectNeedsEternal", true);
    public static final ForgeConfigSpec.ConfigValue<List<? extends Number>> SUSANOO_HEALTH = JUTSUS
            .comment("Health of each stage.").defineList("health", List.of(1000, 1800, 4000, 7000, 11000), o -> o instanceof Number);
    public static final ForgeConfigSpec.BooleanValue SUSANOO_HEALTH_SCALES = JUTSUS
            .comment("If true, the health above is for 100 max chakra and grows by half as much as your max chakra does.",
                     "If false, every Susanoo has exactly the health above.")
            .define("healthScalesWithChakra", false);
    public static final ForgeConfigSpec.DoubleValue SUSANOO_FORM_SECONDS = JUTSUS
            .comment("How long the Susanoo takes to build itself up when summoned or when it grows a stage (bones first,",
                     "rising from the ground). It can already take hits while it forms.")
            .defineInRange("formSeconds", 2.5, 0.0, 20.0);
    public static final ForgeConfigSpec.ConfigValue<List<? extends Number>> SUSANOO_ABSORB = JUTSUS
            .comment("Share of each hit on you that the Susanoo takes instead (the rest reaches you).")
            .defineList("absorb", List.of(0.7, 0.85, 1.0, 1.0, 1.0), o -> o instanceof Number);
    public static final ForgeConfigSpec.ConfigValue<List<? extends Number>> SUSANOO_SUMMON_COST = JUTSUS
            .comment("Chakra to summon or grow into each stage (share of max chakra).")
            .defineList("summonCost", List.of(0.10, 0.15, 0.20, 0.25, 0.35), o -> o instanceof Number);
    public static final ForgeConfigSpec.ConfigValue<List<? extends Number>> SUSANOO_DRAIN = JUTSUS
            .comment("Chakra it uses every second (share of max chakra).")
            .defineList("drainPerSecond", List.of(0.01, 0.015, 0.02, 0.025, 0.035), o -> o instanceof Number);
    public static final ForgeConfigSpec.ConfigValue<List<? extends Number>> SUSANOO_COMBO_DAMAGE = JUTSUS
            .comment("Damage of the first two swings of the left-click combo (the third does 1.5x). Ribcage has no combo.")
            .defineList("comboDamage", List.of(0, 10, 16, 22, 40), o -> o instanceof Number);
    public static final ForgeConfigSpec.ConfigValue<List<? extends Number>> SUSANOO_REACH = JUTSUS
            .comment("How far the combo reaches, in blocks.")
            .defineList("comboReach", List.of(0, 5, 7, 8, 16), o -> o instanceof Number);
    public static final ForgeConfigSpec.ConfigValue<List<? extends Number>> SUSANOO_SPECIAL_DAMAGE = JUTSUS
            .comment("Damage of the right-click special: ground slam, each magatama, chakra slash wave, giant slash wave.")
            .defineList("specialDamage", List.of(0, 18, 12, 35, 70), o -> o instanceof Number);
    public static final ForgeConfigSpec.ConfigValue<List<? extends Number>> SUSANOO_SPECIAL_COOLDOWN = JUTSUS
            .comment("Seconds between specials.").defineList("specialCooldown", List.of(0, 6, 8, 10, 15), o -> o instanceof Number);
    public static final ForgeConfigSpec.ConfigValue<List<? extends Number>> SUSANOO_SPECIAL_COST = JUTSUS
            .comment("Chakra each special costs (share of max chakra).")
            .defineList("specialCost", List.of(0, 0.05, 0.06, 0.08, 0.10), o -> o instanceof Number);
    public static final ForgeConfigSpec.DoubleValue SUSANOO_REGEN = JUTSUS
            .comment("Health it regains every second (share of max) once it hasn't been hit for regenDelaySeconds.")
            .defineInRange("regenPerSecond", 0.02, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue SUSANOO_REGEN_DELAY = JUTSUS.defineInRange("regenDelaySeconds", 5, 0, 600);
    public static final ForgeConfigSpec.DoubleValue SUSANOO_REGEN_COST = JUTSUS
            .comment("Chakra each second of healing costs (share of max chakra).").defineInRange("regenChakraPerSecond", 0.005, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue SUSANOO_BLOCK_FRONT = JUTSUS
            .comment("Sneaking blocks: less damage from hits in front (0.6 = 60% less).").defineInRange("blockFront", 0.6, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue SUSANOO_BLOCK_SHIELD = JUTSUS
            .comment("Armored stage: the shield blocks this much of a hit in front.").defineInRange("blockShield", 0.9, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue SUSANOO_BLOCK_WINGS = JUTSUS
            .comment("Perfect stage: the wings block this much of a hit from any side.").defineInRange("blockWings", 0.75, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue SUSANOO_AMATERASU_BURN = JUTSUS
            .comment("Amaterasu burns this share of the Susanoo's max health every second.").defineInRange("amaterasuBurn", 0.04, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue SUSANOO_SHATTER_COOLDOWN = JUTSUS
            .comment("Seconds before you can summon again after it shatters (0 health).").defineInRange("shatterCooldown", 30, 0, 3600);
    public static final ForgeConfigSpec.IntValue SUSANOO_DISSOLVE_COOLDOWN = JUTSUS
            .comment("Seconds before you can summon again after releasing it or running out of chakra.").defineInRange("releaseCooldown", 5, 0, 3600);
    public static final ForgeConfigSpec.BooleanValue SUSANOO_BREAK_BLOCKS = JUTSUS
            .comment("Let the ground slam and slash waves break blocks (needs jutsuGriefing).").define("specialsBreakBlocks", false);
    static { JUTSUS.pop(); }

    // ---------------------------------------------------------------- Jinchuriki
    static { JUTSUS.comment("Jinchuriki: a tailed beast sealed in a player (/jinchuriki give <player> <beast>). Its power comes out",
            "first as rage forms (1 to 6 tails) the jinchuriki can't control; time spent in the highest one earns the EXP for the",
            "next (2 tails: 400, 3: 600, then 200 more each). After the last rage form it's tamed: a chakra cloak of its own.").push("jinchuriki"); }
    public static final ForgeConfigSpec.DoubleValue JIN_EXP_PER_SECOND = JUTSUS
            .comment("EXP earned per second in a form.").defineInRange("expPerSecond", 1.0, 0.01, 1000.0);
    public static final ForgeConfigSpec.IntValue JIN_EXP_STEP = JUTSUS
            .comment("EXP needed for each new form is this times its number (2 tails: 400, 3: 600, ...).").defineInRange("expStep", 200, 1, 100000);
    public static final ForgeConfigSpec.DoubleValue JIN_RAGE_SECONDS = JUTSUS
            .comment("How long a rage form lasts at one tail (it can't be stopped early)...").defineInRange("rageSeconds", 30.0, 5.0, 600.0);
    public static final ForgeConfigSpec.DoubleValue JIN_RAGE_PER_TAIL = JUTSUS
            .comment("...and how much longer with each extra tail.").defineInRange("rageSecondsPerTail", 8.0, 0.0, 600.0);
    public static final ForgeConfigSpec.DoubleValue JIN_COOLDOWN = JUTSUS
            .comment("Seconds before the beast can be called on again after a form ends.").defineInRange("cooldownSeconds", 60.0, 0.0, 3600.0);
    public static final ForgeConfigSpec.DoubleValue JIN_RAGE_DAMAGE = JUTSUS
            .comment("Damage of a raging jinchuriki's blows: this plus 2 per tail.").defineInRange("rageDamage", 4.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.DoubleValue JIN_CLOAK_DRAIN = JUTSUS
            .comment("Chakra the chakra cloak burns per second (share of max chakra).").defineInRange("cloakDrain", 0.01, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue JIN_BOMB_DAMAGE = JUTSUS
            .comment("Tailed Beast Bomb damage.")
            .defineInRange("bombDamage", 18.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.BooleanValue JIN_ONE_PER_BEAST = JUTSUS
            .comment("Only one jinchuriki per beast at a time (giving a taken beast to someone else takes it from its holder).")
            .define("onePerBeast", true);
    static { JUTSUS.pop(); }

    static { JUTSUS.comment("Ninja tools: smoke bombs and wire traps.").push("ninjaTools"); }
    public static final ForgeConfigSpec.DoubleValue SMOKE_RADIUS = JUTSUS
            .comment("Radius of a smoke bomb's cloud (blocks).").defineInRange("smokeRadius", 4.5, 1.0, 32.0);
    public static final ForgeConfigSpec.IntValue SMOKE_SECONDS = JUTSUS
            .comment("How long a smoke bomb's cloud lasts.").defineInRange("smokeSeconds", 8, 1, 120);
    public static final ForgeConfigSpec.IntValue WIRE_HOLD_SECONDS = JUTSUS
            .comment("How long a wire trap holds whoever runs into it.").defineInRange("wireHoldSeconds", 3, 1, 60);
    public static final ForgeConfigSpec.IntValue WIRE_SECONDS = JUTSUS
            .comment("How long a wire trap that's never sprung lasts before it rusts away.").defineInRange("wireLifetimeSeconds", 600, 10, 86400);
    static { JUTSUS.pop(); }

    static { JUTSUS.comment("Flying Thunder God: the Flying Thunder God kunai marks places (right-click a block to seal it, or throw",
            "the kunai: it marks where it sticks, and anyone it hits). Right-click toward a mark or pick it in the ninja menu",
            "to teleport there.").push("flyingThunderGod"); }
    public static final ForgeConfigSpec.IntValue FTG_MAX_MARKS = JUTSUS
            .comment("How many marks a player can have at once (the oldest goes when a new one is made).").defineInRange("maxMarks", 12, 1, 64);
    public static final ForgeConfigSpec.DoubleValue FTG_COST = JUTSUS
            .comment("Chakra per teleport (share of max chakra).").defineInRange("chakraCost", 0.05, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue FTG_COOLDOWN = JUTSUS
            .comment("Ticks between teleports.").defineInRange("cooldownTicks", 10, 0, 1200);
    public static final ForgeConfigSpec.IntValue FTG_AIM_RANGE = JUTSUS
            .comment("How far away a mark can be to teleport to it by right-clicking toward it (the ninja menu has no limit).")
            .defineInRange("aimRange", 256, 8, 4096);
    public static final ForgeConfigSpec.IntValue FTG_TARGET_SECONDS = JUTSUS
            .comment("How long the mark on a creature or player lasts.").defineInRange("targetMarkSeconds", 120, 5, 36000);
    public static final ForgeConfigSpec.BooleanValue FTG_CROSS_DIMENSION = JUTSUS
            .comment("Allow teleporting to a mark in another dimension (from the ninja menu).").define("crossDimension", false);
    public static final ForgeConfigSpec.ConfigValue<String> FTG_MIN_RANK = JUTSUS
            .comment("Lowest ninja rank that can use it: genin, chunin, jonin, anbu or sannin.").define("minRank", "genin");
    static { JUTSUS.pop(); }

    // the [jutsu.<id>] sections are added by jutsusSpec(), once every jutsu is registered

    // ================================================================================================ Weapons.toml

    static { WEAPONS.comment("Total attack damage of each ninja weapon (what the tooltip shows; Kenjutsu adds on top).").push("damage"); }
    public static final ForgeConfigSpec.DoubleValue ZABUZA_DAMAGE = WEAPONS.defineInRange("kubikiribochoDamage", 32.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue SAMEHADA_DAMAGE = WEAPONS.defineInRange("samehadaDamage", 34.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue HIDAN_SCYTHE_DAMAGE = WEAPONS.defineInRange("hidanScytheDamage", 24.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue SWORD_OF_FIRE_DAMAGE = WEAPONS.defineInRange("swordOfFireDamage", 19.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue SHAKUJO_DAMAGE = WEAPONS.defineInRange("shakujoDamage", 17.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue KUSANAGI_DAMAGE = WEAPONS.defineInRange("kusanagiDamage", 15.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue KATANA_DAMAGE = WEAPONS.defineInRange("katanaDamage", 11.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue KABUTOWARI_DAMAGE = WEAPONS.defineInRange("kabutowariDamage", 26.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue GUNBAI_DAMAGE = WEAPONS.defineInRange("gunbaiDamage", 18.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue KIBA_DAMAGE = WEAPONS.defineInRange("kibaDamage", 16.0, 1.0, 10000.0);
    static { WEAPONS.pop(); }

    static { WEAPONS.push("abilities"); }
    public static final ForgeConfigSpec.DoubleValue SAMEHADA_STEAL = WEAPONS
            .comment("Chakra Samehada steals from a player it hits.").defineInRange("samehadaChakraSteal", 10.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue SAMEHADA_FEED = WEAPONS
            .comment("Chakra Samehada gives its wielder on every hit, on top of what it steals.").defineInRange("samehadaChakraFeed", 5.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue KUSANAGI_CHAKRA_PERCENT = WEAPONS
            .comment("Kusanagi: share of your max chakra each Chidori Flow stun costs (0.1 = 10%). Hits during the stun",
                     "cooldown are ordinary sword hits and cost nothing.")
            .defineInRange("kusanagiStunChakraPercent", 0.10, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue KUSANAGI_STUN_COOLDOWN = WEAPONS
            .comment("Kusanagi: seconds before Chidori Flow can stun again.").defineInRange("kusanagiStunCooldownSeconds", 15, 0, 3600);
    public static final ForgeConfigSpec.DoubleValue HIDAN_LIFESTEAL = WEAPONS
            .comment("Part of the damage dealt with Hidan's scythe that heals the wielder (0.2 = 20%).").defineInRange("hidanScytheLifesteal", 0.2, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue KABUTOWARI_PIERCE = WEAPONS
            .comment("Kabutowari: share of the protection armor would give that it ignores (0.4 = armor stops 40% less).")
            .defineInRange("kabutowariArmorPierce", 0.4, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue KABUTOWARI_SHIELD_TICKS = WEAPONS
            .comment("Kabutowari: ticks a shield (or a guarding Gunbai) it hits can't be used (20 = 1 s).")
            .defineInRange("kabutowariShieldBreakTicks", 100, 0, 6000);
    public static final ForgeConfigSpec.DoubleValue KIBA_ARC_SHARE = WEAPONS
            .comment("Kiba: share of a hit's damage the lightning deals to each nearby enemy it jumps to.")
            .defineInRange("kibaArcShare", 0.3, 0.0, 10.0);
    public static final ForgeConfigSpec.IntValue KIBA_ARC_TARGETS = WEAPONS.defineInRange("kibaArcTargets", 2, 0, 20);
    public static final ForgeConfigSpec.DoubleValue KIBA_ARC_COST = WEAPONS
            .comment("Chakra each Kiba hit spends on its lightning (no chakra: no lightning).").defineInRange("kibaArcCost", 3.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue KIBA_STRIKE_COST = WEAPONS
            .comment("Kiba right-click: chakra to call down lightning where you look.").defineInRange("kibaStrikeCost", 15.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue KIBA_STRIKE_DAMAGE = WEAPONS.defineInRange("kibaStrikeDamage", 12.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.IntValue KIBA_STRIKE_COOLDOWN = WEAPONS.defineInRange("kibaStrikeCooldownSeconds", 8, 0, 3600);
    static { WEAPONS.pop(); }

    // ================================================================================================ Food.toml

    static { FOOD.push("food"); }
    public static final ForgeConfigSpec.DoubleValue CHAKRA_PILL_RESTORE = FOOD
            .comment("Chakra a Chakra Pill restores when eaten.").defineInRange("chakraPillRestore", 50.0, 0.0, 100000.0);
    public static final ForgeConfigSpec.IntValue EXP_BOTTLE_XP = FOOD
            .comment("Ninja XP one Ninja EXP Bottle gives.").defineInRange("expBottleXp", 100, 0, 1000000);
    static { FOOD.pop(); }

    // ================================================================================================ Stats.toml

    // ---------------------------------------------------------------- chakra
    static { STATS.push("chakra"); }
    public static final ForgeConfigSpec.DoubleValue CHAKRA_REGEN_MULTIPLIER = STATS
            .comment("Multiplier applied to natural chakra regeneration and charging.").defineInRange("regenMultiplier", 1.0, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue BASE_CHAKRA_REGEN = STATS
            .comment("Chakra regenerated per second before bonuses (clans can raise it).").defineInRange("baseRegenPerSecond", 2.0, 0.0, 100.0);
    public static final ForgeConfigSpec.IntValue CHAKRA_PER_NINJUTSU = STATS
            .comment("Max chakra gained per Ninjutsu stat point.").defineInRange("chakraPerNinjutsuPoint", 5, 0, 1000);
    public static final ForgeConfigSpec.DoubleValue NINJUTSU_REGEN_PER_POINT = STATS
            .comment("Extra chakra regenerated per second per Ninjutsu point (0 to disable).").defineInRange("ninjutsuRegenPerPoint", 0.02, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue NINJUTSU_DAMAGE_PER_POINT = STATS
            .comment("Extra jutsu damage per Ninjutsu point, for every jutsu (0.005: 100 Ninjutsu = +50% damage, 200 = +100%).",
                     "0 turns it off.").defineInRange("ninjutsuDamagePerPoint", 0.005, 0.0, 1.0);
    static { STATS.pop(); }

    // ---------------------------------------------------------------- leveling
    static { STATS.push("leveling"); }
    public static final ForgeConfigSpec.IntValue XP_BASE = STATS
            .comment("XP needed to go from level 1 to 2.").defineInRange("xpBase", 100, 1, 1000000);
    public static final ForgeConfigSpec.IntValue XP_PER_LEVEL = STATS
            .comment("Extra XP needed for each level after that, see xpGrowth.")
            .defineInRange("xpPerLevel", 50, 0, 1000000);
    public static final ForgeConfigSpec.DoubleValue XP_GROWTH = STATS
            .comment("Makes every level harder than the last: level N needs xpBase + (N-1) * xpPerLevel + (N-1)^2 * xpGrowth XP.",
                     "With the defaults: level 10 needs 611 XP, level 50 about 4,400, level 100 about 12,400, level 300 about",
                     "82,000 and level 500 about 211,000. 0 = the old straight line.")
            .defineInRange("xpGrowth", 0.75, 0.0, 1000.0);
    public static final ForgeConfigSpec.IntValue STAT_POINTS_PER_LEVEL = STATS.defineInRange("statPointsPerLevel", 4, 0, 100);
    public static final ForgeConfigSpec.IntValue RYO_PER_LEVEL_UP = STATS.defineInRange("ryoPerLevelUp", 250, 0, 1000000);
    public static final ForgeConfigSpec.IntValue MOB_KILL_XP = STATS
            .comment("Ninja XP for killing a hostile mob (XP boosts multiply it).").defineInRange("mobKillXp", 5, 0, 1000000);
    public static final ForgeConfigSpec.BooleanValue MOB_XP_ALL_MOBS = STATS
            .comment("If true, every mob gives mobKillXp (animals too), not just hostile ones.").define("mobXpFromAllMobs", false);
    static { STATS.pop(); }

    // ---------------------------------------------------------------- ranks
    static { STATS.comment("Highest level each rank can reach. A Kage (or /shinobi rank) promotes players.").push("ranks"); }
    public static final ForgeConfigSpec.IntValue GENIN_LEVEL_CAP = STATS.defineInRange("geninLevelCap", 75, 1, 100000);
    public static final ForgeConfigSpec.IntValue CHUNIN_LEVEL_CAP = STATS.defineInRange("chuninLevelCap", 150, 1, 100000);
    public static final ForgeConfigSpec.IntValue JONIN_LEVEL_CAP = STATS.defineInRange("joninLevelCap", 250, 1, 100000);
    public static final ForgeConfigSpec.IntValue ANBU_LEVEL_CAP = STATS.defineInRange("anbuLevelCap", 400, 1, 100000);
    public static final ForgeConfigSpec.IntValue SANNIN_LEVEL_CAP = STATS.defineInRange("sanninLevelCap", 500, 1, 100000);
    public static final ForgeConfigSpec.BooleanValue NO_CAP_FROM_ANBU = STATS
            .comment("If true, Anbu (and every rank above) has no level cap at all, and the two caps above are ignored.")
            .define("noLevelCapFromAnbu", true);
    static { STATS.pop(); }

    // ---------------------------------------------------------------- stats
    static { STATS.push("stats"); }
    public static final ForgeConfigSpec.IntValue SPEED_CAP = STATS
            .comment("Speed is the only stat with a cap.").defineInRange("speedCap", 50, 1, 10000);
    public static final ForgeConfigSpec.DoubleValue HEALTH_PER_MEDICAL = STATS
            .comment("Max health per Medical point (2 = one heart).").defineInRange("healthPerMedicalPoint", 1.0, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue SPEED_PER_POINT = STATS
            .comment("Movement speed bonus per Speed point (0.01 = +1%).").defineInRange("speedPerPoint", 0.01, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue TAIJUTSU_PER_POINT = STATS
            .comment("Extra fist damage per Taijutsu point.").defineInRange("taijutsuDamagePerPoint", 0.5, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue KENJUTSU_PER_POINT = STATS
            .comment("Extra sword damage per Kenjutsu point.").defineInRange("kenjutsuDamagePerPoint", 0.4, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue GENJUTSU_PER_POINT = STATS
            .comment("Genjutsu bonus per point: longer illusions/binds, stronger Amaterasu, better Sharingan dodge (0.02 = +2%).")
            .defineInRange("genjutsuBonusPerPoint", 0.02, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue SENJUTSU_PER_POINT = STATS
            .comment("Max Senjutsu (natural energy) per Senjutsu point.").defineInRange("senjutsuPerPoint", 10, 0, 1000);
    public static final ForgeConfigSpec.IntValue RESET_COST_BASE = STATS
            .comment("Ryo cost to reset stats = base + perLevel * level.").defineInRange("statResetCostBase", 500, 0, 100000000);
    public static final ForgeConfigSpec.IntValue RESET_COST_PER_LEVEL = STATS.defineInRange("statResetCostPerLevel", 100, 0, 100000000);
    static { STATS.pop(); }

    // ---------------------------------------------------------------- senjutsu
    static { STATS.push("senjutsu"); }
    public static final ForgeConfigSpec.DoubleValue SENJUTSU_GATHER_RATE = STATS
            .comment("Natural energy gathered per second while charging chakra and standing still.").defineInRange("gatherPerSecond", 4.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.DoubleValue SAGE_MODE_DRAIN = STATS
            .comment("Senjutsu drained per second in Sage Mode.").defineInRange("sageModeDrainPerSecond", 2.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.IntValue SAGE_MODE_MIN = STATS
            .comment("Senjutsu needed to enter Sage Mode.").defineInRange("sageModeMinimum", 20, 0, 100000);
    public static final ForgeConfigSpec.DoubleValue SAGE_MODE_JUTSU_BONUS = STATS
            .comment("Extra jutsu damage in Sage Mode (0.25 = +25%).").defineInRange("sageModeJutsuBonus", 0.25, 0.0, 10.0);
    static { STATS.pop(); }

    // ================================================================================================ Spawn weights and chances.toml

    // ---------------------------------------------------------------- ninja bandits
    static { SPAWNS.push("bandits"); }
    public static final ForgeConfigSpec.IntValue BANDIT_SPAWN_WEIGHT = SPAWNS
            .comment("How often Ninja Bandits spawn in the Overworld at night and in the dark, compared with other monsters",
                     "(a zombie is 100). 0 = never. Needs a server restart.")
            .defineInRange("spawnWeight", 10, 0, 1000);
    public static final ForgeConfigSpec.IntValue BANDIT_GROUP_MIN = SPAWNS.defineInRange("groupMin", 1, 1, 16);
    public static final ForgeConfigSpec.IntValue BANDIT_GROUP_MAX = SPAWNS.defineInRange("groupMax", 3, 1, 16);
    public static final ForgeConfigSpec.IntValue BANDIT_RYO_MIN = SPAWNS
            .comment("Ryo a defeated bandit drops (a random amount between min and max).").defineInRange("ryoDropMin", 100, 0, 1000000);
    public static final ForgeConfigSpec.IntValue BANDIT_RYO_MAX = SPAWNS.defineInRange("ryoDropMax", 400, 0, 1000000);
    static { SPAWNS.pop(); }

    // ---------------------------------------------------------------- clan rolls
    static { SPAWNS.push("clanChances"); }
    public static final ForgeConfigSpec.DoubleValue COMMON_CLAN_WEIGHT = SPAWNS
            .comment("How likely each clan is on a /clanroll. Every clan of a tier has this weight; a clan's chance is its",
                    "weight divided by the total of all clans (19 common, 7 uncommon, 3 rare, 1 mythic).")
            .defineInRange("commonWeight", 6.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue UNCOMMON_CLAN_WEIGHT = SPAWNS.defineInRange("uncommonWeight", 3.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue RARE_CLAN_WEIGHT = SPAWNS
            .comment("Uchiha, Senju, Uzumaki.").defineInRange("rareWeight", 1.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue MYTHIC_CHANCE = SPAWNS
            .comment("Chance per /clanroll of the Mythic Otsutsuki clan, checked before the weights above",
                    "(0.00001 = 1 in 100,000).").defineInRange("mythicChance", 0.00001, 0.0, 1.0);
    static { SPAWNS.pop(); }

    // ---------------------------------------------------------------- kekkei genkai drops
    static { SPAWNS.comment("Kekkei genkai anyone can gain from DNA (right-click to awaken it; it comes with all its jutsu).",
            "Kekkei genkai: wood, ice, magnet, bone, sealing, sharingan, byakugan, rinnegan.",
            "There is also DNA of each chakra nature (fire, water, wind, lightning, earth, yin yang), which unlocks that release.")
            .push("kekkeiGenkaiDrops"); }
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DNA_DROPS = SPAWNS
            .comment("Which mobs drop DNA, as \"mob id=chance\" (chance per kill, 0-1). Use \"*\" for every hostile mob.",
                     "The DNA is a random one of all the natures and kekkei genkai. Only kills by players count.")
            .defineList("dnaDrops", List.of("shinobiarts:ninja_bandit=0.02", "minecraft:evoker=0.05", "minecraft:wither_skeleton=0.01",
                    "minecraft:warden=0.5", "minecraft:wither=1.0", "minecraft:ender_dragon=1.0"), Config::dropEntry);
    public static final ForgeConfigSpec.DoubleValue PLAYER_DNA_CHANCE = SPAWNS
            .comment("Chance that a player killed by another player drops the DNA of one of their own kekkei genkai.")
            .defineInRange("playerDnaChance", 0.25, 0.0, 1.0);
    static { SPAWNS.pop(); }

    // ================================================================================================ General.toml

    // ---------------------------------------------------------------- pvp
    static { GENERAL.push("pvp"); }
    public static final ForgeConfigSpec.BooleanValue PVP_REWARDS = GENERAL
            .comment("Give XP and Ryo for fighting and defeating other players.").define("enabled", true);
    public static final ForgeConfigSpec.IntValue PVP_KILL_XP_BASE = GENERAL.defineInRange("killXpBase", 50, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_KILL_XP_PER_LEVEL = GENERAL
            .comment("Extra kill XP per level of the defeated player.").defineInRange("killXpPerVictimLevel", 10, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_KILL_RYO_BASE = GENERAL.defineInRange("killRyoBase", 50, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_KILL_RYO_PER_LEVEL = GENERAL.defineInRange("killRyoPerVictimLevel", 5, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_HIT_XP = GENERAL
            .comment("XP for each hit landed on another player.").defineInRange("hitXp", 2, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_HIT_XP_PER_MINUTE = GENERAL
            .comment("Most XP a player can earn from hits per minute.").defineInRange("hitXpPerMinute", 30, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_MIN_LEVEL_GAP = GENERAL
            .comment("Level-gap rule (works both ways): no PvP rewards when the two players' levels differ by more than",
                     "max(minLevelGap, lowerLevel * levelGapPercent). With the defaults, level 1 and level 12+ players",
                     "get nothing from fighting each other; a level 100 player can be rewarded against levels 50-150.")
            .defineInRange("minLevelGap", 10, 0, 100000);
    public static final ForgeConfigSpec.DoubleValue PVP_LEVEL_GAP_PERCENT = GENERAL.defineInRange("levelGapPercent", 0.5, 0.0, 100.0);
    public static final ForgeConfigSpec.IntValue PVP_SAME_VICTIM_COOLDOWN = GENERAL
            .comment("Minutes before defeating the same player gives rewards again.").defineInRange("sameVictimCooldownMinutes", 10, 0, 100000);
    public static final ForgeConfigSpec.BooleanValue PVP_REQUIRE_ACTIVITY = GENERAL
            .comment("Only reward kills of players who were moving or fighting shortly before (stops AFK alt farming).")
            .define("requireVictimActivity", true);
    public static final ForgeConfigSpec.IntValue PVP_ACTIVITY_WINDOW = GENERAL.defineInRange("activityWindowSeconds", 30, 1, 3600);
    static { GENERAL.pop(); }

    // ---------------------------------------------------------------- combat tag
    static { GENERAL.push("combat"); }
    public static final ForgeConfigSpec.IntValue COMBAT_TAG_SECONDS = GENERAL
            .comment("Seconds a player stays in combat after hitting or being hit by another player (0 = off).")
            .defineInRange("tagSeconds", 60, 0, 3600);
    public static final ForgeConfigSpec.BooleanValue COMBAT_LOG_KILL = GENERAL
            .comment("Players who log out while in combat are killed (their opponent gets the kill).").define("killOnLogout", true);
    public static final ForgeConfigSpec.BooleanValue COMBAT_BLOCK_COMMANDS = GENERAL
            .comment("Block every command for players in combat.").define("blockCommands", true);
    static { GENERAL.pop(); }

    // ---------------------------------------------------------------- villages & quests
    static { GENERAL.push("villages"); }
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> VILLAGES = GENERAL
            .comment("Villages as \"id:Display Name\". Members get the permission shinobiarts.village.<id>, Kages",
                     "shinobiarts.village.<id>.kage (e.g. with LuckPerms), or use /shinobi village and /shinobi kage.",
                     "New villages need a server restart for their permissions to exist.")
            .defineList("villages", List.of("leaf:Hidden Leaf", "sand:Hidden Sand", "mist:Hidden Mist",
                    "cloud:Hidden Cloud", "stone:Hidden Stone"), o -> o instanceof String str && str.contains(":"));
    public static final ForgeConfigSpec.IntValue HOURLY_QUESTS = GENERAL.defineInRange("hourlyQuests", 2, 0, 10);
    public static final ForgeConfigSpec.IntValue DAILY_QUESTS = GENERAL.defineInRange("dailyQuests", 3, 0, 10);
    public static final ForgeConfigSpec.IntValue WEEKLY_QUESTS = GENERAL.defineInRange("weeklyQuests", 2, 0, 10);
    public static final ForgeConfigSpec.IntValue MONTHLY_QUESTS = GENERAL.defineInRange("monthlyQuests", 1, 0, 10);
    public static final ForgeConfigSpec.BooleanValue QUEST_SCROLLS = GENERAL
            .comment("Random quests also pay out a jutsu scroll: hourly D rank; daily C or B (chances of A and S below);",
                     "weekly B (better chances of A and S); monthly A (or S).").define("questScrolls", true);
    public static final ForgeConfigSpec.DoubleValue QUEST_DAILY_A = GENERAL.defineInRange("dailyScrollChanceA", 0.10, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue QUEST_DAILY_S = GENERAL.defineInRange("dailyScrollChanceS", 0.03, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue QUEST_WEEKLY_A = GENERAL.defineInRange("weeklyScrollChanceA", 0.30, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue QUEST_WEEKLY_S = GENERAL.defineInRange("weeklyScrollChanceS", 0.12, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue QUEST_MONTHLY_S = GENERAL.defineInRange("monthlyScrollChanceS", 0.40, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue KAGE_MAX_BOTTLES = GENERAL
            .comment("Most EXP bottles a Kage can offer as a quest reward.").defineInRange("kageQuestMaxBottles", 16, 0, 1000);
    public static final ForgeConfigSpec.IntValue KAGE_MAX_RYO = GENERAL
            .comment("Most Ryo a Kage can offer as a quest reward.").defineInRange("kageQuestMaxRyo", 5000, 0, 100000000);
    public static final ForgeConfigSpec.IntValue KAGE_MAX_QUESTS = GENERAL.defineInRange("kageQuestsPerVillage", 8, 1, 50);
    public static final ForgeConfigSpec.IntValue KAGE_QUEST_COOLDOWN = GENERAL
            .comment("Minutes a village's Kage must wait between posting two quests (0 = no wait).")
            .defineInRange("kageQuestCooldownMinutes", 60, 0, 100000);
    public static final ForgeConfigSpec.BooleanValue KAGE_PROMOTE_MAX = GENERAL
            .comment("If true, Kages can promote members up to Anbu; if false, up to Jonin.").define("kageCanPromoteToAnbu", false);
    public static final ForgeConfigSpec.BooleanValue SHOW_TITLES = GENERAL
            .comment("Show [Kage] and [Advisor] in front of player names in chat. Off by default (use a permissions plugin's",
                     "prefixes instead).").define("showKageTagInChat", false);
    public static final ForgeConfigSpec.BooleanValue CLAN_JUTSU_LOCKED = GENERAL
            .comment("If true, clan jutsu (Shadow Possession, Mind Body Transfer, Expansion, Human Bullet Tank...) can only be",
                     "learned by that clan. If false, anyone can learn them from the scroll. Kekkei genkai releases (Wood, Ice...)",
                     "still need the kekkei genkai either way.")
            .define("clanJutsuLockedToClan", true);
    public static final ForgeConfigSpec.BooleanValue SHOW_TITLES_TAB = GENERAL
            .comment("Also show [Kage] / [Advisor] in the player list (Tab). Off by default, so a permissions plugin's",
                     "prefixes (LuckPerms...) aren't doubled up.").define("showTitlesInTabList", false);
    static { GENERAL.pop(); }

    // ---------------------------------------------------------------- clans
    static { GENERAL.push("clans"); }
    public static final ForgeConfigSpec.IntValue CLAN_ROLLS = GENERAL
            .comment("How many times each player can use /clanroll (each use rolls a new clan). Afterwards they claim whichever",
                     "of the clans they rolled they like best (the chances are in Spawn weights and chances.toml).")
            .defineInRange("clanRolls", 2, 1, 100);
    public static final ForgeConfigSpec.BooleanValue ANNOUNCE_RARE_CLANS = GENERAL
            .comment("Tell the whole server when someone is born into a Rare or Mythic clan.").define("announceRareClans", true);
    static { GENERAL.pop(); }

    // ---------------------------------------------------------------- teams
    static { GENERAL.push("teams"); }
    public static final ForgeConfigSpec.IntValue TEAM_MAX = GENERAL.defineInRange("maxMembers", 4, 2, 64);
    static { GENERAL.pop(); }

    // ---------------------------------------------------------------- credits
    static { GENERAL.comment("The Credits page of the stats menu (J). One line per role: \"Role: Name, Name\". Lines without a",
            "colon are shown as they are. Edit these for your server's staff; players see them as soon as they join.").push("credits"); }
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> CREDITS = GENERAL
            .defineList("lines", List.of("Created by: You", "Staff: (add your staff in config/Naruto Generations/General.toml)",
                    "Thanks for playing Naruto Generations!"), o -> o instanceof String);
    static { GENERAL.pop(); }

    static { GENERAL.comment("The ninja shop (/shop). One line per thing for sale: \"category|item|count|price\" (price in Ryo for",
            "that many). Categories: tools, explosives, food, points. The item \"jutsu_points\" sells jutsu points.").push("shop"); }
    public static final ForgeConfigSpec.BooleanValue SHOP_ENABLED = GENERAL.define("shopEnabled", true);
    public static final ForgeConfigSpec.IntValue AUCTION_MAX_LISTINGS = GENERAL
            .comment("Auction house (/shop auction): how many items one player can have listed at once.")
            .defineInRange("auctionMaxListings", 5, 1, 100);
    public static final ForgeConfigSpec.IntValue AUCTION_MAX_HOURS = GENERAL
            .comment("Longest an auction can run, in hours.")
            .defineInRange("auctionMaxHours", 72, 1, 720);
    public static final ForgeConfigSpec.DoubleValue AUCTION_FEE = GENERAL
            .comment("Share of the final price kept by the auction house (0.05 = 5%).")
            .defineInRange("auctionFee", 0.05, 0.0, 0.9);
    public static final ForgeConfigSpec.IntValue BOUNTY_MIN = GENERAL
            .comment("Smallest bounty (Ryo) anyone can put on a player's head (/bounty, or the Bounties page of the ninja menu).")
            .defineInRange("bountyMinimum", 500, 1, Integer.MAX_VALUE);
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> SHOP_ITEMS = GENERAL
            .defineList("stock", List.of(
                    "tools|shinobiarts:kunai|16|120", "tools|shinobiarts:shuriken|16|120", "tools|shinobiarts:chakra_paper|1|300",
                    "tools|shinobiarts:blank_scroll|4|200", "tools|shinobiarts:forehead_protector|1|500",
                    "explosives|shinobiarts:explosive_tag|4|250", "explosives|shinobiarts:explosive_tag|16|900", "explosives|minecraft:tnt|4|400",
                    "food|shinobiarts:onigiri|8|80", "food|shinobiarts:dango|8|120", "food|shinobiarts:ichiraku_ramen|1|60",
                    "food|shinobiarts:yakiniku|4|200", "food|shinobiarts:katsudon|1|90", "food|shinobiarts:curry_of_life|1|150",
                    "food|shinobiarts:chakra_pill|4|600",
                    "points|jutsu_points|1|5000", "points|jutsu_points|5|22500"), o -> o instanceof String);
    static { GENERAL.pop(); }

    static { SPAWNS.comment("Using DNA: the chance it takes. When it doesn't, the body rejects it: Slowness and Nausea.").push("dnaUse"); }
    public static final ForgeConfigSpec.DoubleValue DNA_NATURE_CHANCE = SPAWNS
            .comment("Chance a chakra nature's DNA (Fire, Water, Wind, Lightning, Earth, Yin Yang) works.").defineInRange("natureDnaChance", 0.40, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue DNA_KEKKEI_GENKAI_CHANCE = SPAWNS
            .comment("Chance a kekkei genkai's DNA (Wood, Ice, Magnet, Bone, Sealing, the eyes, Lava, Storm, Boil, Scorch) works.")
            .defineInRange("kekkeiGenkaiDnaChance", 0.05, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue DNA_REJECT_SECONDS = SPAWNS
            .comment("How long Slowness and Nausea last when the DNA is rejected.").defineInRange("rejectSeconds", 300, 0, 36000);
    static { SPAWNS.pop(); }

    // ================================================================================================ the specs

    public static final ForgeConfigSpec GENERAL_SPEC = GENERAL.build();
    public static final ForgeConfigSpec WEAPONS_SPEC = WEAPONS.build();
    public static final ForgeConfigSpec FOOD_SPEC = FOOD.build();
    public static final ForgeConfigSpec STATS_SPEC = STATS.build();
    public static final ForgeConfigSpec SPAWNS_SPEC = SPAWNS.build();
    private static ForgeConfigSpec jutsusSpec;

    /** Each jutsu's own settings ([jutsu.<id>] in Jutsus.toml). */
    public record JutsuValues(ForgeConfigSpec.DoubleValue chakraCost, ForgeConfigSpec.DoubleValue damage,
                              ForgeConfigSpec.DoubleValue cooldownSeconds, ForgeConfigSpec.DoubleValue chargeSeconds,
                              ForgeConfigSpec.DoubleValue chargeMinPower, ForgeConfigSpec.DoubleValue chargeMaxPower) {}

    private static final Map<String, JutsuValues> PER_JUTSU = new LinkedHashMap<>();

    /**
     * Jutsus.toml. It's built here (not in a static field) because it has a section for every registered jutsu,
     * and the jutsu list must not be loaded while this class is still being set up.
     */
    public static synchronized ForgeConfigSpec jutsusSpec() {
        if (jutsusSpec == null) {
            JUTSUS.comment("Every jutsu's own settings. chakraCost is a share of max chakra (0.25 = 25%); damageMultiplier",
                    "scales all of its damage; chargeSeconds is how long a full charge takes, and chargeMinPower / chargeMaxPower",
                    "are its damage at a quick tap and at a full charge (only jutsu that deal damage charge).").push("jutsu");
            for (Jutsu j : Jutsus.all()) {
                JUTSUS.push(j.id());
                PER_JUTSU.put(j.id(), new JutsuValues(
                        JUTSUS.defineInRange("chakraCost", defaultCost(j.rank()), 0.0, 1.0),
                        JUTSUS.defineInRange("damageMultiplier", 1.0, 0.0, 100.0),
                        JUTSUS.defineInRange("cooldownSeconds", j.baseCooldown() / 20.0, 0.0, 3600.0),
                        JUTSUS.defineInRange("chargeSeconds", defaultCharge(j.rank()), 0.05, 60.0),
                        JUTSUS.defineInRange("chargeMinPower", 0.6, 0.0, 10.0),
                        JUTSUS.defineInRange("chargeMaxPower", 1.5, 0.0, 10.0)));
                JUTSUS.pop();
            }
            JUTSUS.pop();
            jutsusSpec = JUTSUS.build();
        }
        return jutsusSpec;
    }

    /** Chakra cost by rank (raised from the old flat 15%): D 18%, C 22%, B 27%, A 33%, S 40% of max chakra. */
    private static double defaultCost(JutsuRank rank) {
        return switch (rank) {
            case D -> 0.18;
            case C -> 0.22;
            case B -> 0.27;
            case A -> 0.33;
            case S -> 0.40;
        };
    }

    /** Seconds for a full charge by rank: 0.5 s for D up to 2.5 s for S. */
    private static double defaultCharge(JutsuRank rank) {
        return switch (rank) {
            case D -> 0.5;
            case C -> 1.0;
            case B -> 1.5;
            case A -> 2.0;
            case S -> 2.5;
        };
    }

    /** One jutsu's settings, or null if the jutsu has none (only before the specs are built). */
    @Nullable
    public static JutsuValues jutsu(String id) {
        return PER_JUTSU.get(id);
    }

    /** "mob id=chance" (or "*=chance"). */
    private static boolean dropEntry(Object o) {
        if (!(o instanceof String s)) return false;
        int eq = s.indexOf('=');
        if (eq <= 0) return false;
        try {
            double v = Double.parseDouble(s.substring(eq + 1).trim());
            return v >= 0 && v <= 1;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /** Registers every file (from the mod's constructor). */
    public static void register(net.minecraftforge.fml.ModLoadingContext context) {
        // common configs, so they sit in the server's own config folder; ConfigSyncPacket sends them to players
        net.minecraftforge.fml.config.ModConfig.Type type = net.minecraftforge.fml.config.ModConfig.Type.COMMON;
        context.registerConfig(type, GENERAL_SPEC, FOLDER + "General.toml");
        context.registerConfig(type, jutsusSpec(), FOLDER + "Jutsus.toml");
        context.registerConfig(type, WEAPONS_SPEC, FOLDER + "Weapons.toml");
        context.registerConfig(type, FOOD_SPEC, FOLDER + "Food.toml");
        context.registerConfig(type, STATS_SPEC, FOLDER + "Stats.toml");
        context.registerConfig(type, SPAWNS_SPEC, FOLDER + "Spawn weights and chances.toml");
    }

    // ---------------------------------------------------------------- safe readers
    public static boolean b(ForgeConfigSpec.BooleanValue v) {
        try {
            return v.get();
        } catch (RuntimeException e) {
            return v.getDefault();
        }
    }

    public static int i(ForgeConfigSpec.IntValue v) {
        try {
            return v.get();
        } catch (RuntimeException e) {
            return v.getDefault();
        }
    }

    public static double d(ForgeConfigSpec.DoubleValue v) {
        try {
            return v.get();
        } catch (RuntimeException e) {
            return v.getDefault();
        }
    }

    @SuppressWarnings("unchecked")
    public static List<String> villages() {
        return strings(VILLAGES);
    }

    @SuppressWarnings("unchecked")
    public static List<String> strings(ForgeConfigSpec.ConfigValue<List<? extends String>> v) {
        try {
            return (List<String>) v.get();
        } catch (RuntimeException e) {
            return (List<String>) v.getDefault();
        }
    }

    public static float f(ForgeConfigSpec.DoubleValue v) {
        return (float) d(v);
    }

    /** One stage's value (1-5) from a per-stage list, or {@code fallback} if the list is too short or unreadable. */
    public static double stage(ForgeConfigSpec.ConfigValue<List<? extends Number>> v, int stage, double fallback) {
        List<? extends Number> list;
        try {
            list = v.get();
        } catch (RuntimeException e) {
            list = v.getDefault();
        }
        return stage >= 1 && stage <= list.size() && list.get(stage - 1) != null ? list.get(stage - 1).doubleValue() : fallback;
    }

    private Config() {}
}
