package com.shinobiarts.world.realm;

import static com.shinobiarts.world.realm.RealmNoise.fbm;
import static com.shinobiarts.world.realm.RealmNoise.hash;

/**
 * Mount Myoboku: green valleys with a winding river, and everywhere tall rock spires with pines on their tops, some
 * pouring waterfalls into pools at their feet. Every so often (always at the arrival point) a toad village on a
 * levelled plateau: a five-storey pagoda in the middle of a stone plaza, four smaller pagodas around it, a torii gate
 * and a lantern-lined path, a pond crossed by a red bridge, and giant stone toad statues (the mod's own design) — two
 * guarding the path and a huge one behind the great pagoda.
 */
public final class MyobokuShape extends RealmShape {
    public MyobokuShape() {
        super(192);
    }

    /** Height of the village plateau's surface (the block players walk on is at this y). */
    static final int PLATEAU = 70;
    /** Villages: one per cell of this size at most (always one at 0, 0). */
    static final int VILLAGE_CELL = 224;
    /** Flat out to this radius, then blends into the hills. */
    static final int FLAT = 54, BLEND = 34;
    static final int SPIRE_CELL = 38, PINE_CELL = 11;
    static final int SEA = 61;

    @Override
    public int[] arrival() {
        return new int[]{0, PLATEAU, -36};
    }

    // ---------------------------------------------------------------- villages

    /** The village centre of village cell (i, j), or null if that cell has none. */
    static int[] village(int i, int j) {
        if (i == 0 && j == 0) return new int[]{0, 0};
        if (hash(i, j, 7) > 0.45) return null;
        int x = i * VILLAGE_CELL + (int) ((hash(i, j, 8) - 0.5) * 80);
        int z = j * VILLAGE_CELL + (int) ((hash(i, j, 9) - 0.5) * 80);
        return new int[]{x, z};
    }

    /** Distance to the nearest village centre (and that centre in out[0..1]). */
    static double nearestVillage(int x, int z, int[] out) {
        int ci = Math.floorDiv(x + VILLAGE_CELL / 2, VILLAGE_CELL), cj = Math.floorDiv(z + VILLAGE_CELL / 2, VILLAGE_CELL);
        double best = Double.MAX_VALUE;
        for (int i = ci - 1; i <= ci + 1; i++) {
            for (int j = cj - 1; j <= cj + 1; j++) {
                int[] v = village(i, j);
                if (v == null) continue;
                double d = Math.hypot(x - v[0], z - v[1]);
                if (d < best) {
                    best = d;
                    if (out != null) {
                        out[0] = v[0];
                        out[1] = v[1];
                    }
                }
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- terrain

    /** The surface height of the ground (rivers and villages included, spires not). */
    static int ground(int x, int z) {
        double g = 67 + 9 * fbm(x, z, 150, 11) + 4 * fbm(x, z, 38, 12);
        double river = Math.abs(fbm(x + 3000, z - 1700, 260, 13));
        double vd = nearestVillage(x, z, null);
        double w = smooth((vd - FLAT) / BLEND);                   // 0 in the village, 1 outside
        if (river < 0.16 && w > 0) {
            double bank = smooth((0.16 - river) / 0.09);          // 0 at the edge of the valley, 1 in the channel
            double floor = river < 0.05 ? 57 + 3 * (river / 0.05) : SEA + 1;
            g = g + (floor - g) * bank * w;
        }
        g = PLATEAU + (g - PLATEAU) * w;
        return (int) Math.round(g);
    }

    /** The spire in spire cell (i, j): {x, z, radius, top}, or null. Never in or near a village. */
    static int[] spire(int i, int j) {
        if (hash(i, j, 21) > 0.36) return null;
        int x = i * SPIRE_CELL + (int) (hash(i, j, 22) * (SPIRE_CELL - 10)) + 5;
        int z = j * SPIRE_CELL + (int) (hash(i, j, 23) * (SPIRE_CELL - 10)) + 5;
        double vd = nearestVillage(x, z, null);
        if (vd < FLAT + 12) return null;
        int r = 4 + (int) (hash(i, j, 24) * 6);
        int g = ground(x, z);
        int top = Math.min(180, g + 28 + (int) (hash(i, j, 25) * 50) + (vd < FLAT + BLEND + 30 ? 20 : 0));
        return new int[]{x, z, r, top};
    }

    /** How wide the spire is at height y (craggy: wider at the foot, bulges and notches up the side). */
    static double spireRadius(int[] s, int y, double angle) {
        double t = (y - (s[3] - 60)) / 60.0;
        double base = s[2] * (1.25 - 0.35 * smooth(t));
        double crag = 0.18 * Math.sin(angle * 3 + y * 0.21 + s[0]) + 0.12 * Math.sin(angle * 7 - y * 0.37 + s[1]);
        return base * (1 + crag);
    }

    @Override
    protected void column(int x, int z, Chunk c) {
        int g = ground(x, z);
        for (int y = 0; y < g; y++) {
            int id = y >= g - 1 ? (g <= SEA ? GRAVEL : GRASS) : y >= g - 4 ? (g <= SEA ? GRAVEL : DIRT) : (y % 7 == 0 ? ANDESITE : STONE);
            c.set(x, y, z, id);
        }
        for (int y = g; y <= SEA; y++) c.set(x, y, z, WATER);

        // the spires
        int si = Math.floorDiv(x, SPIRE_CELL), sj = Math.floorDiv(z, SPIRE_CELL);
        for (int i = si - 1; i <= si + 1; i++) {
            for (int j = sj - 1; j <= sj + 1; j++) {
                int[] s = spire(i, j);
                if (s == null) continue;
                double dx = x + 0.5 - s[0], dz = z + 0.5 - s[1];
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > s[2] * 1.7) continue;
                double ang = Math.atan2(dz, dx);
                int top = s[3] - (int) (d * 0.6);                  // a rounded crown
                for (int y = Math.min(g, SEA) - 2; y <= top; y++) {
                    if (d <= spireRadius(s, y, ang)) {
                        int id = y >= top ? GRASS : y >= top - 2 ? DIRT : ((y / 3 + i + j) % 5 == 0 ? ANDESITE : (y % 11 == 0 ? MOSSY_COBBLE : STONE));
                        c.set(x, y, z, id);
                    }
                }
            }
        }

        // the village pond and plaza ground
        int[] v = new int[2];
        double vd = nearestVillage(x, z, v);
        if (vd < FLAT) {
            int lx = x - v[0], lz = z - v[1];
            double px = (lx - 38) / 8.0, pz = lz / 14.0;
            if (px * px + pz * pz <= 1) {
                c.set(x, PLATEAU - 1, z, WATER);
                c.set(x, PLATEAU - 2, z, WATER);
                c.set(x, PLATEAU - 3, z, GRAVEL);
            } else if (px * px + pz * pz <= 1.35) {
                c.set(x, PLATEAU - 1, z, MOSSY_COBBLE);
            }
            if (Math.abs(lx) <= 15 && lz >= -15 && lz <= 15) c.set(x, PLATEAU - 1, z, (lx + lz & 3) == 0 ? SMOOTH_STONE : POLISHED);
            if (Math.abs(lx) <= 1 && lz >= -46 && lz < -15) c.set(x, PLATEAU - 1, z, BRICKS);
            if (Math.abs(lx) == 2 && lz >= -46 && lz < -15) c.set(x, PLATEAU - 1, z, MOSSY_BRICKS);
        }
    }

    // ---------------------------------------------------------------- structures

    @Override
    protected void structures(Chunk c) {
        // waterfalls and the pines on top of the spires
        int si = Math.floorDiv(c.x0, SPIRE_CELL), sj = Math.floorDiv(c.z0, SPIRE_CELL);
        for (int i = si - 1; i <= si + 2; i++) {
            for (int j = sj - 1; j <= sj + 2; j++) {
                int[] s = spire(i, j);
                if (s == null) continue;
                int reach = s[2] * 2 + 8;
                if (!c.touches(s[0] - reach, s[1] - reach, s[0] + reach, s[1] + reach)) continue;
                conifer(c, s[0], s[3] + 1, s[1], 9 + (int) (hash(i, j, 26) * 8), 0);
                if (s[2] >= 6) conifer(c, s[0] + 2, s[3], s[1] - 2, 7, 0);
                if (hash(i, j, 27) < 0.55) waterfall(c, s, hash(i, j, 28) * Math.PI * 2);
            }
        }
        // pines in the valleys
        int pi = Math.floorDiv(c.x0, PINE_CELL), pj = Math.floorDiv(c.z0, PINE_CELL);
        for (int i = pi - 1; i <= pi + 2; i++) {
            for (int j = pj - 1; j <= pj + 2; j++) {
                if (hash(i, j, 31) > 0.55) continue;
                int x = i * PINE_CELL + (int) (hash(i, j, 32) * PINE_CELL), z = j * PINE_CELL + (int) (hash(i, j, 33) * PINE_CELL);
                if (!c.touches(x - 5, z - 5, x + 5, z + 5)) continue;
                int g = ground(x, z);
                if (g <= SEA + 1) continue;
                double vd = nearestVillage(x, z, null);
                if (vd < FLAT - 4 && !(vd > 44)) continue;
                if (insideSpire(x, z) || onApproach(x, z)) continue;
                conifer(c, x, g, z, 10 + (int) (hash(i, j, 34) * 10), 0);
            }
        }
        // the villages
        int vi = Math.floorDiv(c.x0 + VILLAGE_CELL / 2, VILLAGE_CELL), vj = Math.floorDiv(c.z0 + VILLAGE_CELL / 2, VILLAGE_CELL);
        for (int i = vi - 1; i <= vi + 1; i++) {
            for (int j = vj - 1; j <= vj + 1; j++) {
                int[] v = village(i, j);
                if (v != null && c.touches(v[0] - 70, v[1] - 70, v[0] + 70, v[1] + 70)) village(c, v[0], v[1]);
            }
        }
    }

    /** Kept clear in front of each village's gate, so the way in is open. */
    static boolean onApproach(int x, int z) {
        int[] v = new int[2];
        double d = nearestVillage(x, z, v);
        return d < 110 && Math.abs(x - v[0]) < 9 && z < v[1];
    }

    static boolean insideSpire(int x, int z) {
        int si = Math.floorDiv(x, SPIRE_CELL), sj = Math.floorDiv(z, SPIRE_CELL);
        for (int i = si - 1; i <= si + 1; i++) {
            for (int j = sj - 1; j <= sj + 1; j++) {
                int[] s = spire(i, j);
                if (s != null && Math.hypot(x - s[0], z - s[1]) < s[2] * 1.8 + 2) return true;
            }
        }
        return false;
    }

    /** A waterfall pouring off the top of a spire on the side facing {@code angle}, into a pool at its foot. */
    private static void waterfall(Chunk c, int[] s, double angle) {
        double ux = Math.cos(angle), uz = Math.sin(angle);
        int g = ground((int) (s[0] + ux * s[2] * 2.2), (int) (s[1] + uz * s[2] * 2.2));
        // find how far out the rock goes at each height so the water runs just outside it
        for (int y = s[3] - 1; y >= Math.min(g, SEA); y--) {
            double r = spireRadius(s, y, angle) + 0.9;
            for (int w = -1; w <= 1; w++) {
                int x = (int) Math.floor(s[0] + ux * r - uz * w), z = (int) Math.floor(s[1] + uz * r + ux * w);
                c.setIfAir(x, y, z, WATER);
            }
        }
        // the notch it pours from, and the pool
        int nx = (int) Math.floor(s[0] + ux * (s[2] * 0.7)), nz = (int) Math.floor(s[1] + uz * (s[2] * 0.7));
        c.box(nx - 1, s[3] - 1, nz - 1, nx + 1, s[3] - 1, nz + 1, WATER);
        int px = (int) Math.floor(s[0] + ux * (s[2] * 1.6 + 3)), pz = (int) Math.floor(s[1] + uz * (s[2] * 1.6 + 3));
        int pg = ground(px, pz);
        if (pg > SEA) c.ellipsoid(px + 0.5, pg, pz + 0.5, 4.5, 2.2, 4.5, WATER);
        c.cylinder(px + 0.5, pz + 0.5, pg + 1, pg + 4, 4.6, AIR);
    }

    /** A toad village around (vx, vz). */
    private static void village(Chunk c, int vx, int vz) {
        int y = PLATEAU;
        pagoda(c, vx, y, vz, 8, 5);
        int[][] small = {{-30, -24}, {30, -26}, {-34, 24}, {34, 32}};
        for (int[] s : small) pagoda(c, vx + s[0], y, vz + s[1], 4, 3);
        torii(c, vx, y, vz - 46, 4, 9);
        torii(c, vx, y, vz - 18, 3, 7);
        for (int k = -44; k <= -20; k += 6) {
            lanternPost(c, vx - 4, y, vz + k);
            lanternPost(c, vx + 4, y, vz + k);
        }
        // the guardian toads either side of the path, and the great toad behind the pagoda
        toad(c, vx - 16, y, vz - 30, 9, 1, 0);
        toad(c, vx + 16, y, vz - 30, 9, -1, 0);
        toad(c, vx, y, vz + 38, 18, 0, -1);
        // the bridge over the pond
        bridge(c, vx + 26, y, vz, vx + 50, y, vz, 3);
        // pines around the edge
        for (int k = 0; k < 14; k++) {
            double a = k * Math.PI * 2 / 14 + 0.2;
            int px = vx + (int) (Math.cos(a) * 49), pz = vz + (int) (Math.sin(a) * 49);
            if (Math.abs(px - vx) <= 9 && pz < vz) continue;       // keep the gate open
            conifer(c, px, y, pz, 13 + (k * 5) % 7, 0);
        }
    }

    /**
     * A giant stone toad (the mod's own design): squat body on a mossy plinth, a pale belly, a wide flat head with a
     * long mouth, two bulging yellow eyes, thick legs. {@code size} is roughly its height; it faces (fx, fz).
     */
    static void toad(Chunk c, int x, int base, int z, int s, int fx, int fz) {
        c.box(x - (int) (s * 0.95), base, z - (int) (s * 0.95), x + (int) (s * 0.95), base + Math.max(1, s / 6), z + (int) (s * 0.95), MOSSY_BRICKS);
        int b = base + Math.max(1, s / 6) + 1;
        Toad t = new Toad(c, x + 0.5, b, z + 0.5, s, fx, fz);
        t.el(-0.15, 0.5, 0, 0.78, 0.55, 0.72, TOAD);              // body
        t.el(-0.45, 0.3, 0.62, 0.5, 0.32, 0.24, TOAD_DARK);       // back legs
        t.el(-0.45, 0.3, -0.62, 0.5, 0.32, 0.24, TOAD_DARK);
        t.el(-0.1, 0.06, 0.78, 0.55, 0.1, 0.2, TOAD_DARK);        // back feet
        t.el(-0.1, 0.06, -0.78, 0.55, 0.1, 0.2, TOAD_DARK);
        t.el(0.3, 0.4, 0, 0.52, 0.38, 0.52, TOAD_BELLY);          // belly
        t.tube(0.45, 0.55, 0.42, 0.62, 0.0, 0.48, 0.14, TOAD_DARK); // front legs
        t.tube(0.45, 0.55, -0.42, 0.62, 0.0, -0.48, 0.14, TOAD_DARK);
        t.el(0.72, 0.04, 0.5, 0.2, 0.08, 0.2, TOAD_DARK);         // front feet
        t.el(0.72, 0.04, -0.5, 0.2, 0.08, 0.2, TOAD_DARK);
        t.el(0.42, 0.95, 0, 0.5, 0.34, 0.66, TOAD);               // head
        t.el(0.52, 0.86, 0, 0.44, 0.045, 0.6, BLACK);             // the mouth
        for (int side = -1; side <= 1; side += 2) {
            t.el(0.45, 1.25, side * 0.38, 0.2, 0.2, 0.2, TOAD);    // eye bumps
            t.el(0.55, 1.27, side * 0.38, 0.14, 0.14, 0.14, YELLOW_CLAY);
            t.el(0.66, 1.28, side * 0.38, 0.07, 0.1, 0.05, BLACK);
        }
        t.el(-0.2, 1.0, 0, 0.35, 0.12, 0.3, MOSS);                // moss on its back
    }

    /** Draws parts of a toad in its own frame: a = forward, u = up, s = to its side, all in units of its size. */
    private static final class Toad {
        final Chunk c;
        final double x, y, z, size;
        final int fx, fz;

        Toad(Chunk c, double x, double y, double z, double size, int fx, int fz) {
            this.c = c;
            this.x = x;
            this.y = y;
            this.z = z;
            this.size = size;
            this.fx = fx;
            this.fz = fz;
        }

        double wx(double a, double s) {
            return x + (fx * a - fz * s) * size;
        }

        double wz(double a, double s) {
            return z + (fz * a + fx * s) * size;
        }

        void el(double a, double u, double s, double ra, double ru, double rs, int id) {
            double rx = fx != 0 ? ra : rs, rz = fx != 0 ? rs : ra;
            c.ellipsoid(wx(a, s), y + u * size, wz(a, s), Math.max(0.6, rx * size), Math.max(0.6, ru * size), Math.max(0.6, rz * size), id);
        }

        void tube(double a0, double u0, double s0, double a1, double u1, double s1, double r, int id) {
            c.tube(wx(a0, s0), y + u0 * size, wz(a0, s0), wx(a1, s1), y + u1 * size, wz(a1, s1), Math.max(0.7, r * size), id);
        }
    }
}
