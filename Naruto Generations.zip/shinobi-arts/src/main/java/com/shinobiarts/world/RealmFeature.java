package com.shinobiarts.world;

import com.mojang.serialization.Codec;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.world.realm.RealmShape;
import net.minecraft.commands.arguments.blocks.BlockStateParser;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

import java.util.function.Supplier;

/**
 * Lays down one of the Sage realms (Mount Myoboku, Ryuchi Cave, Shikkotsu Forest) chunk by chunk as it generates: the
 * realm's dimension uses an empty flat generator and this feature, in its one biome, writes the whole chunk from the
 * realm's {@link RealmShape}. Each realm has its own feature, biome and dimension, so they never touch any other world.
 */
public class RealmFeature extends Feature<NoneFeatureConfiguration> {
    private final Supplier<RealmShape> shapeFactory;
    /** One work buffer per thread (chunks generate on several threads at once). */
    private final ThreadLocal<RealmShape.Chunk> buffer;
    private final ThreadLocal<RealmShape> shape;
    private static volatile BlockState[] states;

    public RealmFeature(Codec<NoneFeatureConfiguration> codec, Supplier<RealmShape> shapeFactory) {
        super(codec);
        this.shapeFactory = shapeFactory;
        this.shape = ThreadLocal.withInitial(shapeFactory);
        this.buffer = ThreadLocal.withInitial(() -> new RealmShape.Chunk(shapeFactory.get().height));
    }

    /** The palette as block states (parsed once). */
    static BlockState[] states() {
        BlockState[] s = states;
        if (s == null) {
            s = new BlockState[RealmShape.PALETTE.length];
            for (int i = 0; i < s.length; i++) {
                try {
                    s[i] = BlockStateParser.parseForBlock(BuiltInRegistries.BLOCK.asLookup(), RealmShape.PALETTE[i], false).blockState();
                } catch (Exception e) {
                    ShinobiArts.LOGGER.warn("Sage realm block {} could not be read, using stone", RealmShape.PALETTE[i]);
                    s[i] = Blocks.STONE.defaultBlockState();
                }
            }
            states = s;
        }
        return s;
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        int cx = ctx.origin().getX() >> 4, cz = ctx.origin().getZ() >> 4;
        RealmShape.Chunk c = buffer.get();
        shape.get().fill(cx, cz, c);
        BlockState[] palette = states();
        int minY = level.getMinBuildHeight(), maxY = level.getMaxBuildHeight();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        byte[] b = c.blocks;
        for (int y = Math.max(0, minY); y < Math.min(c.height, maxY); y++) {
            for (int z = 0; z < 16; z++) {
                for (int x = 0; x < 16; x++) {
                    int id = b[((y << 4) | z) << 4 | x] & 0xFF;
                    if (id == 0 || id >= palette.length) continue;
                    level.setBlock(m.set(c.x0 + x, y, c.z0 + z), palette[id], Block.UPDATE_CLIENTS);
                }
            }
        }
        return true;
    }
}
