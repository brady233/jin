package com.shinobiarts.registry;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.item.ChakraPaperItem;
import com.shinobiarts.item.ChakraPillItem;
import com.shinobiarts.item.CoinItem;
import com.shinobiarts.item.ExpBottleItem;
import com.shinobiarts.item.ExplosiveTagItem;
import com.shinobiarts.item.FrogWalletItem;
import com.shinobiarts.item.JutsuScrollItem;
import com.shinobiarts.item.NatureScrollItem;
import com.shinobiarts.item.NinjaWeaponItem;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.item.SharinganEyeItem;
import com.shinobiarts.item.SharinganItem;
import com.shinobiarts.item.XpBoostItem;
import com.shinobiarts.item.ThrownToolItem;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.ninja.ChakraNature;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ShinobiArts.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ShinobiArts.MODID);

    // ---------------------------------------------------------------- release scrolls (equip to use jutsu)
    public static final Map<ChakraNature, RegistryObject<Item>> RELEASES = new EnumMap<>(ChakraNature.class);

    static {
        for (ChakraNature release : ChakraNature.RELEASES) {
            RELEASES.put(release, ITEMS.register("release_" + release.id(),
                    () -> new ReleaseItem(release, new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON))));
        }
    }

    // ---------------------------------------------------------------- ninja tools & weapons
    /** Stackable throwing knife that is also a decent melee weapon (5 damage). */
    public static final RegistryObject<Item> KUNAI = ITEMS.register("kunai",
            () -> new ThrownToolItem(new Item.Properties().stacksTo(16), 2.0f, 12, 4.0, -2.0));
    /** Minato's three-pronged kunai: marks places and people for the Flying Thunder God Technique. */
    public static final RegistryObject<Item> FLYING_THUNDER_GOD_KUNAI = ITEMS.register("flying_thunder_god_kunai",
            () -> new com.shinobiarts.item.FlyingThunderGodKunaiItem(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> EXPLOSIVE_KUNAI = ITEMS.register("explosive_kunai",
            () -> new com.shinobiarts.item.NinjaToolItems.ExplosiveKunai(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> EIGHT_GATES = ITEMS.register("eight_gates",
            () -> new com.shinobiarts.item.EightGatesItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SMOKE_BOMB = ITEMS.register("smoke_bomb",
            () -> new com.shinobiarts.item.NinjaToolItems.SmokeBomb(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> WIRE_TRAP = ITEMS.register("wire_trap",
            () -> new com.shinobiarts.item.NinjaToolItems.WireTrap(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> SHURIKEN = ITEMS.register("shuriken",
            () -> new ThrownToolItem(new Item.Properties().stacksTo(32), 2.6f, 6, 0.0, 0.0));
    public static final RegistryObject<Item> EXPLOSIVE_TAG = ITEMS.register("explosive_tag",
            () -> new ExplosiveTagItem(new Item.Properties().stacksTo(16)));

    // Named weapons. Damage is in the "weapons" config section; attack speed shown = 4 + the value here.
    /** Zabuza's giant cleaver: 32 damage, slow, +1 reach, repairs itself on hit. */
    public static final RegistryObject<Item> ZABUZA_BLADE = ITEMS.register("zabuza_blade",
            () -> new NinjaWeaponItem(Tiers.NETHERITE, Config.ZABUZA_DAMAGE, -3.2f, 1.0, NinjaWeaponItem.Ability.SELF_REPAIR,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
    /** Kisame's living sword: 34 damage, slowest, +1 reach, eats chakra. */
    public static final RegistryObject<Item> SAMEHADA = ITEMS.register("samehada",
            () -> new NinjaWeaponItem(Tiers.NETHERITE, Config.SAMEHADA_DAMAGE, -3.3f, 1.0, NinjaWeaponItem.Ability.CHAKRA_DRAIN,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
    /** Hidan's triple-bladed scythe: 24 damage, +1.5 reach, heals on hit. */
    public static final RegistryObject<Item> HIDAN_SCYTHE = ITEMS.register("hidan_scythe",
            () -> new NinjaWeaponItem(Tiers.NETHERITE, Config.HIDAN_SCYTHE_DAMAGE, -3.1f, 1.5, NinjaWeaponItem.Ability.LIFESTEAL,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
    public static final RegistryObject<Item> SWORD_OF_FIRE = ITEMS.register("sword_of_fire",
            () -> new NinjaWeaponItem(Tiers.NETHERITE, Config.SWORD_OF_FIRE_DAMAGE, -2.8f, 0.0, NinjaWeaponItem.Ability.BURN,
                    new Item.Properties().rarity(Rarity.RARE).fireResistant()));
    public static final RegistryObject<Item> SHAKUJO = ITEMS.register("shakujo",
            () -> new NinjaWeaponItem(Tiers.DIAMOND, Config.SHAKUJO_DAMAGE, -2.9f, 1.5, NinjaWeaponItem.Ability.KNOCKBACK,
                    new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> KUSANAGI = ITEMS.register("kusanagi",
            () -> new NinjaWeaponItem(Tiers.DIAMOND, Config.KUSANAGI_DAMAGE, -2.2f, 0.0, NinjaWeaponItem.Ability.CHIDORI_FLOW,
                    new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> KATANA = ITEMS.register("katana",
            () -> new NinjaWeaponItem(Tiers.IRON, Config.KATANA_DAMAGE, -2.4f, 0.0, NinjaWeaponItem.Ability.NONE,
                    new Item.Properties()));

    /** Kabutowari, the Helmet Splitter: axe in the main hand, hammer in the off hand. 26 damage, breaks defences. */
    public static final RegistryObject<Item> KABUTOWARI = ITEMS.register("kabutowari",
            () -> new NinjaWeaponItem(Tiers.NETHERITE, Config.KABUTOWARI_DAMAGE, -3.2f, 0.5, NinjaWeaponItem.Ability.ARMOR_BREAK,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()).dualWield("kabutowari_hammer"));
    /** Madara's war fan: 18 damage, +1 reach, guards like a shield and sends jutsu back. */
    public static final RegistryObject<Item> GUNBAI = ITEMS.register("gunbai",
            () -> new NinjaWeaponItem(Tiers.NETHERITE, Config.GUNBAI_DAMAGE, -3.0f, 1.0, NinjaWeaponItem.Ability.REFLECT,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
    /** The twin lightning blades: one in each hand. 16 damage, fast, lightning. */
    public static final RegistryObject<Item> KIBA = ITEMS.register("kiba",
            () -> new NinjaWeaponItem(Tiers.DIAMOND, Config.KIBA_DAMAGE, -2.1f, 0.0, NinjaWeaponItem.Ability.LIGHTNING,
                    new Item.Properties().rarity(Rarity.RARE)).dualWield("kiba"));

    /** Worn in the helmet slot; the plate shows the wearer's village. */
    public static final RegistryObject<Item> FOREHEAD_PROTECTOR = ITEMS.register("forehead_protector",
            () -> new com.shinobiarts.item.ForeheadProtectorItem(new Item.Properties()));

    /** The swords of the Seven Ninja Swordsmen of the Mist, together in their own creative tab. */
    public static final List<RegistryObject<Item>> SEVEN_SWORDSMEN = List.of(ZABUZA_BLADE, SAMEHADA, KABUTOWARI, KIBA);
    /** Everything else in the "Ninja Tools" creative tab: tools first, then the other legendary weapons. */
    public static final List<RegistryObject<Item>> NINJA_TOOLS = List.of(KUNAI, FLYING_THUNDER_GOD_KUNAI, EXPLOSIVE_KUNAI, SHURIKEN, EXPLOSIVE_TAG, SMOKE_BOMB, WIRE_TRAP, FOREHEAD_PROTECTOR,
            KATANA, KUSANAGI, SWORD_OF_FIRE, SHAKUJO, GUNBAI, HIDAN_SCYTHE);

    // ---------------------------------------------------------------- consumables & progression
    public static final RegistryObject<Item> CHAKRA_PILL = ITEMS.register("chakra_pill",
            () -> new ChakraPillItem(new Item.Properties().stacksTo(16).food(new FoodProperties.Builder()
                    .nutrition(2).saturationMod(0.2f).alwaysEat().fast().build())));

    // food from the Hidden Leaf (sold in the /shop)
    public static final RegistryObject<Item> ICHIRAKU_RAMEN = food("ichiraku_ramen", 10, 1.0f, false, 1, 0.15f, true,
            () -> new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.REGENERATION, 100, 0));
    public static final RegistryObject<Item> DANGO = food("dango", 4, 0.6f, true, 16, 0f, false,
            () -> new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, 300, 0));
    public static final RegistryObject<Item> ONIGIRI = food("onigiri", 6, 0.7f, false, 16, 0.03f, false);
    public static final RegistryObject<Item> YAKINIKU = food("yakiniku", 9, 1.0f, false, 16, 0f, false,
            () -> new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.DAMAGE_BOOST, 400, 0));
    public static final RegistryObject<Item> CURRY_OF_LIFE = food("curry_of_life", 8, 0.9f, false, 1, 0.05f, true,
            () -> new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.REGENERATION, 200, 1),
            () -> new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.CONFUSION, 100, 0));
    public static final RegistryObject<Item> KATSUDON = food("katsudon", 10, 1.1f, false, 1, 0f, true,
            () -> new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.ABSORPTION, 1200, 0));

    @SafeVarargs
    private static RegistryObject<Item> food(String id, int nutrition, float saturation, boolean fast, int stack, float chakra, boolean bowl,
                                             java.util.function.Supplier<net.minecraft.world.effect.MobEffectInstance>... effects) {
        return ITEMS.register(id, () -> {
            FoodProperties.Builder b = new FoodProperties.Builder().nutrition(nutrition).saturationMod(saturation);
            if (fast) b.fast();
            if (effects.length > 0 || chakra > 0) b.alwaysEat();
            return new com.shinobiarts.item.NinjaFoodItem(new Item.Properties().stacksTo(stack).food(b.build()), chakra, bowl, effects);
        });
    }

    public static final RegistryObject<Item> CHAKRA_PAPER = ITEMS.register("chakra_paper",
            () -> new ChakraPaperItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> EXP_BOTTLE = ITEMS.register("exp_bottle",
            () -> new ExpBottleItem(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> BLANK_SCROLL = ITEMS.register("blank_scroll",
            () -> new com.shinobiarts.item.BlankScrollItem(new Item.Properties().stacksTo(16)));

    // ---------------------------------------------------------------- ryo
    public static final Map<CoinItem.Coin, RegistryObject<Item>> COINS = new EnumMap<>(CoinItem.Coin.class);

    static {
        for (CoinItem.Coin coin : CoinItem.Coin.values()) {
            COINS.put(coin, ITEMS.register(coin.id() + "_ryo", () -> new CoinItem(coin, new Item.Properties().stacksTo(64))));
        }
    }

    public static final RegistryObject<Item> NINJA_BANDIT_SPAWN_EGG = ITEMS.register("ninja_bandit_spawn_egg",
            () -> new net.minecraftforge.common.ForgeSpawnEggItem(ModEntities.NINJA_BANDIT, 0x2B2B33, 0xB0332B, new Item.Properties()));

    /** A Sharingan eye taken in PvP; right-click to implant it. */
    public static final RegistryObject<Item> SHARINGAN_EYE = ITEMS.register("sharingan_eye",
            () -> new SharinganEyeItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    // XP boost tokens: multiplier x duration
    public static final RegistryObject<Item> XP_BOOST_15_30 = ITEMS.register("xp_boost_1_5x_30m",
            () -> new XpBoostItem(1.5f, 30, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> XP_BOOST_15_60 = ITEMS.register("xp_boost_1_5x_60m",
            () -> new XpBoostItem(1.5f, 60, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> XP_BOOST_25_30 = ITEMS.register("xp_boost_2_5x_30m",
            () -> new XpBoostItem(2.5f, 30, new Item.Properties().stacksTo(16).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> XP_BOOST_25_60 = ITEMS.register("xp_boost_2_5x_60m",
            () -> new XpBoostItem(2.5f, 60, new Item.Properties().stacksTo(16).rarity(Rarity.RARE)));

    /** DNA of each kekkei genkai: right-click to awaken it (drops are set in "Spawn weights and chances.toml"). */
    public static final Map<com.shinobiarts.ninja.KekkeiGenkai, RegistryObject<Item>> DNA = new EnumMap<>(com.shinobiarts.ninja.KekkeiGenkai.class);

    /** DNA of each chakra nature (Fire, Water, Wind, Lightning, Earth, Yin Yang): right-click to unlock that release. */
    public static final Map<ChakraNature, RegistryObject<Item>> NATURE_DNA = new EnumMap<>(ChakraNature.class);

    static {
        for (ChakraNature nature : ChakraNature.NATURES) {
            NATURE_DNA.put(nature, ITEMS.register("dna_" + nature.id(),
                    () -> new com.shinobiarts.item.DnaItem(nature, new Item.Properties().stacksTo(16).rarity(Rarity.RARE))));
        }
        for (com.shinobiarts.ninja.KekkeiGenkai kg : com.shinobiarts.ninja.KekkeiGenkai.values()) {
            DNA.put(kg, ITEMS.register("dna_" + kg.id(),
                    () -> new com.shinobiarts.item.DnaItem(kg, new Item.Properties().stacksTo(16).rarity(Rarity.EPIC))));
        }
    }

    /** Every DNA vial: the six natures, then the kekkei genkai. */
    public static List<RegistryObject<Item>> allDna() {
        List<RegistryObject<Item>> out = new ArrayList<>();
        for (ChakraNature nature : ChakraNature.NATURES) out.add(NATURE_DNA.get(nature));
        for (com.shinobiarts.ninja.KekkeiGenkai kg : com.shinobiarts.ninja.KekkeiGenkai.values()) out.add(DNA.get(kg));
        return out;
    }

    /** Worn in the dojutsu slot: shows Sharingan eyes on the wearer's face. */
    public static final RegistryObject<Item> SHARINGAN = ITEMS.register("sharingan",
            () -> new SharinganItem(new Item.Properties().rarity(Rarity.EPIC)));
    /** The eyes you've switched on (V), shown in the dojutsu slot while they're on. Not in any creative tab. */
    public static final RegistryObject<Item> ACTIVE_EYE = ITEMS.register("active_eye",
            () -> new com.shinobiarts.item.ActiveEyeItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> FROG_WALLET = ITEMS.register("frog_wallet",
            () -> new FrogWalletItem(new Item.Properties().stacksTo(1)));

    // ---------------------------------------------------------------- scrolls (one per jutsu / nature)
    public static final Map<String, RegistryObject<Item>> JUTSU_SCROLLS = new LinkedHashMap<>();
    public static final Map<ChakraNature, RegistryObject<Item>> NATURE_SCROLLS = new EnumMap<>(ChakraNature.class);

    static {
        for (ChakraNature nature : ChakraNature.NATURES) {
            NATURE_SCROLLS.put(nature, ITEMS.register("nature_scroll_" + nature.id(),
                    () -> new NatureScrollItem(nature, new Item.Properties().stacksTo(16).rarity(Rarity.RARE))));
        }
        // Registered from D-rank to S-rank so the creative tab lists them in that order.
        List<Jutsu> byRank = new ArrayList<>(Jutsus.all());
        byRank.sort(Comparator.comparing(Jutsu::rank));
        for (Jutsu jutsu : byRank) {
            if (!Jutsus.hasScroll(jutsu)) continue;                  // kekkei genkai jutsu come with the kekkei genkai
            JUTSU_SCROLLS.put(jutsu.id(), ITEMS.register("scroll_" + jutsu.id(),
                    () -> new JutsuScrollItem(jutsu, new Item.Properties().stacksTo(16).rarity(rarityFor(jutsu)))));
        }
    }

    /**
     * The main tab, in sections: the releases, the nature training scrolls, the jutsu scrolls grouped by release (weakest
     * first in each), DNA (natures, then kekkei genkai), then everything else.
     */
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.shinobiarts"))
            .icon(() -> new ItemStack(RELEASES.get(ChakraNature.FIRE).get()))
            .displayItems((params, output) -> mainTabOrder().forEach(entry -> output.accept(entry.get())))
            .build());
    public static final RegistryObject<CreativeModeTab> TOOLS_TAB = TABS.register("ninja_tools", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.shinobiarts.ninja_tools"))
            .icon(() -> new ItemStack(KUNAI.get()))
            .withTabsBefore(TAB.getKey())
            .displayItems((params, output) -> NINJA_TOOLS.forEach(entry -> output.accept(entry.get())))
            .build());
    public static final RegistryObject<CreativeModeTab> FOOD_TAB = TABS.register("food", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.shinobiarts.food"))
            .icon(() -> new ItemStack(KATSUDON.get()))
            .withTabsBefore(TOOLS_TAB.getKey())
            .displayItems((params, output) -> ITEMS.getEntries().forEach(entry -> {
                if (entry.get().isEdible()) output.accept(entry.get());
            }))
            .build());
    public static final RegistryObject<CreativeModeTab> SWORDSMEN_TAB = TABS.register("seven_swordsmen", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.shinobiarts.seven_swordsmen"))
            .icon(() -> new ItemStack(ZABUZA_BLADE.get()))
            .withTabsBefore(FOOD_TAB.getKey())
            .displayItems((params, output) -> SEVEN_SWORDSMEN.forEach(entry -> output.accept(entry.get())))
            .build());

    /** Everything in the main tab, in order (each item once; tools, swords and the switched-on eyes left out). */
    private static List<RegistryObject<Item>> mainTabOrder() {
        List<RegistryObject<Item>> out = new ArrayList<>();
        for (ChakraNature release : ChakraNature.RELEASES) out.add(RELEASES.get(release));                  // releases
        for (ChakraNature nature : ChakraNature.NATURES) out.add(NATURE_SCROLLS.get(nature));               // nature scrolls
        for (ChakraNature release : ChakraNature.RELEASES) {                                                 // jutsu scrolls
            List<Jutsu> group = new ArrayList<>();
            for (Jutsu j : Jutsus.all()) {
                if (j.release() == release) group.add(j);
            }
            group.sort(Comparator.comparing(Jutsu::rank));
            for (Jutsu j : group) if (JUTSU_SCROLLS.containsKey(j.id())) out.add(JUTSU_SCROLLS.get(j.id()));
        }
        out.addAll(allDna());                                                                                // DNA
        for (RegistryObject<Item> entry : ITEMS.getEntries()) {                                              // the rest
            if (!out.contains(entry) && !NINJA_TOOLS.contains(entry) && !SEVEN_SWORDSMEN.contains(entry) && entry != ACTIVE_EYE
                    && !entry.get().isEdible()) out.add(entry);
        }
        return out;
    }

    public static Item coin(CoinItem.Coin coin) {
        return COINS.get(coin).get();
    }

    public static Item release(ChakraNature release) {
        return RELEASES.get(release).get();
    }

    private static Rarity rarityFor(Jutsu jutsu) {
        return jutsu.rank().rarity();
    }

    private ModItems() {}
}
