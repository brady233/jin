package com.shinobiarts.item;

import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Supplier;

/**
 * Food from the Hidden Leaf: Ichiraku ramen, dango, onigiri, yakiniku, Lee's Curry of Life, katsudon. Each fills you
 * up like vanilla food and some give a little more: chakra back, a short buff. Bowls come back empty.
 */
public class NinjaFoodItem extends Item {
    /** Share of max chakra it gives back (0 = none). */
    private final float chakraShare;
    private final boolean bowl;
    private final List<Supplier<MobEffectInstance>> effects;

    @SafeVarargs
    public NinjaFoodItem(Properties properties, float chakraShare, boolean bowl, Supplier<MobEffectInstance>... effects) {
        super(properties);
        this.chakraShare = chakraShare;
        this.bowl = bowl;
        this.effects = List.of(effects);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide) {
            for (Supplier<MobEffectInstance> e : effects) entity.addEffect(e.get());
            if (chakraShare > 0 && entity instanceof ServerPlayer sp) {
                NinjaData d = NinjaData.get(sp);
                if (d != null) {
                    float amount = d.maxChakra() * chakraShare;
                    d.addChakra(amount);
                    sp.displayClientMessage(Component.translatable("message.shinobiarts.food_chakra", Math.round(amount))
                            .withStyle(ChatFormatting.AQUA), true);
                    ModNetwork.sync(sp);
                }
            }
        }
        ItemStack left = super.finishUsingItem(stack, level, entity);
        if (!bowl || (entity instanceof Player p && p.getAbilities().instabuild)) return left;
        if (left.isEmpty()) return new ItemStack(Items.BOWL);
        if (entity instanceof Player p && !p.getInventory().add(new ItemStack(Items.BOWL))) p.drop(new ItemStack(Items.BOWL), false);
        return left;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(getDescriptionId() + ".desc").withStyle(ChatFormatting.GRAY));
        if (chakraShare > 0) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.food_chakra", Math.round(chakraShare * 100)).withStyle(ChatFormatting.AQUA));
        }
    }
}
