package com.shinobiarts.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.shinobiarts.Config;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.ForgeMod;

import javax.annotation.Nullable;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * The named ninja weapons (Kubikiribocho, Samehada, Kusanagi, ...). They are swords, so Kenjutsu points
 * boost them. Attack damage comes from the server config ("weapons" section), so admins can rebalance
 * without a new jar; the tooltip always shows the live value. Big weapons also reach further.
 */
public class NinjaWeaponItem extends SwordItem {
    /** The special effect each weapon has on hit. */
    public enum Ability {
        NONE,
        /** Kubikiribocho: repairs itself a little with every hit. */
        SELF_REPAIR,
        /** Samehada: eats the target's chakra and feeds it to the wielder. */
        CHAKRA_DRAIN,
        /** Kusanagi: Chidori Flow. Spends a little chakra to paralyse the target. */
        CHIDORI_FLOW,
        /** Hidan's scythe: Jashin's ritual heals the wielder for part of the damage (handled in WeaponEvents). */
        LIFESTEAL,
        /** Sword of Fire: sets the target ablaze. */
        BURN,
        /** Shakujo: heavy staff strikes knock targets far back. */
        KNOCKBACK,
        /** Kabutowari: armor stops less of its damage, and it knocks shields out of use (handled in WeaponEvents). */
        ARMOR_BREAK,
        /** Gunbai: hold right-click to guard like a shield; jutsu and arrows that hit the guard fly back (WeaponEvents). */
        REFLECT,
        /** Kiba: hits spark lightning onto nearby enemies; right-click calls lightning down where you look. */
        LIGHTNING
    }

    private static final UUID REACH_UUID = UUID.fromString("5b1f3c2e-8a4d-4f6e-9c1b-2d7e8f9a0b31");

    private final ForgeConfigSpec.DoubleValue damage;
    private final float attackSpeed;
    private final double reach;
    private final Ability ability;
    /** The model drawn in the empty off hand (Kiba's second blade, Kabutowari's hammer), or null. */
    @Nullable
    private String offhandModel;
    private volatile Modifiers cache;

    private record Modifiers(double damage, Multimap<Attribute, AttributeModifier> map) {}

    /**
     * @param damage      config value holding the total attack damage shown on the tooltip
     * @param attackSpeed attacks per second minus 4 (vanilla convention: -2.4 = sword speed 1.6)
     * @param reach       extra attack reach in blocks
     */
    public NinjaWeaponItem(Tier tier, ForgeConfigSpec.DoubleValue damage, float attackSpeed, double reach, Ability ability,
                           Properties properties) {
        super(tier, Math.max(0, (int) Math.round(damage.getDefault() - 1 - tier.getAttackDamageBonus())), attackSpeed, properties);
        this.damage = damage;
        this.attackSpeed = attackSpeed;
        this.reach = reach;
        this.ability = ability;
    }

    private static double minDamage = -1, maxDamage = -1;

    /**
     * The Kenjutsu a player needs to wield this sword: 5 for the weakest sword, up to 175 for the strongest, in between
     * by how hard it hits (by default damage, so config changes don't move it).
     */
    public int kenjutsuNeeded() {
        if (minDamage < 0) {
            minDamage = Double.MAX_VALUE;
            maxDamage = 0;
            for (net.minecraft.world.item.Item item : net.minecraftforge.registries.ForgeRegistries.ITEMS) {
                if (item instanceof NinjaWeaponItem w) {
                    minDamage = Math.min(minDamage, w.damage.getDefault());
                    maxDamage = Math.max(maxDamage, w.damage.getDefault());
                }
            }
        }
        double span = Math.max(1e-6, maxDamage - minDamage);
        double t = Math.max(0, Math.min(1, (damage.getDefault() - minDamage) / span));
        return (int) Math.round(5 + t * 170);
    }

    public Ability ability() {
        return ability;
    }

    /** Held in both hands: the off hand (while empty) shows {@code model} (models/item/3d/<model>.json). */
    public NinjaWeaponItem dualWield(String model) {
        this.offhandModel = model;
        return this;
    }

    @Nullable
    public String offhandModel() {
        return offhandModel;
    }

    // ---------------------------------------------------------------- right-click: Gunbai guard, Kiba lightning

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (ability == Ability.REFLECT) {
            player.startUsingItem(hand);
            return InteractionResultHolder.consume(stack);
        }
        if (ability == Ability.LIGHTNING && hand == InteractionHand.MAIN_HAND) {
            if (!(player instanceof ServerPlayer sp) || !(level instanceof ServerLevel server)) return InteractionResultHolder.success(stack);
            return lightningStrike(server, sp, stack) ? InteractionResultHolder.success(stack) : InteractionResultHolder.fail(stack);
        }
        return super.use(level, player, hand);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return ability == Ability.REFLECT ? UseAnim.BLOCK : super.getUseAnimation(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return ability == Ability.REFLECT ? 72000 : super.getUseDuration(stack);
    }

    /** The Gunbai blocks like a shield while you hold right-click. */
    @Override
    public boolean canPerformAction(ItemStack stack, ToolAction action) {
        if (ability == Ability.REFLECT && action == ToolActions.SHIELD_BLOCK) return true;
        return super.canPerformAction(stack, action);
    }

    /** Kiba: lightning comes down on whatever you look at (32 blocks), hurting everyone near it. */
    private boolean lightningStrike(ServerLevel level, ServerPlayer player, ItemStack stack) {
        NinjaData data = NinjaData.get(player);
        if (data == null) return false;
        float cost = Config.f(Config.KIBA_STRIKE_COST);
        boolean free = player.getAbilities().instabuild;
        if (!free && data.getChakra() < cost) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_chakra",
                    (int) data.getChakra(), (int) Math.ceil(cost)).withStyle(ChatFormatting.RED), true);
            return false;
        }
        LivingEntity aimed = JutsuUtil.rayTarget(player, 32);
        Vec3 pos;
        if (aimed != null) {
            pos = aimed.position();
        } else {
            BlockHitResult hit = JutsuUtil.rayBlock(player, 32);
            if (hit.getType() == HitResult.Type.MISS) return false;
            pos = hit.getLocation();
        }
        if (!free) data.consumeChakra(cost);
        ModNetwork.sync(player);
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {                                        // the flash and thunder only: no fire, no vanilla damage
            bolt.moveTo(pos.x, pos.y, pos.z);
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
        float damage = Config.f(Config.KIBA_STRIKE_DAMAGE);
        for (LivingEntity e : JutsuUtil.inRadius(level, player, pos.add(0, 1, 0), 2.5)) {
            e.hurt(ModDamage.jutsu(level, player, player), damage);
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 3), player);
        }
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y + 1, pos.z, 40, 0.8, 1.0, 0.8, 0.4);
        player.getCooldowns().addCooldown(this, Config.i(Config.KIBA_STRIKE_COOLDOWN) * 20);
        return true;
    }

    /** Total attack damage (including the player's base 1), as set in the config. */
    public double attackDamage() {
        return Config.d(damage);
    }

    @Override
    public float getDamage() {
        return (float) attackDamage() - 1f;
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        if (slot != EquipmentSlot.MAINHAND) return super.getDefaultAttributeModifiers(slot);
        double dmg = attackDamage();
        Modifiers current = cache;
        if (current == null || current.damage() != dmg) {
            ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
            builder.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Weapon modifier",
                    dmg - 1.0, AttributeModifier.Operation.ADDITION));
            builder.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Weapon modifier",
                    attackSpeed, AttributeModifier.Operation.ADDITION));
            if (reach > 0) {
                builder.put(ForgeMod.ENTITY_REACH.get(), new AttributeModifier(REACH_UUID, "Weapon reach",
                        reach, AttributeModifier.Operation.ADDITION));
            }
            current = new Modifiers(dmg, builder.build());
            cache = current;
        }
        return current.map();
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.hurtEnemy(stack, target, attacker);
        if (!(attacker.level() instanceof ServerLevel level)) return result;
        Vec3 c = target.getBoundingBox().getCenter();
        switch (ability) {
            case SELF_REPAIR -> {
                if (stack.isDamaged()) stack.setDamageValue(Math.max(0, stack.getDamageValue() - 3));
            }
            case CHAKRA_DRAIN -> {
                if (!(attacker instanceof ServerPlayer player)) break;
                NinjaData data = NinjaData.get(player);
                if (data == null) break;
                float gained = Config.f(Config.SAMEHADA_FEED);
                if (target instanceof ServerPlayer victim && victim != player) {
                    gained += com.shinobiarts.ninja.PlayerDataManager.drainChakra(victim, Config.f(Config.SAMEHADA_STEAL));
                }
                if (gained > 0) {
                    data.addChakra(gained);
                    ModNetwork.sync(player);
                }
                level.sendParticles(ParticleTypes.SOUL, c.x, c.y, c.z, 6, 0.3, 0.4, 0.3, 0.02);
            }
            case CHIDORI_FLOW -> {
                // Chidori Flow: a stun that costs a tenth of your max chakra, then can't stun again for 15 seconds (both in
                // Weapons.toml); hits in between are plain sword hits. The hotbar shows the wait on the sword.
                if (!(attacker instanceof ServerPlayer player)) break;
                NinjaData data = NinjaData.get(player);
                long now = level.getGameTime();
                if (data == null || data.cooldownRemaining("kusanagi_stun", now) > 0) break;
                boolean creative = player.getAbilities().instabuild;
                float cost = data.maxChakra() * Config.f(Config.KUSANAGI_CHAKRA_PERCENT);
                if (!creative && data.getChakra() < cost) break;
                if (!creative) data.consumeChakra(cost);
                int cooldown = Config.i(Config.KUSANAGI_STUN_COOLDOWN) * 20;
                data.setCooldown("kusanagi_stun", now + cooldown);
                if (cooldown > 0) player.getCooldowns().addCooldown(this, cooldown);
                ModNetwork.sync(player);
                com.shinobiarts.ninja.Afflictions.stun(target, 30, com.shinobiarts.ninja.Afflictions.STUN_NONE);
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 30, 0.35, 0.5, 0.35, 0.4);
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 14, 0.3, 0.4, 0.3, 0.3);
                level.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.TRIDENT_HIT, SoundSource.PLAYERS, 0.6f, 1.8f);
            }
            case BURN -> {
                target.setSecondsOnFire(5);
                level.sendParticles(ParticleTypes.FLAME, c.x, c.y, c.z, 10, 0.3, 0.4, 0.3, 0.03);
            }
            case KNOCKBACK -> {
                target.knockback(1.2, Math.sin(Math.toRadians(attacker.getYRot())), -Math.cos(Math.toRadians(attacker.getYRot())));
                level.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 0.5f, 1.6f);
            }
            case ARMOR_BREAK -> {
                level.sendParticles(ParticleTypes.CRIT, c.x, c.y, c.z, 12, 0.3, 0.4, 0.3, 0.3);
                level.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.35f, 1.4f);
            }
            case REFLECT -> {                                      // a war fan's swing is a gust: it knocks targets back
                target.knockback(0.9, Math.sin(Math.toRadians(attacker.getYRot())), -Math.cos(Math.toRadians(attacker.getYRot())));
                level.sendParticles(ParticleTypes.CLOUD, c.x, c.y, c.z, 6, 0.3, 0.3, 0.3, 0.05);
            }
            case LIGHTNING -> {
                if (!(attacker instanceof ServerPlayer player)) break;
                NinjaData data = NinjaData.get(player);
                float cost = Config.f(Config.KIBA_ARC_COST);
                boolean free = player.getAbilities().instabuild;
                if (data == null || (!free && data.getChakra() < cost)) break;
                List<LivingEntity> near = JutsuUtil.inRadius(level, player, c, 4.0);
                near.remove(target);
                near.sort(Comparator.comparingDouble(e -> e.distanceToSqr(target)));
                float arc = (float) attackDamage() * Config.f(Config.KIBA_ARC_SHARE);
                int max = Config.i(Config.KIBA_ARC_TARGETS);
                for (int i = 0; i < Math.min(max, near.size()); i++) {
                    LivingEntity e = near.get(i);
                    JutsuUtil.line(level, ParticleTypes.ELECTRIC_SPARK, c, e.getBoundingBox().getCenter(), 0.3, 1, 0.05);
                    e.hurt(ModDamage.jutsu(level, player, player), arc);
                }
                if (!free) data.consumeChakra(cost);
                ModNetwork.sync(player);
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 12, 0.3, 0.4, 0.3, 0.3);
                level.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.TRIDENT_HIT, SoundSource.PLAYERS, 0.5f, 1.9f);
            }
            default -> {
            }
        }
        return result;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (level != null && level.isClientSide) {
            int need = kenjutsuNeeded();
            boolean ok = com.shinobiarts.client.ClientNinjaData.get().stat(com.shinobiarts.ninja.Stat.KENJUTSU) >= need;
            tooltip.add(Component.translatable("tooltip.shinobiarts.kenjutsu_needed", need)
                    .withStyle(ok ? net.minecraft.ChatFormatting.GREEN : net.minecraft.ChatFormatting.RED));
        }
        if (ability != Ability.NONE) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.weapon." + ability.name().toLowerCase(java.util.Locale.ROOT))
                    .withStyle(ChatFormatting.GOLD));
        }
        if (ability == Ability.CHIDORI_FLOW) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.weapon.chidori_flow_cost",
                    Math.round(Config.f(Config.KUSANAGI_CHAKRA_PERCENT) * 100), Config.i(Config.KUSANAGI_STUN_COOLDOWN)).withStyle(ChatFormatting.GOLD));
        }
        if (ability == Ability.LIGHTNING) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.weapon.lightning_strike", (int) Config.f(Config.KIBA_STRIKE_COST),
                    Config.i(Config.KIBA_STRIKE_COOLDOWN)).withStyle(ChatFormatting.GOLD));
        }
        if (offhandModel != null) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.weapon.dual").withStyle(ChatFormatting.GRAY));
        }
        tooltip.add(Component.translatable("tooltip.shinobiarts.weapon.kenjutsu").withStyle(ChatFormatting.GRAY));
    }
}
