package com.shinobiarts.network;

import com.shinobiarts.pvp.ShinobiRecords;
import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: put {@code amount} Ryo on the head of the online player called {@code name} (the Bounties page). */
public class BountyPostPacket {
    private final String name;
    private final long amount;

    public BountyPostPacket(String name, long amount) {
        this.name = name;
        this.amount = amount;
    }

    public BountyPostPacket(FriendlyByteBuf buf) {
        this.name = buf.readUtf(32);
        this.amount = buf.readVarLong();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(name, 32);
        buf.writeVarLong(amount);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player == null) return;
        if (com.shinobiarts.combat.CombatTag.inCombat(player)) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.bounty_combat").withStyle(ChatFormatting.RED));
            return;
        }
        ServerPlayer target = player.server.getPlayerList().getPlayerByName(name.trim());
        if (target == null) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.bounty_offline", name.trim()).withStyle(ChatFormatting.RED));
            return;
        }
        ShinobiRecords.post(player, target, amount);
        ShinobiRecords.sendBoard(player);
    }
}
