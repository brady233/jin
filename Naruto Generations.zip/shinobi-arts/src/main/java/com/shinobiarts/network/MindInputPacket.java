package com.shinobiarts.network;

import com.shinobiarts.jutsu.MindTransfer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server, every tick while the player's mind is in another body: their keys and where they're looking. */
public class MindInputPacket {
    private static final int JUMP = 1, SNEAK = 2, ATTACK = 4;
    private final float forward, strafe, yaw, pitch;
    private final int flags;

    public MindInputPacket(float forward, float strafe, boolean jump, boolean sneak, boolean attack, float yaw, float pitch) {
        this.forward = forward;
        this.strafe = strafe;
        this.flags = (jump ? JUMP : 0) | (sneak ? SNEAK : 0) | (attack ? ATTACK : 0);
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public MindInputPacket(FriendlyByteBuf buf) {
        this.forward = buf.readFloat();
        this.strafe = buf.readFloat();
        this.flags = buf.readByte();
        this.yaw = buf.readFloat();
        this.pitch = buf.readFloat();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeFloat(forward);
        buf.writeFloat(strafe);
        buf.writeByte(flags);
        buf.writeFloat(yaw);
        buf.writeFloat(pitch);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player == null || !Float.isFinite(forward) || !Float.isFinite(strafe) || !Float.isFinite(yaw) || !Float.isFinite(pitch)) return;
        MindTransfer.input(player, forward, strafe, (flags & JUMP) != 0, (flags & SNEAK) != 0, (flags & ATTACK) != 0, yaw, pitch);
    }
}
