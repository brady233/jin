package com.shinobiarts.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: draw a jutsu effect (see fx/Fx and client/fx/FxClient). */
public class FxPacket {
    private final int type, entityA, entityB, ticks, seed;
    private final Vec3 a, b;
    private final float size;

    public FxPacket(int type, Vec3 a, Vec3 b, int entityA, int entityB, float size, int ticks, int seed) {
        this.type = type;
        this.a = a;
        this.b = b;
        this.entityA = entityA;
        this.entityB = entityB;
        this.size = size;
        this.ticks = ticks;
        this.seed = seed;
    }

    public FxPacket(FriendlyByteBuf buf) {
        this.type = buf.readVarInt();
        this.a = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        this.b = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        this.entityA = buf.readVarInt();
        this.entityB = buf.readVarInt();
        this.size = buf.readFloat();
        this.ticks = buf.readVarInt();
        this.seed = buf.readInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(type);
        buf.writeDouble(a.x);
        buf.writeDouble(a.y);
        buf.writeDouble(a.z);
        buf.writeDouble(b.x);
        buf.writeDouble(b.y);
        buf.writeDouble(b.z);
        buf.writeVarInt(entityA);
        buf.writeVarInt(entityB);
        buf.writeFloat(size);
        buf.writeVarInt(ticks);
        buf.writeInt(seed);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.shinobiarts.client.fx.FxClient.add(type, a, b, entityA, entityB, size, ticks, seed));
    }
}
