package com.shinobiarts.network;

import com.shinobiarts.ShinobiArts;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ConfigTracker;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * The mod's config files live in the server's own config folder (config/Naruto Generations/), so they're common
 * configs, which Forge doesn't send to players. This sends each file to every player who joins, so their game uses
 * the server's values (jutsu costs, charge times, stats...) exactly as Forge does for server configs. When they
 * leave, their game goes back to its own files (client/ClientEvents).
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ConfigSyncPacket {
    private final String fileName;
    private final byte[] bytes;

    public ConfigSyncPacket(String fileName, byte[] bytes) {
        this.fileName = fileName;
        this.bytes = bytes;
    }

    public ConfigSyncPacket(FriendlyByteBuf buf) {
        this.fileName = buf.readUtf();
        this.bytes = buf.readByteArray();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(fileName);
        buf.writeByteArray(bytes);
    }

    /** This mod's config files. */
    public static List<ModConfig> configs() {
        List<ModConfig> out = new ArrayList<>();
        for (ModConfig c : ConfigTracker.INSTANCE.configSets().get(ModConfig.Type.COMMON)) {
            if (ShinobiArts.MODID.equals(c.getModId())) out.add(c);
        }
        return out;
    }

    /** Sends the server's files to a player who just joined (not to the player hosting a single-player world). */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        MinecraftServer server = player.getServer();
        if (server == null || (!server.isDedicatedServer() && server.isSingleplayerOwner(player.getGameProfile()))) return;
        for (ModConfig c : configs()) {
            try {
                byte[] data = Files.readAllBytes(c.getFullPath());
                ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new ConfigSyncPacket(c.getFileName(), data));
            } catch (IOException | RuntimeException e) {
                ShinobiArts.LOGGER.warn("Couldn't send config {} to {}", c.getFileName(), player.getGameProfile().getName(), e);
            }
        }
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> Client.accept(fileName, bytes));
    }

    /** Client side. */
    public static final class Client {
        /** Whether this game is using a server's files right now. */
        private static boolean usingServerFiles;

        private Client() {}

        static void accept(String fileName, byte[] bytes) {
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            if (mc.isLocalServer()) return;                   // hosting: the files are already ours
            for (ModConfig c : configs()) {
                if (c.getFileName().equals(fileName)) {
                    c.acceptSyncedConfig(bytes);
                    usingServerFiles = true;
                }
            }
        }

        /** Leaving a server: back to this game's own files. */
        public static void restoreLocal() {
            if (!usingServerFiles) return;
            usingServerFiles = false;
            for (ModConfig c : configs()) {
                try {
                    if (Files.exists(c.getFullPath())) c.acceptSyncedConfig(Files.readAllBytes(c.getFullPath()));
                } catch (IOException | RuntimeException e) {
                    ShinobiArts.LOGGER.warn("Couldn't reload config {}", c.getFileName(), e);
                }
            }
        }
    }
}
