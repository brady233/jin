package com.shinobiarts.security;

import com.shinobiarts.ShinobiArts;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Anti-duplication for the mod's unique items (releases, implantable eyes, the Eight Gates...).
 * <p>
 * Every guarded stack carries a serial number, given by the server the first time it sits in a player's inventory.
 * Two ways a duplicate gets caught:
 * <ul>
 *   <li><b>Two copies at once:</b> each tick the server notes where every serial is. If the same serial turns up in two
 *       places in the same tick (two players, or two slots), the second copy is deleted.</li>
 *   <li><b>A copy of something used up:</b> when a guarded item is consumed (an eye implanted...), its serial is
 *       recorded as spent, permanently (saved with the world). Any stack that later turns up with a spent serial is a
 *       duplicate and is deleted.</li>
 * </ul>
 * Each catch is written to the server log (with the player's name) and shown to online operators.
 */
public final class ItemGuard {
    private ItemGuard() {}

    private static final String SERIAL = "ShinobiSerial";

    /** Where each serial was seen this tick: serial -> "player uuid / slot". Cleared when the tick changes. */
    private static final Map<UUID, String> SEEN = new HashMap<>();
    private static long seenTick = Long.MIN_VALUE;

    /** The stack's serial, giving it one first if it has none (server side only). */
    public static UUID serial(ItemStack stack) {
        CompoundTag tag = stack.getOrCreateTag();
        if (!tag.hasUUID(SERIAL)) tag.putUUID(SERIAL, UUID.randomUUID());
        return tag.getUUID(SERIAL);
    }

    /**
     * Called every tick for a guarded stack in a player's inventory (from the item's inventoryTick). Returns false if the
     * stack was a duplicate and has been deleted.
     */
    public static boolean check(ItemStack stack, ServerPlayer player, int slot) {
        if (stack.isEmpty()) return true;
        UUID id = serial(stack);
        MinecraftServer server = player.server;
        Ledger ledger = Ledger.get(server);
        if (ledger.spent.contains(id)) {
            caught(player, stack, "a copy of an item that was already used up");
            stack.setCount(0);
            return false;
        }
        long tick = server.getTickCount();
        if (tick != seenTick) {
            SEEN.clear();
            seenTick = tick;
        }
        String where = player.getUUID() + "/" + slot;
        String before = SEEN.putIfAbsent(id, where);
        if (before != null && !before.equals(where)) {
            caught(player, stack, "two copies of the same item at once");
            stack.setCount(0);
            return false;
        }
        return true;
    }

    /** The guarded item has been used up (implanted, read...): its serial can never be valid again. */
    public static void spend(ItemStack stack, MinecraftServer server) {
        if (stack.isEmpty()) return;
        Ledger.get(server).spend(serial(stack));
    }

    private static void caught(ServerPlayer player, ItemStack stack, String why) {
        String msg = "Shinobi Arts anti-dupe: removed " + stack.getCount() + "x " + stack.getHoverName().getString()
                + " from " + player.getGameProfile().getName() + " (" + why + ")";
        ShinobiArts.LOGGER.warn(msg);
        Component alert = Component.literal("[Anti-dupe] " + player.getGameProfile().getName() + ": removed "
                + stack.getHoverName().getString() + " (" + why + ")").withStyle(ChatFormatting.RED);
        for (ServerPlayer op : player.server.getPlayerList().getPlayers()) {
            if (op.hasPermissions(2)) op.sendSystemMessage(alert);
        }
    }

    /** The serials of guarded items that have been used up (saved with the world). */
    static final class Ledger extends SavedData {
        final Set<UUID> spent = new HashSet<>();

        static Ledger get(MinecraftServer server) {
            ServerLevel overworld = server.overworld();
            return overworld.getDataStorage().computeIfAbsent(Ledger::load, Ledger::new, "shinobiarts_item_ledger");
        }

        static Ledger load(CompoundTag tag) {
            Ledger l = new Ledger();
            for (Tag t : tag.getList("Spent", Tag.TAG_STRING)) {
                try {
                    l.spent.add(UUID.fromString(t.getAsString()));
                } catch (IllegalArgumentException ignored) {
                }
            }
            return l;
        }

        void spend(UUID id) {
            if (spent.add(id)) setDirty();
        }

        @Override
        public CompoundTag save(CompoundTag tag) {
            ListTag list = new ListTag();
            for (UUID id : spent) list.add(StringTag.valueOf(id.toString()));
            tag.put("Spent", list);
            return tag;
        }
    }
}
