package com.shinobiarts.shop;

import com.shinobiarts.Config;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.network.ShopPacket;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/**
 * The ninja shop (/shop): ninja tools, explosives, food and jutsu points, bought with Ryo. Everything on sale and its
 * price comes from the "shop" list in General.toml ("category|item|count|price"; the item "jutsu_points" sells jutsu
 * points). The server checks every purchase against its own list, so the client can't change a price.
 */
public final class Shop {
    public static final String[] CATEGORIES = {"tools", "explosives", "food", "points"};
    public static final String POINTS = "jutsu_points";

    public record Entry(String category, String item, int count, long price) {
        public boolean isPoints() {
            return POINTS.equals(item);
        }

        public ItemStack stack() {
            if (isPoints()) return ItemStack.EMPTY;
            Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(item));
            return it == null ? ItemStack.EMPTY : new ItemStack(it, count);
        }
    }

    private Shop() {}

    /** The entries in the config (bad lines are skipped). */
    public static List<Entry> catalog() {
        List<Entry> out = new ArrayList<>();
        for (String line : Config.strings(Config.SHOP_ITEMS)) {
            Entry e = parse(line);
            if (e != null) out.add(e);
        }
        return out;
    }

    public static Entry parse(String line) {
        String[] p = line.split("\\|");
        if (p.length != 4) return null;
        try {
            String cat = p[0].trim().toLowerCase(), item = p[1].trim();
            int count = Integer.parseInt(p[2].trim());
            long price = Long.parseLong(p[3].trim());
            if (count <= 0 || price < 0) return null;
            if (!item.equals(POINTS)) {
                ResourceLocation id = ResourceLocation.tryParse(item);
                if (id == null || !ForgeRegistries.ITEMS.containsKey(id)) return null;
            }
            return new Entry(cat, item, count, price);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** Opens (or refreshes) the shop screen for the player. */
    public static void open(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;
        CompoundTag tag = new CompoundTag();
        tag.putLong("Ryo", d.getRyo());
        tag.putInt("Points", d.getJutsuPoints());
        ListTag list = new ListTag();
        for (Entry e : catalog()) {
            CompoundTag t = new CompoundTag();
            t.putString("Cat", e.category());
            t.putString("Item", e.item());
            t.putInt("Count", e.count());
            t.putLong("Price", e.price());
            list.add(t);
        }
        tag.put("Items", list);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new ShopPacket(tag));
    }

    /** Buys entry {@code index} of the catalog {@code times} times over. */
    public static void buy(ServerPlayer player, int index, int times) {
        if (!Config.b(Config.SHOP_ENABLED)) return;
        List<Entry> cat = catalog();
        if (index < 0 || index >= cat.size()) return;
        times = Math.max(1, Math.min(64, times));
        Entry e = cat.get(index);
        long cost = e.price() * times;
        if (!PlayerDataManager.trySpendRyo(player, cost)) {
            NinjaData d = NinjaData.get(player);
            player.displayClientMessage(Component.translatable("message.shinobiarts.shop_poor", PlayerDataManager.formatRyo(cost),
                    PlayerDataManager.formatRyo(d == null ? 0 : d.getRyo())).withStyle(ChatFormatting.RED), true);
            return;
        }
        if (e.isPoints()) {
            NinjaData d = NinjaData.get(player);
            if (d != null) d.setJutsuPoints(d.getJutsuPoints() + e.count() * times);
            PlayerDataManager.sync(player);
        } else {
            for (int i = 0; i < times; i++) {
                ItemStack stack = e.stack();
                if (!player.getInventory().add(stack) && !stack.isEmpty()) player.drop(stack, false);
            }
        }
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.VILLAGER_YES, SoundSource.PLAYERS, 0.6f, 1.2f);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.5f, 1.4f);
        open(player);
    }
}
