package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Ice Release (Haku): Ice Prison (a jagged cluster of ice crystals frozen round the target), Demonic Ice Mirrors (a
 * dome of tall shining mirrors, a shadowy figure flitting between them) and the needles that fly from them.
 */
final class FxIce {
    private FxIce() {}

    static Paint ice(float alpha) {
        return FxDraw.block("minecraft:block/packed_ice", 0xE6F6FF, alpha);
    }

    /** Ice Prison: a big crystal locks the target in, with smaller crystals bristling out of its base. */
    static void prison(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        Vec3 feet = e != null ? e.getPosition(c.partial()) : c.fx().a;
        float h = e != null ? e.getBbHeight() : 1.8f, w = e != null ? e.getBbWidth() : 0.6f;
        float age = c.age();
        float grow = FxDraw.smooth(age / 4f);
        float fade = 1f - Mth.clamp((age - (c.fx().ticks - 3)) / 3f, 0f, 1f);
        VertexConsumer vc = FxDraw.blocksTranslucent(c.buffers());
        int light = Math.max(FxDraw.lightAt(feet.add(0, 1, 0)), 0x00A000A0);
        Paint p = ice(0.72f * fade);
        FxDraw.crystal(vc, c.ps(), feet.add(0, h * 0.55f * grow, 0), new Vec3(0.05, 1, 0.02), h * 1.45f * grow, (w * 0.8f + 0.35f) * grow, 6, p, light);
        RandomSource r = FxDraw.rng(c.fx().seed, 7);
        for (int k = 0; k < 9; k++) {
            float ang = k * Mth.TWO_PI / 9 + r.nextFloat() * 0.4f;
            Vec3 axis = new Vec3(Mth.cos(ang) * 0.7, 1, Mth.sin(ang) * 0.7);
            float len = (0.9f + r.nextFloat() * 1.1f) * grow;
            Vec3 at = feet.add(Mth.cos(ang) * (w * 0.6 + 0.45), len * 0.3, Mth.sin(ang) * (w * 0.6 + 0.45));
            FxDraw.crystal(vc, c.ps(), at, axis, len, 0.18f + r.nextFloat() * 0.12f, 5, p, light);
        }
        // a cold sheen sliding down the faces
        VertexConsumer g = FxDraw.glow(c.buffers());
        float sheen = (age * 0.08f) % 1f;
        FxDraw.ring(g, c.ps(), feet.add(0, h * (1.1f - sheen * 1.1f), 0), new Vec3(0, 1, 0), w * 0.8f + 0.4f, 0.12f, 20,
                FxDraw.color(0xFFFFFF, 0.3f * fade), FxDraw.color(0xFFFFFF, 0f), FxDraw.FULL);
    }

    /**
     * Demonic Ice Mirrors: twelve tall mirrors in a ring round the target and eight more tipped in above them, shining
     * with light running across their faces; a dark figure appears in one mirror after another.
     */
    static void mirrors(FxClient.Ctx c) {
        Vec3 centre = c.fx().a;
        float age = c.age();
        float fade = Mth.clamp(age / 6f, 0f, 1f) * (1f - Mth.clamp((age - (c.fx().ticks - 8)) / 8f, 0f, 1f));
        VertexConsumer glow = FxDraw.glow(c.buffers());
        VertexConsumer frame = FxDraw.blocksTranslucent(c.buffers());
        int light = FxDraw.lightAt(centre.add(0, 1, 0));
        int shadow = ((int) (age / 8) * 7 + c.fx().seed) & 0x7fffffff;
        for (int ring = 0; ring < 2; ring++) {
            int count = ring == 0 ? 12 : 8;
            for (int k = 0; k < count; k++) {
                float ang = (k + (ring == 0 ? 0 : 0.5f)) * Mth.TWO_PI / count;
                Vec3 out = new Vec3(Mth.cos(ang), 0, Mth.sin(ang));
                Vec3 side = new Vec3(-out.z, 0, out.x);
                float r = ring == 0 ? 3.3f : 2.6f;
                Vec3 base = centre.add(out.scale(r)).add(0, ring == 0 ? 0.1 : 3.2, 0);
                Vec3 up = ring == 0 ? new Vec3(0, 1, 0) : new Vec3(0, 1, 0).scale(Mth.cos(0.7f)).subtract(out.scale(Mth.sin(0.7f)));
                float w = ring == 0 ? 0.75f : 0.6f, hh = ring == 0 ? 2.6f : 1.8f;
                Vec3 a = base.subtract(side.scale(w)), b = base.add(side.scale(w));
                Vec3 a2 = a.add(up.scale(hh)), b2 = b.add(up.scale(hh));
                FxDraw.quad(glow, c.ps(), a, a2, b2, b, FxDraw.color(0xD8F0FF, 0.38f * fade), FxDraw.FULL);
                // light running diagonally across the glass
                float run = ((age * 0.05f + k * 0.13f) % 1.4f) - 0.2f;
                if (run > 0 && run < 1) {
                    Vec3 s0 = a.lerp(b, run).add(up.scale(hh * 0.1f)), s1 = a.lerp(b, Math.min(1, run + 0.12f)).add(up.scale(hh * 0.1f));
                    FxDraw.quad(glow, c.ps(), s0, s0.add(up.scale(hh * 0.8f)), s1.add(up.scale(hh * 0.8f)), s1,
                            FxDraw.color(0xFFFFFF, 0.35f * fade), FxDraw.FULL);
                }
                // the icy frame round each mirror
                Paint ice = ice(0.85f * fade);
                Vec3 thick = out.scale(0.06);
                FxDraw.box(frame, c.ps(), a.lerp(a2, 0.5), side.scale(0.06), up.scale(hh / 2), thick, ice, light);
                FxDraw.box(frame, c.ps(), b.lerp(b2, 0.5), side.scale(0.06), up.scale(hh / 2), thick, ice, light);
                FxDraw.box(frame, c.ps(), a.lerp(b, 0.5), side.scale(w), up.scale(0.06), thick, ice, light);
                FxDraw.box(frame, c.ps(), a2.lerp(b2, 0.5), side.scale(w), up.scale(0.06), thick, ice, light);
                // the figure inside one mirror at a time
                if (ring == 0 && k == shadow % 12) {
                    Vec3 mid = base.add(up.scale(hh * 0.42f)).subtract(out.scale(0.03));
                    Paint dark = FxDraw.color(0x10141E, 0.75f * fade);
                    FxDraw.box(glow, c.ps(), mid, side.scale(0.22), up.scale(0.42), out.scale(0.01), dark, FxDraw.FULL);
                    FxDraw.box(glow, c.ps(), mid.add(up.scale(0.62)), side.scale(0.14), up.scale(0.15), out.scale(0.01), dark, FxDraw.FULL);
                    FxDraw.box(glow, c.ps(), mid.subtract(up.scale(0.72)), side.scale(0.18), up.scale(0.32), out.scale(0.01), dark, FxDraw.FULL);
                }
            }
        }
    }

    /** An ice needle flying from a mirror to the target. */
    static void needle(FxClient.Ctx c) {
        float t = Mth.clamp(c.age() / Math.max(1, c.fx().ticks - 1), 0f, 1f);
        Vec3 a = c.fx().a, b = c.fx().b;
        Vec3 dir = b.subtract(a);
        if (dir.lengthSqr() < 1e-6) return;
        Vec3 at = a.lerp(b, t);
        VertexConsumer vc = FxDraw.glow(c.buffers());
        FxDraw.crystal(vc, c.ps(), at, dir, 0.7f, 0.05f, 4, FxDraw.color(0xE8F8FF, 0.95f), FxDraw.FULL);
        FxDraw.ribbon(vc, c.ps(), c.cam(), java.util.List.of(at.subtract(dir.normalize().scale(1.4)), at), 0.08f, 0f,
                FxDraw.color(0xCFEFFF, 0f), FxDraw.color(0xCFEFFF, 0.5f), FxDraw.FULL);
    }
}
