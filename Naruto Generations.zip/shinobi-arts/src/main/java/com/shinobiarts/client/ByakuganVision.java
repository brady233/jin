package com.shinobiarts.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * The Byakugan's X-ray sight: while it's on, every living thing nearby (32 blocks; the All-Seeing Eye's range while
 * that's up) shows through walls as its chakra network: glowing blue pathways running out from the chakra centre in
 * the chest to the head, arms and legs, dotted with the bright tenketsu points, chakra pulsing outward along them.
 * Invisible creatures show too. Only the Byakugan's one blind spot, a narrow cone straight behind the back of the
 * neck, hides them. Only the user sees it.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ByakuganVision {
    private static final double RANGE = 32;
    /** How far behind (cosine of the angle off straight back) the blind spot reaches. */
    private static final double BLIND_SPOT = 0.95;

    private ByakuganVision() {}

    /** True if {@code e} sits in the Byakugan's blind spot: straight behind the user's neck. */
    public static boolean inBlindSpot(LocalPlayer p, LivingEntity e) {
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        Vec3 to = e.position().subtract(p.position());
        Vec3 toFlat = new Vec3(to.x, 0, to.z);
        if (flat.lengthSqr() < 1e-6 || toFlat.lengthSqr() < 1e-4) return false;
        return toFlat.normalize().dot(flat.normalize()) < -BLIND_SPOT;
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_WEATHER) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.isInitialized() || d.getActiveDojutsu() != Dojutsu.BYAKUGAN) return;
        long now = mc.level.getGameTime();
        double range = d.getAllSeeingUntil() > now ? Math.max(RANGE, Config.i(Config.ALL_SEEING_RANGE)) : RANGE;
        float partial = event.getPartialTick();
        float t = now + partial;
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        List<LivingEntity> seen = new ArrayList<>();
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(range),
                c -> c != player && c.isAlive() && !c.isSpectator())) {
            if (e.distanceToSqr(player) > range * range || inBlindSpot(player, e)) continue;
            seen.add(e);
        }
        if (seen.isEmpty()) return;

        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = ps.last().pose();
        Vector3f left = camera.getLeftVector(), up = camera.getUpVector();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.SRC_ALPHA,
                com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        Draw draw = new Draw(bb, m, cam, left, up);
        for (LivingEntity e : seen) {
            double dist = Math.sqrt(e.distanceToSqr(player));
            float fade = (float) Mth.clamp(1.25 - dist / range, 0.25, 1.0);
            network(draw, e, partial, t, fade);
        }
        BufferUploader.drawWithShader(bb.end());
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        ps.popPose();
    }

    // ---------------------------------------------------------------- the chakra network

    /** One creature's chakra network, laid out on its body (upright for people and mobs that stand, flat for beasts). */
    private static void network(Draw draw, LivingEntity e, float partial, float t, float fade) {
        Vec3 pos = e.getPosition(partial);
        float yaw = Mth.rotLerp(partial, e.yBodyRotO, e.yBodyRot) * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw)), side = new Vec3(Mth.cos(yaw), 0, Mth.sin(yaw));
        double h = e.getBbHeight(), w = e.getBbWidth();
        RandomSource r = RandomSource.create(e.getId() * 2654435761L);
        Frame f = new Frame(pos, side, fwd);
        float walk = e.walkAnimation.position(partial), speed = Math.min(1f, e.walkAnimation.speed(partial));
        float swing = Mth.sin(walk * 0.6662f) * 0.6f * speed;
        List<Vec3[]> paths = new ArrayList<>();
        Vec3 core;
        if (h >= w * 1.1) {                                       // standing: head, spine, arms, legs
            double hw = w * 0.5;
            Vec3 head = f.at(0, h * 0.86, 0), neck = f.at(0, h * 0.74, 0), chest = f.at(0, h * 0.62, 0.02);
            core = f.at(0, h * 0.5, 0.03);
            Vec3 pelvis = f.at(0, h * 0.4, 0);
            paths.add(new Vec3[]{core, chest, neck, head});
            paths.add(new Vec3[]{core, pelvis});
            for (int s = -1; s <= 1; s += 2) {
                double arm = s * swing * h * 0.12;
                Vec3 shoulder = f.at(s * hw * 0.8, h * 0.71, 0), elbow = f.at(s * hw * 1.0, h * 0.56, 0.02 - arm * 0.5),
                        hand = f.at(s * hw * 1.0, h * 0.42, 0.04 - arm);
                paths.add(new Vec3[]{neck, shoulder, elbow, hand});
                double leg = -s * swing * h * 0.12;
                Vec3 hip = f.at(s * hw * 0.35, h * 0.41, 0), knee = f.at(s * hw * 0.38, h * 0.22, 0.02 + leg * 0.5),
                        foot = f.at(s * hw * 0.38, h * 0.03, leg);
                paths.add(new Vec3[]{pelvis, hip, knee, foot});
                paths.add(new Vec3[]{chest, f.at(s * hw * 0.55, h * 0.6, 0.03), f.at(s * hw * 0.7, h * 0.5, 0.02)});   // ribs
                paths.add(new Vec3[]{core, f.at(s * hw * 0.45, h * 0.47, 0.03), f.at(s * hw * 0.5, h * 0.4, 0.02)});
            }
            draw.ring(head, h * 0.08, 0x9ED8FF, 0.5f * fade, t);
        } else {                                                  // on all fours: a spine from head to tail
            double len = Math.max(w, h) * 1.2, y = h * 0.6, hw = w * 0.35;
            Vec3 head = f.at(0, y + h * 0.15, len * 0.55), front = f.at(0, y, len * 0.3), back = f.at(0, y, -len * 0.3);
            core = f.at(0, y, 0);
            paths.add(new Vec3[]{core, front, head});
            paths.add(new Vec3[]{core, back, f.at(0, y + h * 0.1, -len * 0.55)});
            for (int s = -1; s <= 1; s += 2) {
                double a = s * swing * h * 0.15;
                paths.add(new Vec3[]{front, f.at(s * hw, y * 0.55, len * 0.3 + a), f.at(s * hw, 0.03, len * 0.3 + a * 1.5)});
                paths.add(new Vec3[]{back, f.at(s * hw, y * 0.55, -len * 0.3 - a), f.at(s * hw, 0.03, -len * 0.3 - a * 1.5)});
            }
        }
        // the pathways: wandering a little like veins, chakra pulsing out along them from the centre
        float width = (float) Math.max(0.025, Math.min(0.06, h * 0.025));
        for (Vec3[] path : paths) {
            List<Vec3> pts = wander(path, r, h * 0.025);
            int n = pts.size();
            for (int i = 0; i + 1 < n; i++) {
                float s = i / (float) (n - 1);
                float pulse = 0.5f + 0.5f * Mth.sin(s * 9f - t * 0.35f);
                float a = (0.35f + 0.35f * pulse) * fade;
                draw.segment(pts.get(i), pts.get(i + 1), width * 2.4f, 0x2A7BFF, a * 0.35f);
                draw.segment(pts.get(i), pts.get(i + 1), width, 0x9ED8FF, a);
            }
            for (int i = 2; i < n; i += 3) {                     // tenketsu points along the way
                float twinkle = 0.6f + 0.4f * Mth.sin(t * 0.2f + i * 1.3f + r.nextFloat() * 6f);
                draw.dot(pts.get(i), width * 1.6f, 0xE4F4FF, 0.8f * fade * twinkle);
            }
        }
        float beat = 0.75f + 0.25f * Mth.sin(t * 0.25f);
        draw.dot(core, width * 7f * beat, 0x2A7BFF, 0.35f * fade);  // the chakra centre
        draw.dot(core, width * 3.5f, 0xE8F6FF, 0.9f * fade);
    }

    /** Points along a path with small sideways wanders, a few between each pair of joints. */
    private static List<Vec3> wander(Vec3[] joints, RandomSource r, double amount) {
        List<Vec3> out = new ArrayList<>();
        for (int j = 0; j + 1 < joints.length; j++) {
            Vec3 a = joints[j], b = joints[j + 1];
            int steps = 4;
            for (int k = 0; k < steps; k++) {
                double s = k / (double) steps;
                Vec3 q = a.lerp(b, s);
                if (k > 0) q = q.add((r.nextDouble() - 0.5) * amount * 2, (r.nextDouble() - 0.5) * amount, (r.nextDouble() - 0.5) * amount * 2);
                out.add(q);
            }
        }
        out.add(joints[joints.length - 1]);
        return out;
    }

    /** Where a body-relative point is: x to the creature's side, y up from its feet, z forward. */
    private record Frame(Vec3 pos, Vec3 side, Vec3 fwd) {
        Vec3 at(double x, double y, double z) {
            return pos.add(side.scale(x)).add(0, y, 0).add(fwd.scale(z));
        }
    }

    /** Glowing strips and dots facing the camera, drawn over everything. */
    private record Draw(BufferBuilder bb, Matrix4f m, Vec3 cam, Vector3f left, Vector3f up) {
        void segment(Vec3 a, Vec3 b, float width, int rgb, float alpha) {
            Vec3 d = b.subtract(a);
            Vec3 view = a.add(b).scale(0.5).subtract(cam);
            Vec3 s = d.cross(view);
            if (s.lengthSqr() < 1e-10) return;
            s = s.normalize().scale(width / 2);
            quad(a.add(s), b.add(s), b.subtract(s), a.subtract(s), rgb, alpha);
        }

        void dot(Vec3 c, float size, int rgb, float alpha) {
            float h = size / 2;
            Vec3 l = new Vec3(left.x() * h, left.y() * h, left.z() * h), u = new Vec3(up.x() * h, up.y() * h, up.z() * h);
            quad(c.add(l).add(u), c.subtract(l).add(u), c.subtract(l).subtract(u), c.add(l).subtract(u), rgb, alpha);
            Vec3 l2 = l.add(u).scale(0.72), u2 = u.subtract(l).scale(0.72);   // turned 45 degrees: a soft eight-point glint
            quad(c.add(l2), c.add(u2), c.subtract(l2), c.subtract(u2), rgb, alpha);
        }

        void ring(Vec3 c, double radius, int rgb, float alpha, float t) {
            int n = 14;
            Vec3 l = new Vec3(left.x(), left.y(), left.z()), u = new Vec3(up.x(), up.y(), up.z());
            for (int k = 0; k < n; k++) {
                double a0 = Math.PI * 2 * k / n + t * 0.03, a1 = Math.PI * 2 * (k + 1) / n + t * 0.03;
                Vec3 p0 = c.add(l.scale(Math.cos(a0) * radius)).add(u.scale(Math.sin(a0) * radius));
                Vec3 p1 = c.add(l.scale(Math.cos(a1) * radius)).add(u.scale(Math.sin(a1) * radius));
                segment(p0, p1, (float) (radius * 0.18), rgb, alpha);
            }
        }

        void quad(Vec3 a, Vec3 b, Vec3 c, Vec3 d, int rgb, float alpha) {
            float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, bl = (rgb & 255) / 255f;
            for (Vec3 p : new Vec3[]{a, b, c, d}) {
                bb.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(r, g, bl, alpha).endVertex();
            }
        }
    }
}
