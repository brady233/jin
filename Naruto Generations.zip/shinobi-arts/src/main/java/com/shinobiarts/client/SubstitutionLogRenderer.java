package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.shinobiarts.entity.SubstitutionLog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Substitution's logs: an oak log, standing or lying on its side, that shrinks away in its last half second. */
public class SubstitutionLogRenderer extends EntityRenderer<SubstitutionLog> {
    private static final BlockState STANDING = Blocks.OAK_LOG.defaultBlockState();
    private static final BlockState LYING = Blocks.OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.X);

    public SubstitutionLogRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.35f;
    }

    @Override
    public void render(SubstitutionLog entity, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        float age = entity.tickCount + partialTick;
        float shrink = Math.min(1f, Math.max(0f, (entity.getLife() - age) / 10f));
        if (shrink <= 0f) return;
        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(-entity.getYRot()));
        boolean upright = entity.isUpright();
        // a log about as tall as a ninja when standing, as long when lying down, and 0.7 thick
        if (upright) poseStack.scale(0.7f * shrink, 1.5f * shrink, 0.7f * shrink);
        else poseStack.scale(1.5f * shrink, 0.7f * shrink, 0.7f * shrink);
        poseStack.translate(-0.5, 0.0, -0.5);
        Minecraft.getInstance().getBlockRenderer().renderSingleBlock(upright ? STANDING : LYING, poseStack, buffer, packedLight,
                OverlayTexture.NO_OVERLAY);
        poseStack.popPose();
        super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
    }

    @Override
    @SuppressWarnings("deprecation")
    public ResourceLocation getTextureLocation(SubstitutionLog entity) {
        return InventoryMenu.BLOCK_ATLAS;
    }
}
