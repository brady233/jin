package com.shinobiarts.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Blood Scent (Hoshigaki): while it lasts, every hurt creature within 50 blocks shows through walls as a red smear of
 * scent rising off it, a wavering column with a bright drop at its heart. The more hurt it is, the bigger, brighter and
 * redder the scent, so the weakest are easiest to track. Only the user sees it (health is already known to the client).
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class BloodScentVision {
    private static final double RANGE = 50;

    private BloodScentVision() {}

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_WEATHER) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;
        NinjaData d = ClientNinjaData.get();
        long now = mc.level.getGameTime();
        if (!d.isInitialized() || d.getBloodScentUntil() <= now) return;
        float partial = event.getPartialTick();
        float t = now + partial;
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = ps.last().pose();
        Vector3f left = camera.getLeftVector(), up = camera.getUpVector();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.SRC_ALPHA,
                com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        int drawn = 0;
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(RANGE),
                c -> c != player && c.isAlive() && c.getHealth() < c.getMaxHealth())) {
            if (e.distanceToSqr(player) > RANGE * RANGE) continue;
            float hurt = 1f - Mth.clamp(e.getHealth() / Math.max(1f, e.getMaxHealth()), 0f, 1f);   // 0 scratched .. 1 dying
            Vec3 pos = e.getPosition(partial);
            float h = e.getBbHeight();
            float strength = 0.25f + 0.75f * hurt;
            float r = 1f, g = 0.35f * (1f - hurt), b = 0.25f * (1f - hurt);
            // the drop at the heart
            Vec3 heart = pos.add(0, h * 0.55, 0);
            float s = 0.25f + 0.5f * hurt + 0.06f * Mth.sin(t * 0.3f + e.getId());
            quad(bb, m, heart, left, up, s, r, g, b, 0.85f * strength);
            // the scent: blobs rising and wavering above it, more and taller the more hurt
            int blobs = 3 + Math.round(6 * hurt);
            for (int k = 0; k < blobs; k++) {
                float life = ((t * 0.02f) + k / (float) blobs) % 1f;
                Vec3 p = heart.add(Mth.sin(t * 0.07f + k * 1.7f) * 0.25f * life, life * (1.5f + 2.5f * hurt), Mth.cos(t * 0.05f + k) * 0.25f * life);
                quad(bb, m, p, left, up, s * (0.8f - 0.5f * life), r, g, b, 0.5f * strength * (1f - life));
            }
            drawn++;
        }
        if (drawn > 0) BufferUploader.drawWithShader(bb.end());
        else bb.end();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        ps.popPose();
    }

    /** A camera-facing diamond (a soft blob of scent). */
    private static void quad(BufferBuilder bb, Matrix4f m, Vec3 c, Vector3f left, Vector3f up, float s, float r, float g, float b, float a) {
        float lx = left.x() * s, ly = left.y() * s, lz = left.z() * s, ux = up.x() * s, uy = up.y() * s, uz = up.z() * s;
        bb.vertex(m, (float) c.x + ux, (float) c.y + uy, (float) c.z + uz).color(r, g, b, a).endVertex();
        bb.vertex(m, (float) c.x + lx, (float) c.y + ly, (float) c.z + lz).color(r, g, b, a).endVertex();
        bb.vertex(m, (float) c.x - ux, (float) c.y - uy, (float) c.z - uz).color(r, g, b, a).endVertex();
        bb.vertex(m, (float) c.x - lx, (float) c.y - ly, (float) c.z - lz).color(r, g, b, a).endVertex();
    }
}
