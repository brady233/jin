package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.Map;

/**
 * Shadow Possession's shadow: a black, softly wavering streak lying flat on the ground from the caster's feet to the
 * creature it holds. It races out from the caster when the jutsu lands and shrinks back when it lets go.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ShadowLinkRender {
    private static final ResourceLocation WHITE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/susanoo/white.png");
    private static final float REACH_TICKS = 8f;

    private record Link(int targetId, long start, long end) {}

    private static final Map<Integer, Link> LINKS = new HashMap<>();

    private ShadowLinkRender() {}

    /** From the server: caster {@code casterId}'s shadow holds {@code targetId} for {@code ticks} (0 = let go). */
    public static void set(int casterId, int targetId, int ticks) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        long now = mc.level.getGameTime();
        if (ticks <= 0) {
            Link old = LINKS.get(casterId);
            if (old != null) LINKS.put(casterId, new Link(old.targetId, old.start, Math.min(old.end, now)));
            return;
        }
        LINKS.put(casterId, new Link(targetId, now, now + ticks));
    }

    public static void clear() {
        LINKS.clear();
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || LINKS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            LINKS.clear();
            return;
        }
        float partial = event.getPartialTick();
        float now = mc.level.getGameTime() + partial;
        Vec3 cam = event.getCamera().getPosition();
        PoseStack ps = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        RenderType type = RenderType.entityTranslucent(WHITE);
        VertexConsumer vc = buffers.getBuffer(type);
        boolean drew = false;
        var it = LINKS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Link> en = it.next();
            Link l = en.getValue();
            // grows out over REACH_TICKS, holds, then shrinks back over REACH_TICKS once it lets go
            float reach = Mth.clamp((now - l.start) / REACH_TICKS, 0f, 1f);
            if (now > l.end) reach = Math.min(reach, 1f - Mth.clamp((now - l.end) / REACH_TICKS, 0f, 1f));
            if (now > l.end + REACH_TICKS) {
                it.remove();
                continue;
            }
            Entity caster = mc.level.getEntity(en.getKey()), target = mc.level.getEntity(l.targetId);
            if (caster == null || target == null || reach <= 0f) continue;
            Vec3 a = caster.getPosition(partial), b = target.getPosition(partial);
            ps.pushPose();
            ps.translate(-cam.x, -cam.y, -cam.z);
            streak(ps.last().pose(), ps.last().normal(), vc, a, b, reach, now);
            ps.popPose();
            drew = true;
        }
        if (drew) buffers.endBatch(type);
    }

    /** The streak in segments, a little wider at both ends, edges wavering like a living shadow. */
    private static void streak(Matrix4f pose, Matrix3f normal, VertexConsumer vc, Vec3 a, Vec3 b, float reach, float time) {
        Vec3 d = b.subtract(a);
        double flat = Math.sqrt(d.x * d.x + d.z * d.z);
        if (flat < 1e-3) return;
        double sx = -d.z / flat, sz = d.x / flat;          // sideways, along the ground
        int segments = Math.max(4, (int) (flat * 2));
        int shown = Math.max(1, Math.round(segments * reach));
        for (int i = 0; i < shown; i++) {
            float t0 = i / (float) segments, t1 = (i + 1) / (float) segments;
            float w0 = width(t0, time), w1 = width(t1, time);
            double x0 = a.x + d.x * t0, z0 = a.z + d.z * t0, y0 = a.y + d.y * t0 + 0.03;
            double x1 = a.x + d.x * t1, z1 = a.z + d.z * t1, y1 = a.y + d.y * t1 + 0.03;
            int alpha0 = alpha(t0), alpha1 = alpha(t1);
            vertex(vc, pose, normal, x0 - sx * w0, y0, z0 - sz * w0, alpha0);
            vertex(vc, pose, normal, x0 + sx * w0, y0, z0 + sz * w0, alpha0);
            vertex(vc, pose, normal, x1 + sx * w1, y1, z1 + sz * w1, alpha1);
            vertex(vc, pose, normal, x1 - sx * w1, y1, z1 - sz * w1, alpha1);
        }
    }

    private static float width(float t, float time) {
        float base = 0.22f + 0.16f * (float) Math.pow(Math.abs(t - 0.5f) * 2f, 2.0); // pools at both ends
        return base + 0.04f * Mth.sin(time * 0.35f + t * 9f);
    }

    private static int alpha(float t) {
        return 200 + Math.round(20 * Mth.sin(t * 6f));
    }

    private static void vertex(VertexConsumer vc, Matrix4f pose, Matrix3f normal, double x, double y, double z, int alpha) {
        vc.vertex(pose, (float) x, (float) y, (float) z).color(8, 8, 12, alpha).uv(0.5f, 0.5f).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT).normal(normal, 0f, 1f, 0f).endVertex();
    }
}
