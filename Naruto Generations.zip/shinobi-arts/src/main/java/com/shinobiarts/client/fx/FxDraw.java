package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Shapes for the jutsu effects: glowing ribbons and lightning bolts, tubes, cones, crystals, rings, spheres, boxes and
 * camera-facing sprites. Everything is drawn in world coordinates (the pose stack is already shifted by the camera).
 * A {@link Paint} says how a surface looks: a colour (on plain white, glowing or lit) or a block texture.
 */
public final class FxDraw {
    public static final ResourceLocation WHITE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/susanoo/white.png");
    public static final int FULL = LightTexture.FULL_BRIGHT;

    private FxDraw() {}

    // ---------------------------------------------------------------- how a surface looks

    /** A surface: where its texture comes from (u0..u1, v0..v1 of it), and its colour. */
    public record Paint(float u0, float v0, float u1, float v1, int r, int g, int b, int a) {
        public Paint alpha(float k) {
            return new Paint(u0, v0, u1, v1, r, g, b, Math.max(0, Math.min(255, Math.round(a * k))));
        }

        public Paint tint(int rr, int gg, int bb) {
            return new Paint(u0, v0, u1, v1, rr, gg, bb, a);
        }

        float u(float t) {
            return u0 + (u1 - u0) * t;
        }

        float v(float t) {
            return v0 + (v1 - v0) * t;
        }
    }

    /** A plain colour (on the white texture). */
    public static Paint color(int rgb, float alpha) {
        return new Paint(0.25f, 0.25f, 0.75f, 0.75f, (rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, Math.round(alpha * 255));
    }

    /** A colour for the additive glow ({@link #additive}): it can't fade by alpha, so the colour itself dims. */
    public static Paint addColor(int rgb, float alpha) {
        float k = Math.max(0f, Math.min(1f, alpha));
        return new Paint(0.25f, 0.25f, 0.75f, 0.75f, Math.round(((rgb >> 16) & 255) * k), Math.round(((rgb >> 8) & 255) * k),
                Math.round((rgb & 255) * k), 255);
    }

    /** A vanilla block texture (e.g. "block/oak_log") from the block atlas. */
    public static Paint block(String name, int rgb, float alpha) {
        TextureAtlasSprite s = Minecraft.getInstance().getTextureAtlas(TextureAtlas.LOCATION_BLOCKS).apply(new ResourceLocation(name));
        return new Paint(s.getU0(), s.getV0(), s.getU1(), s.getV1(), (rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, Math.round(alpha * 255));
    }

    /** Glowing, see-through colour (no lighting). */
    public static VertexConsumer glow(MultiBufferSource buffers) {
        return buffers.getBuffer(RenderType.entityTranslucentEmissive(WHITE));
    }

    /** Additive glow: brightens what's behind it (lightning, chakra). */
    public static VertexConsumer additive(MultiBufferSource buffers) {
        return buffers.getBuffer(RenderType.eyes(WHITE));
    }

    /** Lit, see-through colour. */
    public static VertexConsumer lit(MultiBufferSource buffers) {
        return buffers.getBuffer(RenderType.entityTranslucent(WHITE));
    }

    /** Lit block textures, solid. */
    public static VertexConsumer blocks(MultiBufferSource buffers) {
        return buffers.getBuffer(RenderType.entityCutoutNoCull(TextureAtlas.LOCATION_BLOCKS));
    }

    /** Lit block textures, see-through (ice). */
    public static VertexConsumer blocksTranslucent(MultiBufferSource buffers) {
        return buffers.getBuffer(RenderType.entityTranslucent(TextureAtlas.LOCATION_BLOCKS));
    }

    /** A texture of our own, glowing and see-through. */
    public static VertexConsumer glowTex(MultiBufferSource buffers, ResourceLocation tex) {
        return buffers.getBuffer(RenderType.entityTranslucentEmissive(tex));
    }

    /** A texture of our own, lit and see-through. */
    public static VertexConsumer litTex(MultiBufferSource buffers, ResourceLocation tex) {
        return buffers.getBuffer(RenderType.entityTranslucent(tex));
    }

    // ---------------------------------------------------------------- basics

    public static void vertex(VertexConsumer vc, PoseStack ps, Vec3 p, Paint paint, float u, float v, int light, Vec3 n) {
        Matrix4f m = ps.last().pose();
        Matrix3f nm = ps.last().normal();
        vc.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(paint.r, paint.g, paint.b, paint.a).uv(paint.u(u), paint.v(v))
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(nm, (float) n.x, (float) n.y, (float) n.z).endVertex();
    }

    /** A four-cornered face (both sides show with the effect render types). */
    public static void quad(VertexConsumer vc, PoseStack ps, Vec3 a, Vec3 b, Vec3 c, Vec3 d, Paint paint, int light) {
        Vec3 n = b.subtract(a).cross(d.subtract(a));
        n = n.lengthSqr() > 1e-12 ? n.normalize() : new Vec3(0, 1, 0);
        vertex(vc, ps, a, paint, 0, 0, light, n);
        vertex(vc, ps, b, paint, 0, 1, light, n);
        vertex(vc, ps, c, paint, 1, 1, light, n);
        vertex(vc, ps, d, paint, 1, 0, light, n);
    }

    /** A face with its own texture corners (u, v from 0 to 1 across the paint's texture). */
    public static void quadUv(VertexConsumer vc, PoseStack ps, Vec3 a, Vec3 b, Vec3 c, Vec3 d, float u0, float v0, float u1, float v1,
                              Paint paint, int light) {
        Vec3 n = b.subtract(a).cross(d.subtract(a));
        n = n.lengthSqr() > 1e-12 ? n.normalize() : new Vec3(0, 1, 0);
        vertex(vc, ps, a, paint, u0, v0, light, n);
        vertex(vc, ps, b, paint, u0, v1, light, n);
        vertex(vc, ps, c, paint, u1, v1, light, n);
        vertex(vc, ps, d, paint, u1, v0, light, n);
    }

    /** A triangle (drawn as a quad with a repeated corner). */
    public static void tri(VertexConsumer vc, PoseStack ps, Vec3 a, Vec3 b, Vec3 c, Paint paint, int light) {
        quad(vc, ps, a, b, c, c, paint, light);
    }

    public static Vec3 camRight(Camera cam) {
        Vector3f l = cam.getLeftVector();
        return new Vec3(-l.x(), -l.y(), -l.z());
    }

    public static Vec3 camUp(Camera cam) {
        Vector3f u = cam.getUpVector();
        return new Vec3(u.x(), u.y(), u.z());
    }

    /** Any unit vector at right angles to {@code v}. */
    public static Vec3 perpendicular(Vec3 v) {
        Vec3 a = Math.abs(v.y) < 0.9 ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        return v.cross(a).normalize();
    }

    /** A sprite facing the camera, {@code w} by {@code h} blocks, turned by {@code rot} radians. */
    public static void billboard(VertexConsumer vc, PoseStack ps, Camera cam, Vec3 c, float w, float h, float rot, Paint paint, int light) {
        Vec3 r = camRight(cam), u = camUp(cam);
        float cs = Mth.cos(rot), sn = Mth.sin(rot);
        Vec3 rr = r.scale(cs).add(u.scale(sn)), uu = u.scale(cs).subtract(r.scale(sn));
        Vec3 x = rr.scale(w / 2), y = uu.scale(h / 2);
        quadUv(vc, ps, c.subtract(x).subtract(y), c.subtract(x).add(y), c.add(x).add(y), c.add(x).subtract(y), 0, 1, 1, 0, paint, light);
    }

    // ---------------------------------------------------------------- strips

    /** A strip through {@code pts} that always faces the camera, {@code width} wide (tapering by {@code taper} to the end). */
    public static void ribbon(VertexConsumer vc, PoseStack ps, Vec3 cam, List<Vec3> pts, float width, float taper, Paint paint, Paint end, int light) {
        int n = pts.size();
        if (n < 2) return;
        Vec3[] side = new Vec3[n];
        for (int i = 0; i < n; i++) {
            Vec3 t = pts.get(Math.min(n - 1, i + 1)).subtract(pts.get(Math.max(0, i - 1)));
            Vec3 toCam = cam.subtract(pts.get(i));
            Vec3 s = t.cross(toCam);
            side[i] = s.lengthSqr() > 1e-10 ? s.normalize() : perpendicular(t.lengthSqr() > 1e-10 ? t : new Vec3(0, 1, 0));
        }
        for (int i = 0; i + 1 < n; i++) {
            float f0 = i / (float) (n - 1), f1 = (i + 1) / (float) (n - 1);
            float w0 = width * (1 - taper * f0) / 2, w1 = width * (1 - taper * f1) / 2;
            Paint p0 = mix(paint, end, f0), p1 = mix(paint, end, f1);
            Vec3 a = pts.get(i).add(side[i].scale(w0)), b = pts.get(i).subtract(side[i].scale(w0));
            Vec3 c = pts.get(i + 1).subtract(side[i + 1].scale(w1)), d = pts.get(i + 1).add(side[i + 1].scale(w1));
            Vec3 nrm = cam.subtract(pts.get(i)).normalize();
            vertex(vc, ps, a, p0, 0, f0, light, nrm);
            vertex(vc, ps, b, p0, 1, f0, light, nrm);
            vertex(vc, ps, c, p1, 1, f1, light, nrm);
            vertex(vc, ps, d, p1, 0, f1, light, nrm);
        }
    }

    public static Paint mix(Paint a, Paint b, float t) {
        if (a == b) return a;
        return new Paint(a.u0, a.v0, a.u1, a.v1, Math.round(a.r + (b.r - a.r) * t), Math.round(a.g + (b.g - a.g) * t),
                Math.round(a.b + (b.b - a.b) * t), Math.round(a.a + (b.a - a.a) * t));
    }

    /**
     * A jagged lightning bolt from {@code from} to {@code to}: a white-hot core inside a coloured glow, with forks.
     * The same seed always gives the same bolt; change it (e.g. every tick) to make it crackle.
     */
    public static void bolt(MultiBufferSource buffers, PoseStack ps, Vec3 cam, Vec3 from, Vec3 to, long seed, float jitter, float width,
                            int rgb, float alpha, int forks) {
        RandomSource r = RandomSource.create(seed);
        List<Vec3> pts = jagged(from, to, r, jitter, 5);
        VertexConsumer add = additive(buffers);
        ribbon(add, ps, cam, pts, width * 4.5f, 0.3f, addColor(rgb, alpha * 0.35f), addColor(rgb, alpha * 0.2f), FULL);
        ribbon(add, ps, cam, pts, width * 2f, 0.3f, addColor(rgb, alpha * 0.8f), addColor(rgb, alpha * 0.6f), FULL);
        ribbon(add, ps, cam, pts, width * 0.7f, 0.3f, addColor(0xFFFFFF, alpha), addColor(0xEEF6FF, alpha), FULL);
        for (int k = 0; k < forks && pts.size() > 3; k++) {
            int i = 1 + r.nextInt(pts.size() - 2);
            Vec3 at = pts.get(i);
            Vec3 dir = to.subtract(from);
            double len = dir.length() * (0.15 + r.nextDouble() * 0.25);
            Vec3 off = dir.normalize().add(perpendicular(dir).scale(r.nextGaussian() * 0.9)).add(0, r.nextGaussian() * 0.5, 0).normalize();
            List<Vec3> fork = jagged(at, at.add(off.scale(len)), r, jitter * 0.6f, 3);
            ribbon(add, ps, cam, fork, width * 2.2f, 0.9f, addColor(rgb, alpha * 0.4f), addColor(rgb, 0f), FULL);
            ribbon(add, ps, cam, fork, width * 0.5f, 0.9f, addColor(0xFFFFFF, alpha * 0.9f), addColor(0xFFFFFF, 0f), FULL);
        }
    }

    /** Midpoint displacement: a crooked line between two points ({@code depth} halvings). */
    public static List<Vec3> jagged(Vec3 from, Vec3 to, RandomSource r, float jitter, int depth) {
        List<Vec3> pts = new ArrayList<>();
        pts.add(from);
        pts.add(to);
        float j = jitter;
        for (int d = 0; d < depth; d++) {
            List<Vec3> next = new ArrayList<>();
            for (int i = 0; i + 1 < pts.size(); i++) {
                Vec3 a = pts.get(i), b = pts.get(i + 1);
                Vec3 mid = a.add(b).scale(0.5).add(r.nextGaussian() * j, r.nextGaussian() * j, r.nextGaussian() * j);
                next.add(a);
                next.add(mid);
            }
            next.add(pts.get(pts.size() - 1));
            pts = next;
            j *= 0.55f;
        }
        return pts;
    }

    // ---------------------------------------------------------------- solids

    /**
     * A tube along {@code pts} (radius per point), textured lengthwise ({@code vScale} texture lengths per block),
     * with its frames carried along the curve so it doesn't twist. Caps the first and last ends if {@code caps}.
     */
    public static void tube(VertexConsumer vc, PoseStack ps, List<Vec3> pts, float[] radii, int sides, Paint paint, float vScale, int light, boolean caps) {
        int n = pts.size();
        if (n < 2) return;
        Vec3[] t = new Vec3[n], nn = new Vec3[n], bb = new Vec3[n];
        for (int i = 0; i < n; i++) {
            Vec3 d = pts.get(Math.min(n - 1, i + 1)).subtract(pts.get(Math.max(0, i - 1)));
            t[i] = d.lengthSqr() > 1e-12 ? d.normalize() : (i > 0 ? t[i - 1] : new Vec3(0, 1, 0));
            Vec3 up = i == 0 ? perpendicular(t[0]) : nn[i - 1];
            Vec3 x = up.subtract(t[i].scale(up.dot(t[i])));
            nn[i] = x.lengthSqr() > 1e-12 ? x.normalize() : perpendicular(t[i]);
            bb[i] = t[i].cross(nn[i]).normalize();
        }
        double along = 0;
        for (int i = 0; i + 1 < n; i++) {
            double seg = pts.get(i).distanceTo(pts.get(i + 1));
            // block sprites can't repeat: each slice of the tube takes the texture from the top, as far as it reaches
            float v0 = 0f, v1 = (float) Math.min(1.0, seg * vScale);
            along += seg;
            for (int k = 0; k < sides; k++) {
                float a0 = Mth.TWO_PI * k / sides, a1 = Mth.TWO_PI * (k + 1) / sides;
                Vec3 d00 = nn[i].scale(Mth.cos(a0)).add(bb[i].scale(Mth.sin(a0)));
                Vec3 d01 = nn[i].scale(Mth.cos(a1)).add(bb[i].scale(Mth.sin(a1)));
                Vec3 d10 = nn[i + 1].scale(Mth.cos(a0)).add(bb[i + 1].scale(Mth.sin(a0)));
                Vec3 d11 = nn[i + 1].scale(Mth.cos(a1)).add(bb[i + 1].scale(Mth.sin(a1)));
                float u0 = k / (float) sides, u1 = (k + 1) / (float) sides;
                vertex(vc, ps, pts.get(i).add(d00.scale(radii[i])), paint, u0, v0, light, d00);
                vertex(vc, ps, pts.get(i + 1).add(d10.scale(radii[i + 1])), paint, u0, v1, light, d10);
                vertex(vc, ps, pts.get(i + 1).add(d11.scale(radii[i + 1])), paint, u1, v1, light, d11);
                vertex(vc, ps, pts.get(i).add(d01.scale(radii[i])), paint, u1, v0, light, d01);
            }
        }
        if (caps) {
            cap(vc, ps, pts.get(0), nn[0], bb[0], radii[0], sides, paint, light, t[0].scale(-1));
            cap(vc, ps, pts.get(n - 1), nn[n - 1], bb[n - 1], radii[n - 1], sides, paint, light, t[n - 1]);
        }
    }

    private static void cap(VertexConsumer vc, PoseStack ps, Vec3 c, Vec3 n, Vec3 b, float r, int sides, Paint paint, int light, Vec3 normal) {
        for (int k = 0; k < sides; k++) {
            float a0 = Mth.TWO_PI * k / sides, a1 = Mth.TWO_PI * (k + 1) / sides;
            Vec3 p0 = c.add(n.scale(Mth.cos(a0) * r)).add(b.scale(Mth.sin(a0) * r));
            Vec3 p1 = c.add(n.scale(Mth.cos(a1) * r)).add(b.scale(Mth.sin(a1) * r));
            vertex(vc, ps, c, paint, 0.5f, 0.5f, light, normal);
            vertex(vc, ps, p0, paint, 0.5f + 0.5f * Mth.cos(a0), 0.5f + 0.5f * Mth.sin(a0), light, normal);
            vertex(vc, ps, p1, paint, 0.5f + 0.5f * Mth.cos(a1), 0.5f + 0.5f * Mth.sin(a1), light, normal);
            vertex(vc, ps, p1, paint, 0.5f + 0.5f * Mth.cos(a1), 0.5f + 0.5f * Mth.sin(a1), light, normal);
        }
    }

    /** A cone from a round base to a point (a spike). */
    public static void cone(VertexConsumer vc, PoseStack ps, Vec3 base, Vec3 tip, float radius, int sides, Paint paint, int light) {
        Vec3 axis = tip.subtract(base);
        if (axis.lengthSqr() < 1e-10) return;
        Vec3 n = perpendicular(axis), b = axis.normalize().cross(n);
        for (int k = 0; k < sides; k++) {
            float a0 = Mth.TWO_PI * k / sides, a1 = Mth.TWO_PI * (k + 1) / sides;
            Vec3 d0 = n.scale(Mth.cos(a0)).add(b.scale(Mth.sin(a0))), d1 = n.scale(Mth.cos(a1)).add(b.scale(Mth.sin(a1)));
            Vec3 p0 = base.add(d0.scale(radius)), p1 = base.add(d1.scale(radius));
            float u0 = k / (float) sides, u1 = (k + 1) / (float) sides;
            Vec3 nm = d0.add(d1).normalize();
            vertex(vc, ps, p0, paint, u0, 1, light, nm);
            vertex(vc, ps, tip, paint, (u0 + u1) / 2, 0, light, nm);
            vertex(vc, ps, tip, paint, (u0 + u1) / 2, 0, light, nm);
            vertex(vc, ps, p1, paint, u1, 1, light, nm);
        }
    }

    /** A crystal: a prism with pointed ends, {@code len} long along {@code axis}, {@code radius} thick. */
    public static void crystal(VertexConsumer vc, PoseStack ps, Vec3 c, Vec3 axis, float len, float radius, int sides, Paint paint, int light) {
        Vec3 ax = axis.normalize();
        Vec3 n = perpendicular(ax), b = ax.cross(n);
        Vec3 top = c.add(ax.scale(len / 2)), bottom = c.subtract(ax.scale(len / 2));
        float body = len * 0.32f;
        Vec3 t1 = c.add(ax.scale(body / 2)), b1 = c.subtract(ax.scale(body / 2));
        for (int k = 0; k < sides; k++) {
            float a0 = Mth.TWO_PI * k / sides, a1 = Mth.TWO_PI * (k + 1) / sides;
            Vec3 d0 = n.scale(Mth.cos(a0)).add(b.scale(Mth.sin(a0))).scale(radius), d1 = n.scale(Mth.cos(a1)).add(b.scale(Mth.sin(a1))).scale(radius);
            quadUv(vc, ps, b1.add(d0), t1.add(d0), t1.add(d1), b1.add(d1), k / (float) sides, 0.35f, (k + 1) / (float) sides, 0.65f, paint, light);
            quadUv(vc, ps, t1.add(d0), top, top, t1.add(d1), k / (float) sides, 0f, (k + 1) / (float) sides, 0.35f, paint, light);
            quadUv(vc, ps, b1.add(d1), bottom, bottom, b1.add(d0), k / (float) sides, 0.65f, (k + 1) / (float) sides, 1f, paint, light);
        }
    }

    /** A flat ring facing along {@code normal}. */
    public static void ring(VertexConsumer vc, PoseStack ps, Vec3 c, Vec3 normal, float radius, float width, int segments, Paint inner, Paint outer, int light) {
        Vec3 ax = normal.normalize();
        Vec3 n = perpendicular(ax), b = ax.cross(n);
        float ri = radius - width / 2, ro = radius + width / 2;
        for (int k = 0; k < segments; k++) {
            float a0 = Mth.TWO_PI * k / segments, a1 = Mth.TWO_PI * (k + 1) / segments;
            Vec3 d0 = n.scale(Mth.cos(a0)).add(b.scale(Mth.sin(a0))), d1 = n.scale(Mth.cos(a1)).add(b.scale(Mth.sin(a1)));
            vertex(vc, ps, c.add(d0.scale(ri)), inner, 0, 0, light, ax);
            vertex(vc, ps, c.add(d0.scale(ro)), outer, 0, 1, light, ax);
            vertex(vc, ps, c.add(d1.scale(ro)), outer, 1, 1, light, ax);
            vertex(vc, ps, c.add(d1.scale(ri)), inner, 1, 0, light, ax);
        }
    }

    /** A sphere ({@code lat} x {@code lon} faces). */
    public static void sphere(VertexConsumer vc, PoseStack ps, Vec3 c, float r, int lat, int lon, Paint paint, int light) {
        for (int i = 0; i < lat; i++) {
            float t0 = Mth.PI * i / lat, t1 = Mth.PI * (i + 1) / lat;
            for (int j = 0; j < lon; j++) {
                float p0 = Mth.TWO_PI * j / lon, p1 = Mth.TWO_PI * (j + 1) / lon;
                Vec3 a = dir(t0, p0), b = dir(t1, p0), cc = dir(t1, p1), d = dir(t0, p1);
                vertex(vc, ps, c.add(a.scale(r)), paint, j / (float) lon, i / (float) lat, light, a);
                vertex(vc, ps, c.add(b.scale(r)), paint, j / (float) lon, (i + 1) / (float) lat, light, b);
                vertex(vc, ps, c.add(cc.scale(r)), paint, (j + 1) / (float) lon, (i + 1) / (float) lat, light, cc);
                vertex(vc, ps, c.add(d.scale(r)), paint, (j + 1) / (float) lon, i / (float) lat, light, d);
            }
        }
    }

    private static Vec3 dir(float theta, float phi) {
        return new Vec3(Mth.sin(theta) * Mth.cos(phi), Mth.cos(theta), Mth.sin(theta) * Mth.sin(phi));
    }

    /** A box with its own axes (half sizes along each), every face textured with the whole paint. */
    public static void box(VertexConsumer vc, PoseStack ps, Vec3 c, Vec3 x, Vec3 y, Vec3 z, Paint paint, int light) {
        Vec3[] q = new Vec3[8];
        int i = 0;
        for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) for (int sz = -1; sz <= 1; sz += 2) {
            q[i++] = c.add(x.scale(sx)).add(y.scale(sy)).add(z.scale(sz));
        }
        quad(vc, ps, q[0], q[1], q[3], q[2], paint, light);
        quad(vc, ps, q[4], q[6], q[7], q[5], paint, light);
        quad(vc, ps, q[0], q[4], q[5], q[1], paint, light);
        quad(vc, ps, q[2], q[3], q[7], q[6], paint, light);
        quad(vc, ps, q[0], q[2], q[6], q[4], paint, light);
        quad(vc, ps, q[1], q[5], q[7], q[3], paint, light);
    }

    /** Light where something is (so lit shapes match their surroundings). */
    public static int lightAt(Vec3 p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return FULL;
        return net.minecraft.client.renderer.LevelRenderer.getLightColor(mc.level, net.minecraft.core.BlockPos.containing(p));
    }

    /** A random generator for an effect's shapes (the same for every player). */
    public static RandomSource rng(long seed, int salt) {
        return RandomSource.create(seed * 341873128712L + salt * 132897987541L);
    }

    /** Smoothstep. */
    public static float smooth(float t) {
        t = Mth.clamp(t, 0f, 1f);
        return t * t * (3 - 2 * t);
    }

    /** Where the ground is under a point (client side), searching a few blocks up and down. */
    public static double groundY(Vec3 p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return p.y;
        net.minecraft.core.BlockPos.MutableBlockPos pos = new net.minecraft.core.BlockPos.MutableBlockPos();
        int x = Mth.floor(p.x), z = Mth.floor(p.z), y0 = Mth.floor(p.y);
        for (int dy = 3; dy >= -6; dy--) {
            pos.set(x, y0 + dy - 1, z);
            if (!mc.level.getBlockState(pos).getCollisionShape(mc.level, pos).isEmpty()) {
                pos.set(x, y0 + dy, z);
                if (mc.level.getBlockState(pos).getCollisionShape(mc.level, pos).isEmpty()) return y0 + dy;
            }
        }
        return p.y;
    }
}
