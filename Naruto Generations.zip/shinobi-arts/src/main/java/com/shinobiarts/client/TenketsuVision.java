package com.shinobiarts.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * The Byakugan's view of the chakra network: while your Byakugan is on, every living creature within 40 blocks shows
 * (through walls) its chakra pathways as faint blue lines and its chakra points as glowing dots, pulsing gently.
 * A player's damaged points show red (how many is in their look bits).
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class TenketsuVision {
    private TenketsuVision() {}

    private static final double RANGE = 40;

    /**
     * The points on a body: {side (-1..1 of half the width), height (0..1 of the height), forward (of half the width)}.
     * The first eight are the ones that go red first when damaged (in that order).
     */
    private static final float[][] POINTS = {
            {0f, 0.70f, 0.55f}, {-0.45f, 0.62f, 0.5f}, {0.45f, 0.62f, 0.5f}, {0f, 0.56f, 0.55f},
            {0f, 0.83f, 0.45f}, {-0.9f, 0.55f, 0.15f}, {0.9f, 0.55f, 0.15f}, {0f, 0.94f, 0.5f},
            // head
            {-0.25f, 0.96f, 0.45f}, {0.25f, 0.96f, 0.45f}, {0f, 0.88f, 0.5f},
            // chest and belly
            {-0.3f, 0.72f, 0.55f}, {0.3f, 0.72f, 0.55f}, {-0.3f, 0.5f, 0.5f}, {0.3f, 0.5f, 0.5f}, {0f, 0.45f, 0.5f},
            // shoulders, elbows, wrists
            {-0.8f, 0.74f, 0.2f}, {0.8f, 0.74f, 0.2f}, {-1.0f, 0.42f, 0.2f}, {1.0f, 0.42f, 0.2f},
            // hips, knees, ankles
            {-0.35f, 0.4f, 0.4f}, {0.35f, 0.4f, 0.4f}, {-0.35f, 0.22f, 0.4f}, {0.35f, 0.22f, 0.4f},
            {-0.35f, 0.05f, 0.35f}, {0.35f, 0.05f, 0.35f},
    };
    /** The pathways: pairs of point indices. */
    private static final int[][] LINES = {
            {7, 10}, {10, 4}, {4, 0}, {0, 3}, {3, 15}, {8, 10}, {9, 10},
            {4, 11}, {4, 12}, {11, 1}, {12, 2}, {1, 13}, {2, 14}, {13, 15}, {14, 15},
            {4, 16}, {4, 17}, {16, 5}, {17, 6}, {5, 18}, {6, 19},
            {15, 20}, {15, 21}, {20, 22}, {21, 23}, {22, 24}, {23, 25},
    };

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_WEATHER) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.isInitialized() || !d.isDojutsuActive() || d.getActiveDojutsu() != Dojutsu.BYAKUGAN) return;
        float partial = event.getPartialTick();
        float t = mc.level.getGameTime() + partial;
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = ps.last().pose();
        Vector3f left = camera.getLeftVector(), up = camera.getUpVector();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.SRC_ALPHA,
                com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        int drawn = 0;
        Vec3[] world = new Vec3[POINTS.length];
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(RANGE),
                c -> c != player && c.isAlive() && !(c instanceof ArmorStand) && !c.isInvisible())) {
            double dist = Math.sqrt(e.distanceToSqr(player));
            if (dist > RANGE) continue;
            float fade = (float) Mth.clamp((RANGE - dist) / 10.0, 0.2, 1.0);
            int damaged = e instanceof Player ? SharinganManager.lookTenketsu(ClientEyes.look(e)) : 0;
            Vec3 pos = e.getPosition(partial);
            float yaw = Mth.rotLerp(partial, e.yBodyRotO, e.yBodyRot) * Mth.DEG_TO_RAD;
            double fx = -Mth.sin(yaw), fz = Mth.cos(yaw), rx = -fz, rz = fx;           // forward, and to its left
            float hw = e.getBbWidth() * 0.5f, h = e.getBbHeight();
            for (int i = 0; i < POINTS.length; i++) {
                float[] q = POINTS[i];
                world[i] = pos.add(rx * q[0] * hw + fx * q[2] * hw * 0.6, q[1] * h, rz * q[0] * hw + fz * q[2] * hw * 0.6);
            }
            for (int[] l : LINES) line(bb, m, cam, world[l[0]], world[l[1]], 0.018f * h, 0.35f, 0.75f, 1f, 0.22f * fade);
            for (int i = 0; i < POINTS.length; i++) {
                boolean bad = i < damaged;
                float pulse = 0.75f + 0.25f * Mth.sin(t * 0.25f + i * 0.9f + e.getId());
                float s = 0.045f * h * (bad ? 1.5f : 1f) * pulse;
                if (bad) diamond(bb, m, world[i], left, up, s, 1f, 0.15f, 0.12f, 0.95f * fade);
                else diamond(bb, m, world[i], left, up, s, 0.55f, 0.9f, 1f, 0.8f * fade);
            }
            drawn++;
        }
        if (drawn > 0) BufferUploader.drawWithShader(bb.end());
        else bb.end();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        ps.popPose();
    }

    private static void diamond(BufferBuilder bb, Matrix4f m, Vec3 c, Vector3f left, Vector3f up, float s, float r, float g, float b, float a) {
        float lx = left.x() * s, ly = left.y() * s, lz = left.z() * s, ux = up.x() * s, uy = up.y() * s, uz = up.z() * s;
        bb.vertex(m, (float) c.x + ux, (float) c.y + uy, (float) c.z + uz).color(r, g, b, a).endVertex();
        bb.vertex(m, (float) c.x + lx, (float) c.y + ly, (float) c.z + lz).color(r, g, b, a).endVertex();
        bb.vertex(m, (float) c.x - ux, (float) c.y - uy, (float) c.z - uz).color(r, g, b, a).endVertex();
        bb.vertex(m, (float) c.x - lx, (float) c.y - ly, (float) c.z - lz).color(r, g, b, a).endVertex();
    }

    /** A thin strip from a to b, turned to face the camera. */
    private static void line(BufferBuilder bb, Matrix4f m, Vec3 cam, Vec3 a, Vec3 b, float w, float r, float g, float bl, float alpha) {
        Vec3 dir = b.subtract(a);
        Vec3 side = dir.cross(a.add(b).scale(0.5).subtract(cam));
        if (side.lengthSqr() < 1e-8) return;
        side = side.normalize().scale(w);
        bb.vertex(m, (float) (a.x + side.x), (float) (a.y + side.y), (float) (a.z + side.z)).color(r, g, bl, alpha).endVertex();
        bb.vertex(m, (float) (a.x - side.x), (float) (a.y - side.y), (float) (a.z - side.z)).color(r, g, bl, alpha).endVertex();
        bb.vertex(m, (float) (b.x - side.x), (float) (b.y - side.y), (float) (b.z - side.z)).color(r, g, bl, alpha).endVertex();
        bb.vertex(m, (float) (b.x + side.x), (float) (b.y + side.y), (float) (b.z + side.z)).color(r, g, bl, alpha).endVertex();
    }
}
