package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Yin-Yang Release: the black Yin blades' cuts, and the Yang Burst's dome of light. */
final class FxYinYang {
    private FxYinYang() {}

    /** One cut (a = where it starts, b = how far it reaches, size = the cut's tilt in degrees): a black crescent sweeping across. */
    static void slash(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        Vec3 fwd = b.subtract(a);
        double reach = fwd.length();
        if (reach < 1e-3) return;
        fwd = fwd.scale(1 / reach);
        Vec3 side = FxDraw.perpendicular(fwd);
        Vec3 up = fwd.cross(side).normalize();
        double tilt = Math.toRadians(c.fx().size);
        Vec3 across = side.scale(Math.cos(tilt)).add(up.scale(Math.sin(tilt)));
        float p = c.progress();
        float sweep = Mth.clamp(p * 2.2f, 0f, 1f), fade = 1f - Mth.clamp((p - 0.45f) / 0.55f, 0f, 1f);
        if (fade <= 0) return;
        List<Vec3> arc = new ArrayList<>();
        for (int i = 0; i <= 18; i++) {
            float u = i / 18f;
            if (u > sweep) break;
            double ang = Math.toRadians(-70 + 140 * u);
            arc.add(a.add(fwd.scale(Math.cos(ang) * reach * 0.6 + 1.0)).add(across.scale(Math.sin(ang) * reach * 0.6)));
        }
        if (arc.size() < 2) return;
        FxDraw.ribbon(FxDraw.lit(c.buffers()), c.ps(), c.cam(), arc, 1.1f, 0.6f, FxDraw.color(0x0A0410, 0.2f * fade),
                FxDraw.color(0x14081E, 0.95f * fade), FxDraw.FULL);
        FxDraw.ribbon(FxDraw.additive(c.buffers()), c.ps(), c.cam(), arc, 0.35f, 0.6f, FxDraw.addColor(0x6A2AB0, 0f),
                FxDraw.addColor(0xB070FF, 0.6f * fade), FxDraw.FULL);
    }

    /** The Yang Burst (a = centre, size = radius): a white-gold flash and a dome of light swelling out and fading. */
    static void burst(FxClient.Ctx c) {
        Vec3 o = c.fx().a;
        float p = c.progress(), R = c.fx().size;
        float grow = FxDraw.smooth(Math.min(1f, p * 1.6f));
        float fade = 1f - FxDraw.smooth(p);
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.sphere(add, c.ps(), o, R * grow, 14, 22, FxDraw.addColor(0xFFE8A0, 0.35f * fade), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), o, R * 0.45f * grow, 12, 18, FxDraw.addColor(0xFFFFFF, 0.6f * fade), FxDraw.FULL);
        FxDraw.ring(add, c.ps(), new Vec3(o.x, FxDraw.groundY(o) + 0.05, o.z), new Vec3(0, 1, 0), R * grow * 1.1f, 1.2f, 64,
                FxDraw.addColor(0xFFF0C0, 0.7f * fade), FxDraw.addColor(0xFFC060, 0f), FxDraw.FULL);
    }

    /** Izanagi active (entityA): a faint, slow-turning red ring at their feet and a red shimmer over them. */
    static void izanagi(FxClient.Ctx c) {
        net.minecraft.world.entity.Entity e = c.fx().entityA();
        if (e == null) return;
        Vec3 base = e.getPosition(c.partial());
        float t = c.age();
        float fade = Math.min(1f, t / 10f) * (1f - Mth.clamp((t - c.fx().ticks + 20) / 20f, 0f, 1f));
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.ring(add, c.ps(), new Vec3(base.x, FxDraw.groundY(base.add(0, 1, 0)) + 0.04, base.z), new Vec3(0, 1, 0),
                1.1f + 0.08f * Mth.sin(t * 0.2f), 0.18f, 48, FxDraw.addColor(0xD01818, 0.55f * fade), FxDraw.addColor(0x600000, 0f), FxDraw.FULL);
        for (int k = 0; k < 3; k++) {
            double a = t * 0.05 + k * Math.PI * 2 / 3;
            Vec3 p = base.add(Math.cos(a) * 1.1, 0.06, Math.sin(a) * 1.1);
            FxDraw.billboard(add, c.ps(), c.camera(), p, 0.18f, 0.18f, 0, FxDraw.addColor(0xFF3030, 0.8f * fade), FxDraw.FULL);
        }
    }

    /** Reality rewritten (a = where they come back): a burst of red light folding in on itself. */
    static void rewrite(FxClient.Ctx c) {
        Vec3 o = c.fx().a;
        float p = c.progress();
        float r = (1f - FxDraw.smooth(p)) * 2.5f + 0.1f;
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.sphere(add, c.ps(), o, r, 12, 18, FxDraw.addColor(0xFF2020, 0.35f * (1f - p)), FxDraw.FULL);
        FxDraw.billboard(add, c.ps(), c.camera(), o, 3f * (1f - p) + 0.4f, 3f * (1f - p) + 0.4f, p * 6f,
                FxDraw.addColor(0xFFE0E0, 0.7f * (1f - p)), FxDraw.FULL);
    }

    /** Izanami's loop (a = the spot it keeps returning to): a dim red circle there, with a slow pulse each loop. */
    static void izanamiLoop(FxClient.Ctx c) {
        Vec3 o = c.fx().a;
        float t = c.age();
        float fade = Math.min(1f, t / 10f) * (1f - Mth.clamp((t - c.fx().ticks + 15) / 15f, 0f, 1f));
        float pulse = 1f - ((t % 60f) / 60f);
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.ring(add, c.ps(), o, new Vec3(0, 1, 0), 0.9f, 0.12f, 40, FxDraw.addColor(0xB01010, 0.6f * fade), FxDraw.addColor(0x400000, 0f), FxDraw.FULL);
        FxDraw.ring(add, c.ps(), o, new Vec3(0, 1, 0), 0.9f + 1.6f * (1f - pulse), 0.25f, 40, FxDraw.addColor(0xFF4040, 0.45f * pulse * fade),
                FxDraw.addColor(0x400000, 0f), FxDraw.FULL);
    }
}
