package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.item.NinjaWeaponItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;

/**
 * Dual wield: while you hold Kiba or Kabutowari and your off hand is empty, the off hand shows the second blade (or the
 * hammer) - raised like a held item in third person (OffhandWeaponLayer draws it) and drawn in first person here.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class DualWieldRender {
    private DualWieldRender() {}

    /** The 3D models drawn in the off hand (registered in ClientSetup so they're baked). */
    public static ResourceLocation modelId(String name) {
        return new ResourceLocation(ShinobiArts.MODID, "item/3d/" + name);
    }

    /** The model for this entity's empty off hand, or null (off hand not empty, or the weapon isn't dual). */
    @Nullable
    public static BakedModel offhandModel(LivingEntity entity) {
        if (!entity.getOffhandItem().isEmpty()) return null;
        if (!(entity.getMainHandItem().getItem() instanceof NinjaWeaponItem weapon) || weapon.offhandModel() == null) return null;
        return Minecraft.getInstance().getModelManager().getModel(modelId(weapon.offhandModel()));
    }

    /** Third person: the off arm comes up like it's holding something. */
    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre event) {
        Player p = event.getEntity();
        if (offhandModel(p) == null) return;
        PlayerModel<AbstractClientPlayer> model = event.getRenderer().getModel();
        if (p.getMainArm() == HumanoidArm.RIGHT) model.leftArmPose = HumanoidModel.ArmPose.ITEM;
        else model.rightArmPose = HumanoidModel.ArmPose.ITEM;
    }

    /** First person: the off-hand model where vanilla would draw an off-hand item (ItemInHandRenderer.renderArmWithItem). */
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (event.getHand() != InteractionHand.OFF_HAND || !event.getItemStack().isEmpty()) return;
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || player.isInvisible()) return;
        BakedModel model = offhandModel(player);
        if (model == null) return;
        HumanoidArm arm = player.getMainArm().getOpposite();
        boolean right = arm == HumanoidArm.RIGHT;
        float s = right ? 1f : -1f;
        float swing = event.getSwingProgress(), equip = event.getEquipProgress();
        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        float root = Mth.sqrt(swing);
        ps.translate(s * -0.4f * Mth.sin(root * Mth.PI), 0.2f * Mth.sin(root * (Mth.PI * 2f)), -0.2f * Mth.sin(swing * Mth.PI));
        ps.translate(s * 0.56f, -0.52f + equip * -0.6f, -0.72f);                         // applyItemArmTransform
        float f = Mth.sin(swing * swing * Mth.PI);                                       // applyItemArmAttackTransform
        ps.mulPose(Axis.YP.rotationDegrees(s * (45f + f * -20f)));
        float f1 = Mth.sin(root * Mth.PI);
        ps.mulPose(Axis.ZP.rotationDegrees(s * f1 * -20f));
        ps.mulPose(Axis.XP.rotationDegrees(f1 * -80f));
        ps.mulPose(Axis.YP.rotationDegrees(s * -45f));
        Minecraft.getInstance().getItemRenderer().render(player.getMainHandItem(),
                right ? ItemDisplayContext.FIRST_PERSON_RIGHT_HAND : ItemDisplayContext.FIRST_PERSON_LEFT_HAND, !right, ps,
                event.getMultiBufferSource(), event.getPackedLight(), OverlayTexture.NO_OVERLAY, model);
        ps.popPose();
    }
}
