package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxClient;
import com.shinobiarts.fx.Fx;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Quaternionf;

import java.util.HashSet;
import java.util.Set;

/**
 * Kamui's warp seen on the body: someone being taken twists round and round, squeezed thinner and smaller into the
 * vortex until they're gone; someone arriving untwists out of it.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class KamuiRender {
    private static final Set<Integer> TWISTED = new HashSet<>();

    private KamuiRender() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderPre(RenderLivingEvent.Pre<?, ?> event) {
        LivingEntity e = event.getEntity();
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (FxClient.Active fx : FxClient.active()) {
            if ((fx.type != Fx.Visual.KAMUI_SWIRL && fx.type != Fx.Visual.KAMUI_ARRIVE) || fx.entityA != e.getId()) continue;
            float age = mc.level.getGameTime() - fx.start + event.getPartialTick();
            if (age < 0 || age > fx.ticks) continue;
            float t = Math.min(1f, age / fx.ticks);
            float gone = fx.type == Fx.Visual.KAMUI_SWIRL ? t * t : (1 - t) * (1 - t);   // 0 whole, 1 vanished
            if (gone > 0.985f) {                                         // nothing left to draw
                event.setCanceled(true);
                return;
            }
            float h = e.getBbHeight() * 0.6f;
            PoseStack ps = event.getPoseStack();
            ps.pushPose();
            ps.translate(0, h, 0);
            ps.mulPose(new Quaternionf().rotateY(gone * 14f));
            ps.scale(1f - gone * 0.97f, 1f - gone * 0.9f, 1f - gone * 0.97f);
            ps.mulPose(new Quaternionf().rotateY(-gone * 6f));
            ps.translate(0, -h, 0);
            TWISTED.add(e.getId());
            return;
        }
    }

    @SubscribeEvent
    public static void onRenderPost(RenderLivingEvent.Post<?, ?> event) {
        if (TWISTED.remove(event.getEntity().getId())) event.getPoseStack().popPose();
    }
}
