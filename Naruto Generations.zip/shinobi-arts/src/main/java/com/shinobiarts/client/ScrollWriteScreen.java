package com.shinobiarts.client;

import com.shinobiarts.item.BlankScrollItem;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.network.ScrollWritePacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

/** Writing on a blank scroll: a title line and the body, on a paper-coloured page. Done saves it to the scroll. */
public class ScrollWriteScreen extends Screen {
    private final InteractionHand hand;
    private final String startTitle, startText;
    private EditBox title;
    private MultiLineEditBox body;

    public ScrollWriteScreen(InteractionHand hand, ItemStack stack) {
        super(Component.translatable("screen.shinobiarts.scroll_write"));
        this.hand = hand;
        this.startTitle = BlankScrollItem.title(stack);
        this.startText = BlankScrollItem.text(stack);
    }

    @Override
    protected void init() {
        int w = 240, x = (this.width - w) / 2, y = (this.height - 200) / 2;
        title = new EditBox(this.font, x + 8, y + 8, w - 16, 16, Component.translatable("screen.shinobiarts.scroll_title"));
        title.setMaxLength(BlankScrollItem.MAX_TITLE);
        title.setHint(Component.translatable("screen.shinobiarts.scroll_title"));
        title.setValue(startTitle);
        addRenderableWidget(title);
        body = new MultiLineEditBox(this.font, x + 8, y + 30, w - 16, 136, Component.translatable("screen.shinobiarts.scroll_hint"),
                Component.translatable("screen.shinobiarts.scroll_text"));
        body.setCharacterLimit(BlankScrollItem.MAX_TEXT);
        body.setValue(startText);
        addRenderableWidget(body);
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> save()).bounds(x + 8, y + 172, (w - 24) / 2, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.cancel"), b -> onClose()).bounds(x + 16 + (w - 24) / 2, y + 172, (w - 24) / 2, 20).build());
        setInitialFocus(body);
    }

    private void save() {
        ModNetwork.toServer(new ScrollWritePacket(hand, title.getValue(), body.getValue()));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        int w = 240, x = (this.width - w) / 2, y = (this.height - 200) / 2;
        g.fill(x - 2, y - 2, x + w + 2, y + 200, 0xFF6A5232);
        g.fill(x, y, x + w, y + 198, 0xFFEBDDB4);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
