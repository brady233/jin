package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.client.ClientEyes;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.ninja.TailedBeast;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * The Tailed Beast Bomb, in the colours of the beast that fires it: black and white chakra spiralling in to a ball
 * in front of the mouth, the dark ball flying, and the dome of the blast where it lands.
 */
final class FxBeast {
    private FxBeast() {}

    /** The beast's chakra colour of whoever fired it (orange if they can't be seen). */
    private static int color(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        TailedBeast b = e == null ? null : TailedBeast.byTails(SharinganManager.lookBeast(ClientEyes.look(e)));
        return b == null ? 0xFF7A1A : b.color;
    }

    /** The ball itself: a dark core with a purple sheen, a rim of the beast's colour and a bright edge. */
    private static void ball(FxClient.Ctx c, Vec3 at, float r, int color, float a) {
        VertexConsumer lit = FxDraw.glow(c.buffers());
        FxDraw.sphere(lit, c.ps(), at, r, 10, 14, FxDraw.color(0x0C0812, 0.96f * a), FxDraw.FULL);
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.sphere(add, c.ps(), at, r * 1.12f, 10, 14, FxDraw.addColor(0x6A3AA0, 0.35f * a), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), at, r * 1.3f, 10, 14, FxDraw.addColor(color, 0.3f * a), FxDraw.FULL);
        float t = c.age();
        for (int k = 0; k < 3; k++) {
            Vec3 axis = new Vec3(Mth.cos(t * 0.3f + k * 2.1f), Mth.sin(t * 0.21f + k), Mth.sin(t * 0.3f + k * 2.1f));
            FxDraw.ring(add, c.ps(), at, axis, r * 1.2f, r * 0.12f, 28, FxDraw.addColor(0xFFFFFF, 0.5f * a), FxDraw.addColor(color, 0f), FxDraw.FULL);
        }
    }

    /** Gathering: streams of black, white and the beast's chakra spiral in and the ball grows. */
    static void charge(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        Vec3 at = c.fx().a;
        if (e != null) {
            Vec3 look = e.getViewVector(c.partial());
            at = e.getEyePosition(c.partial()).add(look.scale(1.4)).subtract(0, 0.2, 0);
        }
        float p = c.progress(), s = c.fx().size;
        int color = color(c);
        ball(c, at, (0.12f + 0.55f * FxDraw.smooth(p)) * s, color, 1f);
        RandomSource r = FxDraw.rng(c.fx().seed, 9);
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (int k = 0; k < 10; k++) {
            Vec3 from = new Vec3(r.nextGaussian(), r.nextGaussian() * 0.6, r.nextGaussian()).normalize().scale(2.6 * s);
            float phase = (c.age() * 0.09f + k * 0.13f) % 1f;
            List<Vec3> pts = new ArrayList<>();
            for (int i = 0; i <= 8; i++) {
                float t = phase + (1 - phase) * i / 8f;
                Vec3 q = from.scale(1 - t);
                Vec3 sw = q.cross(new Vec3(0, 1, 0)).scale(0.6 * (1 - t));
                pts.add(at.add(q).add(sw));
            }
            int col = k % 3 == 0 ? 0xFFFFFF : k % 3 == 1 ? 0x4A2A70 : color;
            FxDraw.ribbon(add, c.ps(), c.cam(), pts, 0.14f * s, 0.6f, FxDraw.addColor(col, 0.1f), FxDraw.addColor(col, 0.8f), FxDraw.FULL);
        }
    }

    /** In flight: the ball tearing from a to b, a shock ring trailing it. */
    static void bomb(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        float p = c.progress(), s = c.fx().size;
        Vec3 at = a.lerp(b, p);
        Vec3 dir = b.subtract(a);
        if (dir.lengthSqr() < 1e-6) return;
        dir = dir.normalize();
        int color = color(c);
        ball(c, at, 0.75f * s, color, 1f);
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (int k = 1; k <= 3; k++) {
            FxDraw.ring(add, c.ps(), at.subtract(dir.scale(k * 0.9 * s)), dir, (0.8f + k * 0.25f) * s, 0.1f * s, 28,
                    FxDraw.addColor(color, 0.5f / k), FxDraw.addColor(color, 0f), FxDraw.FULL);
        }
        List<Vec3> trail = List.of(at.subtract(dir.scale(5 * s)), at.subtract(dir.scale(2.5 * s)), at);
        FxDraw.ribbon(add, c.ps(), c.cam(), trail, 1.0f * s, 0.2f, FxDraw.addColor(color, 0f), FxDraw.addColor(color, 0.45f), FxDraw.FULL);
    }

    /** The blast (size = its radius): a flash, a dome of the beast's colour swelling out, a shock ring along the ground. */
    static void blast(FxClient.Ctx c) {
        Vec3 o = c.fx().a;
        float p = c.progress(), R = c.fx().size;
        int color = color(c);
        VertexConsumer add = FxDraw.additive(c.buffers());
        float g = FxDraw.smooth(Math.min(1f, p * 2.2f));
        float fade = 1f - FxDraw.smooth(Math.max(0f, (p - 0.35f) / 0.65f));
        FxDraw.sphere(add, c.ps(), o, R * (0.2f + 0.95f * g), 12, 18, FxDraw.addColor(color, 0.7f * fade), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), o, R * (0.1f + 0.6f * g), 12, 18, FxDraw.addColor(0xFFFFFF, 0.8f * fade * (1 - p)), FxDraw.FULL);
        FxDraw.sphere(FxDraw.glow(c.buffers()), c.ps(), o, R * 0.35f * (1 - p), 10, 14, FxDraw.color(0x0C0812, 0.9f * (1 - p)), FxDraw.FULL);
        double gy = FxDraw.groundY(o) + 0.1;
        float sr = R * (0.3f + 1.8f * FxDraw.smooth(p));
        FxDraw.ring(add, c.ps(), new Vec3(o.x, gy, o.z), new Vec3(0, 1, 0), sr, R * 0.25f * (1 - p), 64, FxDraw.addColor(0xFFFFFF, 0.8f * (1 - p)),
                FxDraw.addColor(color, 0f), FxDraw.FULL);
    }
}
