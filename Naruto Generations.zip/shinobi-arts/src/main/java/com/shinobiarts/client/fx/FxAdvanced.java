package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.jutsu.AdvancedJutsu;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * The advanced natures' jutsu: Lava Release's molten rocks, quicklime and corrosive lava; Storm Release's bending
 * beams of light and its storm cloud; Boil Release's acid mist and steam; Scorch Release's little suns.
 */
final class FxAdvanced {
    private FxAdvanced() {}

    private static final int LAVA = 0xFF6A1A, LAVA_HOT = 0xFFC040, CRUST = 0x2A1410, LIME = 0xEEEAE0, LASER = 0x8AE4FF,
            STEAM = 0xF2F4F6, ACID = 0xE4ECC4, SUN = 0xFFB040, SUN_CORE = 0xFFF4C8;

    private static float fadeOut(FxClient.Ctx c, float last) {
        return 1f - Mth.clamp((c.age() - (c.fx().ticks - last)) / last, 0f, 1f);
    }

    // ---------------------------------------------------------------- Lava Release

    /** A molten rock arcing from a to b: a dark crust with glowing cracks, trailing smoke and embers. */
    static void lavaRock(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        float p = c.progress();
        double dist = a.distanceTo(b);
        Vec3 at = arc(a, b, p, dist);
        float r = c.fx().size * 0.55f;
        FxDraw.sphere(FxDraw.lit(c.buffers()), c.ps(), at, r, 6, 8, FxDraw.color(CRUST, 1f), FxDraw.lightAt(at));
        VertexConsumer add = FxDraw.additive(c.buffers());
        float flick = 0.75f + 0.25f * Mth.sin(c.age() * 1.7f + c.fx().seed);
        FxDraw.sphere(add, c.ps(), at, r * 1.08f, 6, 8, FxDraw.addColor(LAVA, 0.8f * flick), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), at, r * 1.6f, 6, 8, FxDraw.addColor(LAVA, 0.25f), FxDraw.FULL);
        List<Vec3> trail = new ArrayList<>();
        for (int k = 0; k <= 6; k++) trail.add(arc(a, b, Math.max(0f, p - k * 0.05f), dist));
        java.util.Collections.reverse(trail);
        FxDraw.ribbon(add, c.ps(), c.cam(), trail, r * 1.4f, 0.1f, FxDraw.addColor(LAVA, 0f), FxDraw.addColor(LAVA_HOT, 0.6f), FxDraw.FULL);
        FxDraw.ribbon(FxDraw.lit(c.buffers()), c.ps(), c.cam(), trail, r * 2.2f, 0.4f, FxDraw.color(0x3A3634, 0f), FxDraw.color(0x3A3634, 0.35f),
                FxDraw.lightAt(at));
    }

    private static Vec3 arc(Vec3 a, Vec3 b, float t, double dist) {
        return a.lerp(b, t).add(0, 4 * t * (1 - t) * dist * 0.12, 0);
    }

    /** Quicklime spraying from the mouth: a thick white stream that reaches out and hangs as dust. */
    static void quicklime(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        float travel = Math.max(1f, c.fx().ticks - 8f);
        float front = Math.min(1f, c.age() / travel);
        float fade = fadeOut(c, 8f);
        List<Vec3> pts = new ArrayList<>();
        int n = 12;
        float[] radii = new float[n + 1];
        RandomSource r = FxDraw.rng(c.fx().seed, 5);
        for (int i = 0; i <= n; i++) {
            float t = front * i / n;
            Vec3 q = a.lerp(b, t).add(Mth.sin(c.age() * 0.6f + i) * 0.05, Mth.cos(c.age() * 0.5f + i * 1.3f) * 0.05, 0);
            pts.add(q);
            radii[i] = (0.12f + t * 0.55f + r.nextFloat() * 0.08f) * fade;
        }
        if (pts.get(n).distanceToSqr(a) < 1e-4) return;
        FxDraw.tube(FxDraw.lit(c.buffers()), c.ps(), pts, radii, 10, FxDraw.color(LIME, 0.85f), 1f, FxDraw.lightAt(a), true);
        float[] halo = new float[n + 1];
        for (int i = 0; i <= n; i++) halo[i] = radii[i] * 1.6f;
        FxDraw.tube(FxDraw.lit(c.buffers()), c.ps(), pts, halo, 10, FxDraw.color(0xD8D4C8, 0.25f), 1f, FxDraw.lightAt(a), false);
    }

    /** The crust of set quicklime round someone caught in it: lumpy white shell, crumbling away at the end. */
    static void limeShell(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        Vec3 base = e.getPosition(c.partial());
        float w = e.getBbWidth() * 0.5f + 0.15f, h = e.getBbHeight() + 0.15f;
        float grow = FxDraw.smooth(c.age() / 4f);
        float fade = fadeOut(c, 8f);
        float drop = (1f - fade) * 0.6f;
        RandomSource r = FxDraw.rng(c.fx().seed, 11);
        VertexConsumer vc = FxDraw.lit(c.buffers());
        int light = FxDraw.lightAt(base.add(0, 1, 0));
        int lumps = 18;
        for (int k = 0; k < lumps; k++) {
            float y = r.nextFloat() * h, a = r.nextFloat() * Mth.TWO_PI;
            float rad = (0.22f + r.nextFloat() * 0.18f) * (0.6f + 0.4f * (w / 0.45f));
            Vec3 at = base.add(Mth.cos(a) * w * 0.8f, y - drop * (1 + k % 3), Mth.sin(a) * w * 0.8f);
            int shade = 0xE6E2D8 - (r.nextInt(3) * 0x0A0A0A);
            FxDraw.sphere(vc, c.ps(), at, rad * grow, 5, 7, FxDraw.color(shade, 0.97f * fade), light);
        }
        FxDraw.box(vc, c.ps(), base.add(0, h / 2, 0), new Vec3(w * 0.85, 0, 0), new Vec3(0, h * 0.5 * grow, 0), new Vec3(0, 0, w * 0.85),
                FxDraw.color(LIME, 0.9f * fade), light);
    }

    /**
     * Melting Apparition: corrosive lava gushing over the ground from the user, spreading wider as it goes; a molten
     * surface with dark crust drifting on it and heat rising, sinking away at the end.
     */
    static void meltingApparition(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        Vec3 dir = b.subtract(a);
        dir = new Vec3(dir.x, 0, dir.z);
        if (dir.lengthSqr() < 1e-6) return;
        double full = dir.length();
        dir = dir.normalize();
        Vec3 side = dir.cross(new Vec3(0, 1, 0)).normalize();
        float age = c.age();
        float reach = (float) Math.min(full, 2 + age * 0.4f);
        float fade = fadeOut(c, 15f);
        float sink = (1 - fade) * 0.25f;
        VertexConsumer lit = FxDraw.glow(c.buffers());
        VertexConsumer add = FxDraw.additive(c.buffers());
        int rows = 20, cols = 6;
        RandomSource r = FxDraw.rng(c.fx().seed, 21);
        float[][] heat = new float[rows + 1][cols + 1];
        for (int i = 0; i <= rows; i++) for (int j = 0; j <= cols; j++) heat[i][j] = r.nextFloat();
        for (int i = 0; i < rows; i++) {
            float s0 = reach * i / rows, s1 = reach * (i + 1) / rows;
            float w0 = 1.5f + s0 * 0.22f, w1 = 1.5f + s1 * 0.22f;
            for (int j = 0; j < cols; j++) {
                float u0 = j / (float) cols - 0.5f, u1 = (j + 1) / (float) cols - 0.5f;
                Vec3 p00 = ground(a, dir, side, s0, u0 * 2 * w0, age, sink), p01 = ground(a, dir, side, s0, u1 * 2 * w0, age, sink);
                Vec3 p10 = ground(a, dir, side, s1, u0 * 2 * w1, age, sink), p11 = ground(a, dir, side, s1, u1 * 2 * w1, age, sink);
                float h = 0.5f + 0.5f * Mth.sin(age * 0.15f + heat[i][j] * 6.28f - s0 * 0.4f);
                int col = mix(CRUST, LAVA, 0.35f + 0.65f * h);
                FxDraw.quad(lit, c.ps(), p00, p01, p11, p10, FxDraw.color(col, 0.95f * fade), FxDraw.FULL);
                if (h > 0.6f) {
                    FxDraw.quad(add, c.ps(), p00.add(0, 0.02, 0), p01.add(0, 0.02, 0), p11.add(0, 0.02, 0), p10.add(0, 0.02, 0),
                            FxDraw.addColor(LAVA_HOT, (h - 0.6f) * 1.4f * fade), FxDraw.FULL);
                }
            }
        }
        // the gush from the mouth while it's being spewed
        if (age < 30) {
            Vec3 mouth = a.add(0, 1.4, 0).subtract(dir.scale(0.6));
            Vec3 land = ground(a, dir, side, Math.min(3f, reach), 0, age, 0);
            List<Vec3> arcPts = new ArrayList<>();
            for (int k = 0; k <= 8; k++) {
                float t = k / 8f;
                arcPts.add(mouth.lerp(land, t).add(0, Mth.sin(Mth.PI * t) * 0.5, 0));
            }
            float g = 1f - Mth.clamp((age - 22) / 8f, 0f, 1f);
            FxDraw.ribbon(add, c.ps(), c.cam(), arcPts, 0.5f * g, 0.5f, FxDraw.addColor(LAVA_HOT, 0.9f * g), FxDraw.addColor(LAVA, 0.7f * g), FxDraw.FULL);
        }
        // the front of the flow, a rolling bulge
        Vec3 frontPt = ground(a, dir, side, reach, 0, age, sink).add(0, 0.25, 0);
        FxDraw.ring(add, c.ps(), frontPt, new Vec3(0, 1, 0), 1.5f + reach * 0.22f, 0.5f, 24, FxDraw.addColor(LAVA_HOT, 0.4f * fade),
                FxDraw.addColor(LAVA, 0f), FxDraw.FULL);
    }

    private static Vec3 ground(Vec3 a, Vec3 dir, Vec3 side, float along, float across, float age, float sink) {
        Vec3 p = a.add(dir.scale(along)).add(side.scale(across));
        double y = FxDraw.groundY(p.add(0, 1, 0)) + 0.06 + 0.04 * Mth.sin(age * 0.3f + along * 1.3f + across) - sink;
        return new Vec3(p.x, y, p.z);
    }

    // ---------------------------------------------------------------- Storm Release

    /** Laser Circus gathering: a halo of light swelling round both hands, then spreading out and fading. */
    static void laserHalo(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        Vec3 look = e.getViewVector(c.partial());
        Vec3 right = look.cross(new Vec3(0, 1, 0));
        right = right.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : right.normalize();
        float p = c.progress();
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (int s = -1; s <= 1; s += 2) {
            Vec3 hand = e.getEyePosition(c.partial()).add(look.scale(0.7)).add(right.scale(0.35 * s)).subtract(0, 0.45, 0);
            float r = 0.15f + 0.9f * FxDraw.smooth(p);
            float a = p < 0.25f ? p / 0.25f : 1f - (p - 0.25f) / 0.75f;
            FxDraw.sphere(add, c.ps(), hand, 0.12f + 0.1f * a, 6, 8, FxDraw.addColor(0xFFFFFF, a), FxDraw.FULL);
            FxDraw.ring(add, c.ps(), hand, look, r, 0.08f, 24, FxDraw.addColor(0xFFFFFF, 0.9f * a), FxDraw.addColor(LASER, 0f), FxDraw.FULL);
            FxDraw.ring(add, c.ps(), hand, look, r * 0.6f, 0.05f, 24, FxDraw.addColor(LASER, 0.8f * a), FxDraw.addColor(LASER, 0f), FxDraw.FULL);
        }
    }

    /** One beam of Laser Circus: a streak of light bending through the air onto its target, a fading trail behind. */
    static void laserBeam(FxClient.Ctx c) {
        Vec3 a = c.fx().a;
        Entity t = c.fx().entityB();
        Vec3 b = t != null ? t.getBoundingBox().getCenter() : c.fx().b;
        float travel = Math.max(1f, c.fx().ticks - 3f);
        float head = Math.min(1f, c.age() / travel);
        float fade = 1f - Mth.clamp((c.age() - travel) / 3f, 0f, 1f);
        RandomSource r = FxDraw.rng(c.fx().seed, 31);
        Vec3 mid = a.lerp(b, 0.45).add((r.nextFloat() - 0.5) * 6, r.nextFloat() * 3.5, (r.nextFloat() - 0.5) * 6);
        List<Vec3> pts = new ArrayList<>();
        float tail = Math.max(0f, head - 0.45f);
        for (int k = 0; k <= 14; k++) {
            float s = tail + (head - tail) * k / 14f;
            pts.add(bezier(a, mid, b, s));
        }
        float w = 0.12f * c.fx().size;
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.ribbon(add, c.ps(), c.cam(), pts, w * 3.2f, 0.2f, FxDraw.addColor(LASER, 0f), FxDraw.addColor(LASER, 0.5f * fade), FxDraw.FULL);
        FxDraw.ribbon(add, c.ps(), c.cam(), pts, w, 0.2f, FxDraw.addColor(0xFFFFFF, 0f), FxDraw.addColor(0xFFFFFF, 1f * fade), FxDraw.FULL);
        Vec3 tip = pts.get(pts.size() - 1);
        FxDraw.sphere(add, c.ps(), tip, w * 1.6f, 5, 7, FxDraw.addColor(0xFFFFFF, 0.9f * fade), FxDraw.FULL);
    }

    private static Vec3 bezier(Vec3 a, Vec3 m, Vec3 b, float t) {
        float u = 1 - t;
        return a.scale(u * u).add(m.scale(2 * u * t)).add(b.scale(t * t));
    }

    /** A black storm cloud hanging over the spot, lightning flickering inside it, rain pouring down beneath. */
    static void stormCloud(FxClient.Ctx c) {
        Vec3 base = c.fx().a;
        float R = c.fx().size, age = c.age();
        float in = FxDraw.smooth(age / 15f), fade = fadeOut(c, 20f) * in;
        Vec3 top = base.add(0, 9, 0);
        RandomSource r = FxDraw.rng(c.fx().seed, 41);
        VertexConsumer lit = FxDraw.lit(c.buffers());
        int light = FxDraw.lightAt(top);
        for (int k = 0; k < 22; k++) {
            float a = r.nextFloat() * Mth.TWO_PI + age * 0.01f * (k % 2 == 0 ? 1 : -1), d = (float) Math.sqrt(r.nextFloat()) * R;
            float rad = 1.4f + r.nextFloat() * 1.6f;
            Vec3 at = top.add(Mth.cos(a) * d, r.nextFloat() * 1.4 + Mth.sin(age * 0.05f + k) * 0.2, Mth.sin(a) * d);
            int shade = mix(0x1A1C22, 0x40444C, r.nextFloat());
            FxDraw.sphere(lit, c.ps(), at, rad * (0.6f + 0.4f * in), 6, 8, FxDraw.color(shade, 0.82f * fade), light);
        }
        VertexConsumer add = FxDraw.additive(c.buffers());
        RandomSource flash = FxDraw.rng(c.fx().seed + (long) (age / 3), 43);
        if (flash.nextFloat() < 0.45f) {
            Vec3 at = top.add((flash.nextFloat() - 0.5) * R * 1.6, 0.6, (flash.nextFloat() - 0.5) * R * 1.6);
            FxDraw.sphere(add, c.ps(), at, 2.2f, 6, 8, FxDraw.addColor(LASER, 0.35f * fade), FxDraw.FULL);
        }
        for (int k = 0; k < 40; k++) {                           // the rain
            float a = r.nextFloat() * Mth.TWO_PI, d = (float) Math.sqrt(r.nextFloat()) * R;
            float phase = (age * 0.35f + r.nextFloat() * 9f) % 9f;
            Vec3 x0 = top.add(Mth.cos(a) * d, -phase, Mth.sin(a) * d);
            FxDraw.ribbon(lit, c.ps(), c.cam(), List.of(x0, x0.add(0, -0.9, 0)), 0.03f, 0f, FxDraw.color(0x9FB8D0, 0.5f * fade),
                    FxDraw.color(0x9FB8D0, 0.1f * fade), light);
        }
    }

    /** A beam of storm chakra striking down from the cloud: a blinding column and a ring where it lands. */
    static void stormBeam(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        float p = c.progress();
        float k = 1f - p;
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.ribbon(add, c.ps(), c.cam(), List.of(a, b), 1.1f * k + 0.1f, 0f, FxDraw.addColor(LASER, 0.6f * k), FxDraw.addColor(LASER, 0.6f * k), FxDraw.FULL);
        FxDraw.ribbon(add, c.ps(), c.cam(), List.of(a, b), 0.35f * k + 0.05f, 0f, FxDraw.addColor(0xFFFFFF, k), FxDraw.addColor(0xFFFFFF, k), FxDraw.FULL);
        FxDraw.ring(add, c.ps(), b.add(0, 0.1, 0), new Vec3(0, 1, 0), 0.4f + p * 2.4f, 0.3f * k, 28, FxDraw.addColor(0xFFFFFF, 0.9f * k),
                FxDraw.addColor(LASER, 0f), FxDraw.FULL);
    }

    // ---------------------------------------------------------------- Boil Release

    /** Skilled Mist: exhaled from the mouth, the corrosive mist rolls out and hangs, churning, over the spot. */
    static void acidMist(FxClient.Ctx c) {
        Vec3 mouth = c.fx().a, centre = c.fx().b;
        float R = c.fx().size, age = c.age();
        float fade = fadeOut(c, 25f);
        VertexConsumer lit = FxDraw.lit(c.buffers());
        int light = FxDraw.lightAt(centre.add(0, 1, 0));
        if (age < 16) {                                          // the breath carrying it out
            float g = 1f - age / 16f;
            List<Vec3> pts = new ArrayList<>();
            int n = 8;
            float[] radii = new float[n + 1];
            for (int i = 0; i <= n; i++) {
                float t = Math.min(1f, age / 10f) * i / n;
                pts.add(mouth.lerp(centre.add(0, 1.2, 0), t));
                radii[i] = (0.15f + t * 1.8f) * g;
            }
            if (pts.get(n).distanceToSqr(mouth) > 1e-4) FxDraw.tube(lit, c.ps(), pts, radii, 10, FxDraw.color(ACID, 0.3f), 1f, light, false);
        }
        float spread = FxDraw.smooth(age / 14f);
        RandomSource r = FxDraw.rng(c.fx().seed, 51);
        for (int k = 0; k < 26; k++) {
            float a = r.nextFloat() * Mth.TWO_PI + age * 0.02f * (k % 2 == 0 ? 1 : -1);
            float d = (float) Math.sqrt(r.nextFloat()) * R * spread;
            float y = 0.4f + r.nextFloat() * 2.4f + Mth.sin(age * 0.07f + k) * 0.2f;
            float rad = (1.0f + r.nextFloat() * 1.0f) * (0.4f + 0.6f * spread);
            FxDraw.sphere(lit, c.ps(), centre.add(Mth.cos(a) * d, y, Mth.sin(a) * d), rad, 6, 8,
                    FxDraw.color(mix(ACID, 0xC8D4A0, r.nextFloat()), 0.16f * fade), light);
        }
    }

    /** Unrivalled Strength: steam venting off the body, puffs rising and swelling, a heat glow round the user. */
    static void steamArmor(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        Vec3 base = e.getPosition(c.partial());
        float age = c.age(), fade = fadeOut(c, 20f) * FxDraw.smooth(age / 6f);
        float yaw = e.getViewYRot(c.partial()) * Mth.DEG_TO_RAD;
        Vec3 back = new Vec3(Mth.sin(yaw), 0, -Mth.cos(yaw));
        VertexConsumer lit = FxDraw.lit(c.buffers());
        int light = FxDraw.lightAt(base.add(0, 1, 0));
        for (int k = 0; k < 10; k++) {
            float phase = ((age * 0.06f) + k / 10f) % 1f;
            Vec3 vent = k < 4 ? base.add(back.scale(0.32)).add(0, 1.3 + (k % 2) * 0.25, 0)
                    : base.add(Mth.cos(k * 2.1f) * 0.3, 0.7 + (k % 3) * 0.45, Mth.sin(k * 2.1f) * 0.3);
            Vec3 at = vent.add(back.scale(phase * 0.6)).add(0, phase * 1.6, 0);
            FxDraw.sphere(lit, c.ps(), at, 0.15f + phase * 0.5f, 5, 7, FxDraw.color(STEAM, 0.45f * (1 - phase) * fade), light);
        }
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.ring(add, c.ps(), base.add(0, 0.05, 0), new Vec3(0, 1, 0), 0.7f, 0.25f, 24, FxDraw.addColor(0xFF9A60, 0.2f * fade),
                FxDraw.addColor(0xFF9A60, 0f), FxDraw.FULL);
    }

    /** A burst of scalding steam (a = where; following entityA if there is one). */
    static void steamBurst(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        Vec3 at = e != null ? e.getBoundingBox().getCenter() : c.fx().a;
        float p = c.progress(), s = c.fx().size;
        VertexConsumer lit = FxDraw.lit(c.buffers());
        int light = FxDraw.lightAt(at);
        RandomSource r = FxDraw.rng(c.fx().seed, 61);
        for (int k = 0; k < 8; k++) {
            Vec3 d = new Vec3(r.nextGaussian(), Math.abs(r.nextGaussian()) + 0.3, r.nextGaussian()).normalize();
            FxDraw.sphere(lit, c.ps(), at.add(d.scale(p * 1.2 * s)), (0.25f + p * 0.7f) * s, 5, 7, FxDraw.color(STEAM, 0.55f * (1 - p)), light);
        }
    }

    // ---------------------------------------------------------------- Scorch Release

    /** A little sun: a white-hot core, an orange blaze round it, flares turning about it. */
    private static void sun(FxClient.Ctx c, Vec3 at, float r, float a) {
        VertexConsumer add = FxDraw.additive(c.buffers());
        float t = c.age() + c.fx().seed % 100;
        FxDraw.sphere(add, c.ps(), at, r * 0.6f, 6, 8, FxDraw.addColor(SUN_CORE, a), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), at, r, 6, 8, FxDraw.addColor(SUN, 0.75f * a), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), at, r * 1.7f, 6, 8, FxDraw.addColor(SUN, 0.22f * a), FxDraw.FULL);
        for (int k = 0; k < 2; k++) {
            Vec3 axis = new Vec3(Mth.cos(t * 0.2f + k * 1.6f), 0.6, Mth.sin(t * 0.2f + k * 1.6f));
            FxDraw.ring(add, c.ps(), at, axis, r * 1.3f, r * 0.15f, 20, FxDraw.addColor(SUN_CORE, 0.6f * a), FxDraw.addColor(SUN, 0f), FxDraw.FULL);
        }
    }

    /** Scorching Sun / a launched sun of Extremely Steaming Murder: flying from a onto its target. */
    static void scorchOrb(FxClient.Ctx c) {
        Entity t = c.fx().entityB();
        Vec3 b = t != null ? t.getBoundingBox().getCenter() : c.fx().b;
        float p = c.progress();
        Vec3 at = c.fx().a.lerp(b, p);
        sun(c, at, 0.45f, 1f);
        List<Vec3> trail = List.of(c.fx().a.lerp(b, Math.max(0f, p - 0.15f)), at);
        FxDraw.ribbon(FxDraw.additive(c.buffers()), c.ps(), c.cam(), trail, 0.5f, 0.2f, FxDraw.addColor(SUN, 0f), FxDraw.addColor(SUN, 0.5f), FxDraw.FULL);
    }

    /** One of Extremely Steaming Murder's suns circling the user, until it's sent off at someone. */
    static void scorchOrbit(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        int index = -2 - c.fx().entityB;
        int tag = AdvancedJutsu.launchTag(c.fx().entityA, index);
        for (FxClient.Active other : FxClient.active()) {      // already launched: the launch draws it now
            if (other.type == com.shinobiarts.fx.Fx.Visual.SCORCH_LAUNCH && other.entityA == tag && other.start >= c.fx().start) return;
        }
        float in = FxDraw.smooth(c.age() / 10f);
        Vec3 at = AdvancedJutsu.sunAt(e.getPosition(c.partial()), index, c.age());
        sun(c, at, 0.42f * in, fadeOut(c, 10f));
    }

    private static int mix(int a, int b, float t) {
        t = Mth.clamp(t, 0f, 1f);
        int r = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return (r << 16) | (g << 8) | bl;
    }
}
