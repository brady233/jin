package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Afflictions;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.util.Scheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeMod;

import java.util.UUID;

/**
 * The shark arts of the Hoshigaki clan (their clan release, beside Shark Fang Torrent):
 * <ul>
 *   <li><b>Shark Blood</b> (passive, every Hoshigaki): breathe underwater, swim 150% faster, Water Release hits 20% harder.</li>
 *   <li><b>Shark Jaw</b>: a huge jaw of chakra snaps shut on whoever you aim at, holds them two seconds, then flings them.</li>
 *   <li><b>Rough Skin</b>: passively, anyone who hits you in melee is cut by your skin; cast, for 12 seconds your skin
 *       hardens (far less damage taken, and it cuts much deeper).</li>
 *   <li><b>Blood Scent</b>: for 20 seconds you smell blood: every hurt creature within 50 blocks shows through walls,
 *       the more hurt, the stronger the scent (only you see it).</li>
 *   <li><b>Shark Rampage</b>: grab the one in front of you, a flurry of punches, and a headbutt that sends them flying.</li>
 *   <li><b>Shark Transformation</b>: become a shark-human: fins, claws and a tail; much stronger and faster, a stronger
 *       bite, every hit steals a little chakra. Burns chakra every second; cast again to change back.</li>
 * </ul>
 */
public final class SharkArts {
    private SharkArts() {}

    private static final UUID SWIM_ID = UUID.fromString("5c6d43f3-3b5e-4b8c-9f2b-1a0e6f8a7a11");
    private static final UUID FORM_DMG_ID = UUID.fromString("0b1c1e1a-6f2e-4d61-8c6a-2b5d7d2b9e21");
    private static final UUID FORM_SPD_ID = UUID.fromString("7e9a5b6c-3c2d-4e8f-a1b2-c3d4e5f6a7b8");

    public static boolean isShark(NinjaData d) {
        return d.isInitialized() && d.getClan() == Clan.HOSHIGAKI;
    }

    /** Water Release damage bonus from Shark Blood. */
    public static float waterBonus(NinjaData d, ChakraNature release) {
        return release == ChakraNature.WATER && isShark(d) ? 1.2f : 1f;
    }

    // ---------------------------------------------------------------- every second, from the ninja ticker

    public static void tick(ServerPlayer p, NinjaData d) {
        boolean shark = isShark(d);
        AttributeInstance swim = p.getAttribute(ForgeMod.SWIM_SPEED.get());
        if (swim != null) {
            boolean has = swim.getModifier(SWIM_ID) != null;
            if (shark && !has) swim.addPermanentModifier(new AttributeModifier(SWIM_ID, "Shark Blood swim", 1.5, AttributeModifier.Operation.MULTIPLY_BASE));
            else if (!shark && has) swim.removeModifier(SWIM_ID);
        }
        if (shark && p.isEyeInFluidType(ForgeMod.WATER_TYPE.get())) {
            p.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 60, 0, false, false, false));
        }
        long now = p.level().getGameTime();
        boolean form = d.isSharkForm();
        AttributeInstance dmg = p.getAttribute(Attributes.ATTACK_DAMAGE), spd = p.getAttribute(Attributes.MOVEMENT_SPEED);
        if (dmg != null && spd != null) {
            if (form && dmg.getModifier(FORM_DMG_ID) == null) {
                dmg.addTransientModifier(new AttributeModifier(FORM_DMG_ID, "Shark form", 0.6, AttributeModifier.Operation.MULTIPLY_TOTAL));
                spd.addTransientModifier(new AttributeModifier(FORM_SPD_ID, "Shark form", 0.35, AttributeModifier.Operation.MULTIPLY_BASE));
            } else if (!form && dmg.getModifier(FORM_DMG_ID) != null) {
                dmg.removeModifier(FORM_DMG_ID);
                spd.removeModifier(FORM_SPD_ID);
            }
        }
        if (form) {                                                   // the form burns chakra
            float cost = Config.f(Config.SHARK_FORM_DRAIN);
            if (!p.isCreative() && d.getChakra() < cost) {
                endForm(p, d);
            } else if (!p.isCreative()) {
                d.consumeChakra(cost);
            }
        }
        if (d.getRoughSkinUntil() > 0 && d.getRoughSkinUntil() <= now) {
            d.setRoughSkinUntil(0);
            ModNetwork.sync(p);
            SharinganManager.updateLook(p);
        }
    }

    // ---------------------------------------------------------------- hits

    /** A melee hit lands on a Hoshigaki: their skin cuts the attacker (Rough Skin). Returns the damage to reflect. */
    public static float roughSkinReflect(ServerPlayer victim, NinjaData d, float incoming, long now) {
        if (!isShark(d)) return 0f;
        boolean hard = d.getRoughSkinUntil() > now;
        return incoming * (hard ? 0.4f : 0.15f) + (hard ? 1f : 0f);
    }

    /** Damage taken while Rough Skin is hardened. */
    public static float roughSkinTaken(NinjaData d, float amount, long now) {
        return d.getRoughSkinUntil() > now ? amount * 0.55f : amount;
    }

    /** A hit from someone in shark form steals a little chakra. */
    public static void formHit(ServerPlayer attacker, NinjaData d, LivingEntity target) {
        if (!d.isSharkForm()) return;
        float stolen = 4f;
        if (target instanceof ServerPlayer tp) {
            NinjaData td = NinjaData.get(tp);
            if (td != null) {
                stolen = Math.min(stolen, td.getChakra());
                td.consumeChakra(stolen);
                ModNetwork.sync(tp);
            }
        }
        d.setChakra(Math.min(d.maxChakra(), d.getChakra() + stolen));
        ((ServerLevel) attacker.level()).sendParticles(ParticleTypes.BUBBLE_POP, target.getX(), target.getY() + 1, target.getZ(), 6, 0.3, 0.4, 0.3, 0.02);
    }

    // ---------------------------------------------------------------- the jutsu

    public static boolean sharkJaw(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 12);
        if (target == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.no_target").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        ServerLevel level = p.serverLevel();
        float bite = JutsuUtil.dmg(d.isSharkForm() ? 13f : 9f);
        Fx.on(level, Fx.Visual.SHARK_JAW, target, p, d.isSharkForm() ? 1.35f : 1f, 46);
        JutsuUtil.sound(level, target.position(), SoundEvents.EVOKER_FANGS_ATTACK, 1.4f, 0.6f);
        target.invulnerableTime = 0;
        target.hurt(ModDamage.jutsu(level, p, p), bite * 0.4f);
        Afflictions.stun(target, 40, Afflictions.STUN_NONE);
        Vec3 hold = target.position();
        Scheduler.repeat(1, 1, 39, i -> {
            if (target.isAlive()) {
                target.teleportTo(hold.x, hold.y, hold.z);
                target.setDeltaMovement(Vec3.ZERO);
            }
        });
        Scheduler.later(40, () -> {
            if (!target.isAlive()) return;
            target.invulnerableTime = 0;
            target.hurt(ModDamage.jutsu(level, p, p), bite);
            Vec3 away = target.position().subtract(p.position());
            away = new Vec3(away.x, 0, away.z);
            away = away.lengthSqr() < 1e-4 ? p.getLookAngle() : away.normalize();
            JutsuUtil.push(target, away.scale(1.8).add(0, 0.7, 0));
            level.sendParticles(ParticleTypes.SPLASH, target.getX(), target.getY() + 1, target.getZ(), 40, 0.5, 0.5, 0.5, 0.2);
            JutsuUtil.sound(level, target.position(), SoundEvents.PLAYER_ATTACK_CRIT, 1.2f, 0.6f);
        });
        return true;
    }

    public static boolean roughSkin(ServerPlayer p, NinjaData d) {
        d.setRoughSkinUntil(p.level().getGameTime() + 240);
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 240, 0, false, false, true));
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ARMOR_EQUIP_NETHERITE, 1.2f, 0.6f);
        p.serverLevel().sendParticles(ParticleTypes.CRIT, p.getX(), p.getY() + 1, p.getZ(), 30, 0.4, 0.6, 0.4, 0.1);
        p.displayClientMessage(Component.translatable("message.shinobiarts.rough_skin_on").withStyle(ChatFormatting.DARK_AQUA), true);
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
        return true;
    }

    public static boolean bloodScent(ServerPlayer p, NinjaData d) {
        d.setBloodScentUntil(p.level().getGameTime() + 400);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.SNIFFER_SNIFFING, 1.2f, 0.8f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.blood_scent_on").withStyle(ChatFormatting.DARK_RED), true);
        ModNetwork.sync(p);
        return true;
    }

    public static boolean sharkRampage(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 4);
        if (target == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.no_target").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        ServerLevel level = p.serverLevel();
        float punch = JutsuUtil.dmg(d.isSharkForm() ? 3.5f : 2.5f), head = JutsuUtil.dmg(d.isSharkForm() ? 14f : 10f);
        Afflictions.stun(target, 50, Afflictions.STUN_NONE);
        JutsuUtil.sound(level, target.position(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.2f, 0.6f);
        Scheduler.repeat(0, 1, 46, i -> {
            if (!p.isAlive() || !target.isAlive()) return;
            // held right in front of you
            Vec3 front = p.position().add(Vec3.directionFromRotation(0, p.getYRot()).scale(1.3));
            target.teleportTo(front.x, p.getY(), front.z);
            target.setDeltaMovement(Vec3.ZERO);
            if (i % 6 == 0 && i < 40) {                               // the punches
                p.swing(i % 12 == 0 ? net.minecraft.world.InteractionHand.MAIN_HAND : net.minecraft.world.InteractionHand.OFF_HAND, true);
                target.invulnerableTime = 0;
                target.hurt(ModDamage.jutsu(level, p, p), punch);
                level.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY() + 1.2, target.getZ(), 8, 0.2, 0.3, 0.2, 0.2);
                JutsuUtil.sound(level, target.position(), SoundEvents.PLAYER_ATTACK_STRONG, 1.0f, 0.8f + i * 0.01f);
            }
            if (i == 45) {                                            // the headbutt
                target.invulnerableTime = 0;
                target.hurt(ModDamage.jutsu(level, p, p), head);
                Vec3 dir = Vec3.directionFromRotation(0, p.getYRot());
                JutsuUtil.push(target, dir.scale(3.2).add(0, 1.0, 0));
                level.sendParticles(ParticleTypes.EXPLOSION, target.getX(), target.getY() + 1.4, target.getZ(), 1, 0, 0, 0, 0);
                JutsuUtil.sound(level, target.position(), SoundEvents.ANVIL_LAND, 1.0f, 0.7f);
                JutsuUtil.sound(level, target.position(), SoundEvents.PLAYER_ATTACK_CRIT, 1.4f, 0.5f);
            }
        });
        return true;
    }

    public static boolean sharkTransformation(ServerPlayer p, NinjaData d) {
        if (d.isSharkForm()) {
            endForm(p, d);
            return false;
        }
        d.setSharkForm(true);
        ServerLevel level = p.serverLevel();
        level.sendParticles(ParticleTypes.SPLASH, p.getX(), p.getY() + 1, p.getZ(), 80, 0.6, 1.0, 0.6, 0.3);
        level.sendParticles(ParticleTypes.BUBBLE_COLUMN_UP, p.getX(), p.getY() + 0.5, p.getZ(), 40, 0.5, 0.2, 0.5, 0.2);
        JutsuUtil.sound(level, p.position(), SoundEvents.ELDER_GUARDIAN_AMBIENT, 1.2f, 0.7f);
        JutsuUtil.sound(level, p.position(), SoundEvents.PLAYER_SPLASH_HIGH_SPEED, 1.4f, 0.6f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.shark_form_on").withStyle(ChatFormatting.DARK_AQUA), true);
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
        return true;
    }

    public static void endForm(ServerPlayer p, NinjaData d) {
        if (!d.isSharkForm()) return;
        d.setSharkForm(false);
        p.serverLevel().sendParticles(ParticleTypes.SPLASH, p.getX(), p.getY() + 1, p.getZ(), 40, 0.5, 0.8, 0.5, 0.2);
        p.displayClientMessage(Component.translatable("message.shinobiarts.shark_form_off").withStyle(ChatFormatting.GRAY), true);
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
    }
}
