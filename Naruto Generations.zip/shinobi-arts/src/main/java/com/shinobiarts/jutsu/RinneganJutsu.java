package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.util.Scheduler;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import static com.shinobiarts.jutsu.JutsuUtil.dmg;

/**
 * The Rinnegan's techniques (Pain's Deva Path, and Madara's Chibaku Tensei). The ripple-patterned eyes show while
 * they're used.
 * <ul>
 *   <li>Shinra Tensei: a wave of repulsion blasts everything around you away (and turns back projectiles).</li>
 *   <li>Bansho Ten'in: the creature you look at is wrenched through the air to you.</li>
 *   <li>Chibaku Tensei: a black sphere rises into the sky and drags everything near it up into a growing ball of
 *       rock, crushing it, until it lets go.</li>
 *   <li>Tengai Shinsei: Madara's meteor. A huge burning rock falls out of the sky onto where you look (and, by
 *       default, a second, bigger one right behind it).</li>
 * </ul>
 */
public final class RinneganJutsu {
    private RinneganJutsu() {}

    /** The Rinnegan shows in the caster's eyes for a while. */
    private static void showEyes(ServerPlayer p, NinjaData d, int ticks) {
        d.setRinneganShownUntil(Math.max(d.getRinneganShownUntil(), p.level().getGameTime() + ticks));
        SharinganManager.updateLook(p);
    }

    /** Shinra Tensei: everything within 10 blocks is blasted away, the closest hardest, and projectiles thrown back. */
    public static boolean shinraTensei(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        showEyes(p, d, 80);
        Vec3 c = p.position().add(0, 1, 0);
        double radius = 10;
        float base = dmg(12f);
        for (LivingEntity e : JutsuUtil.inRadius(level, p, c, radius)) {
            Vec3 away = e.position().add(0, e.getBbHeight() / 2, 0).subtract(c);
            double dist = away.length();
            away = dist < 1e-3 ? p.getLookAngle() : away.scale(1 / dist);
            double k = 1 - dist / (radius + 2);
            e.hurt(ModDamage.jutsu(level, p, p), (float) (base * Math.max(0.3, k)));
            JutsuUtil.push(e, away.scale(1.2 + 2.8 * k).add(0, 0.5 + 0.6 * k, 0));
        }
        for (Projectile proj : level.getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(radius), pr -> pr.getOwner() != p)) {
            Vec3 away = proj.position().subtract(c).normalize();
            proj.setDeltaMovement(away.scale(Math.max(1.2, proj.getDeltaMovement().length())));
            proj.setOwner(p);
        }
        Fx.on(level, Fx.Visual.SHINRA, p, null, (float) radius, 22);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.CLOUD, c.x, p.getY() + 0.2, c.z, 120, radius * 0.5, 0.2, radius * 0.5, 0.3);
        JutsuUtil.sound(level, c, SoundEvents.GENERIC_EXPLODE, 2.0f, 0.5f);
        JutsuUtil.sound(level, c, SoundEvents.WARDEN_SONIC_BOOM, 1.5f, 0.8f);
        return true;
    }

    /** Bansho Ten'in: the creature you look at (up to 32 blocks) is pulled through the air straight to you. */
    public static boolean banshoTenin(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 32);
        if (target == null) {
            p.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.shinobiarts.no_target")
                    .withStyle(net.minecraft.ChatFormatting.GRAY), true);
            return false;
        }
        ServerLevel level = p.serverLevel();
        showEyes(p, d, 60);
        Fx.on(level, Fx.Visual.BANSHO, p, target, 1f, 16);
        target.hurt(ModDamage.jutsu(level, p, p), dmg(4f));
        // a steady pull over a few ticks so it flies to you instead of jumping
        Scheduler.repeat(0, 1, 10, i -> {
            if (!target.isAlive() || !p.isAlive()) return;
            Vec3 to = p.position().add(p.getLookAngle().multiply(1, 0, 1).scale(1.4)).add(0, 0.6, 0).subtract(target.position());
            double dist = to.length();
            if (dist < 1.3) {
                target.setDeltaMovement(target.getDeltaMovement().scale(0.3));
                return;
            }
            JutsuUtil.push(target, to.normalize().scale(Math.min(2.2, 0.5 + dist * 0.12)).subtract(target.getDeltaMovement()).add(0, 0.08, 0));
            target.resetFallDistance();
        });
        JutsuUtil.sound(level, target.position(), SoundEvents.ENDER_DRAGON_FLAP, 1.2f, 0.6f);
        JutsuUtil.sound(level, p.position(), SoundEvents.WARDEN_SONIC_CHARGE, 0.8f, 1.6f);
        return true;
    }

    /**
     * Chibaku Tensei: a small black sphere rises 10 blocks above where you look; for 8 seconds it drags every creature
     * within 14 blocks up toward it (rock tearing out of the ground and packing round it), crushing them a little every
     * second, then lets them drop.
     */
    public static boolean chibakuTensei(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        BlockHitResult hit = JutsuUtil.rayBlock(p, 32);
        Vec3 ground = hit.getType() == HitResult.Type.MISS ? p.getEyePosition().add(p.getLookAngle().scale(16)) : hit.getLocation();
        com.shinobiarts.fx.ChibakuPath path = new com.shinobiarts.fx.ChibakuPath(ground.add(0, 6, 0), ground.y);
        int total = path.totalTicks(), land = path.landTick();
        showEyes(p, d, 100);
        float crush = dmg(2.5f), impact = dmg(14f);
        // the client draws the same path (a = start, b = the ground under it)
        Fx.line(level, Fx.Visual.CHIBAKU, path.start(), new Vec3(ground.x, ground.y, ground.z), 1f, total);
        java.util.Set<Integer> caught = new java.util.HashSet<>();
        Scheduler.repeat(10, 1, land - 10, i -> {
            float t = i + 10;
            Vec3 core = path.core(t);
            float r = path.radius(t);
            boolean gathering = t < com.shinobiarts.fx.ChibakuPath.RISE + com.shinobiarts.fx.ChibakuPath.HANG;
            if (gathering) {                                          // anyone near is torn off the ground toward it
                for (LivingEntity e : JutsuUtil.inRadius(level, p, core, 16)) {
                    if (e != p) caught.add(e.getId());
                }
                for (LivingEntity e : JutsuUtil.inRadius(level, p, path.start().add(0, -6, 0), 14)) {
                    if (e != p) caught.add(e.getId());
                }
            }
            for (int id : caught) {
                if (!(level.getEntity(id) instanceof LivingEntity e) || !e.isAlive()) continue;
                Vec3 at = e.position().add(0, e.getBbHeight() / 2, 0);
                Vec3 to = core.subtract(at);
                double dist = to.length();
                Vec3 surface = dist < 1e-3 ? new Vec3(0, -r, 0) : to.scale(-(r + 0.4) / dist);       // where it's stuck
                Vec3 want = core.add(surface).subtract(at);
                Vec3 pull = dist > r + 3 ? to.normalize().scale(Math.min(0.7, 0.15 + 1.4 / Math.max(1, dist)))
                        : want.scale(0.35).subtract(e.getDeltaMovement().scale(0.7));           // packed into the rock
                e.setDeltaMovement(e.getDeltaMovement().add(pull).add(0, 0.08, 0));
                e.hurtMarked = true;
                e.resetFallDistance();
                if (i % 20 == 0 && dist < r + 3) {
                    e.invulnerableTime = 0;
                    e.hurt(ModDamage.jutsu(level, null, p), crush);
                }
            }
            if (gathering && i % 10 == 0) {
                level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, ground.x, ground.y + 0.2, ground.z, 6, 5, 0.2, 5, 0.02);
                level.sendParticles(new net.minecraft.core.particles.BlockParticleOption(ParticleTypes.BLOCK,
                        net.minecraft.world.level.block.Blocks.STONE.defaultBlockState()), ground.x, ground.y + 0.3, ground.z, 20, 6, 0.3, 6, 0.1);
            }
            if (gathering && i % 30 == 0) JutsuUtil.sound(level, core, SoundEvents.STONE_BREAK, 2.5f, 0.5f);
            if (t == com.shinobiarts.fx.ChibakuPath.RISE + com.shinobiarts.fx.ChibakuPath.HANG) {
                JutsuUtil.sound(level, core, SoundEvents.WARDEN_SONIC_CHARGE, 2.0f, 0.4f);   // it starts to fall
            }
        });
        // it blows apart like a giant TNT blast: everything caught in it and round it is hit and thrown away
        Scheduler.later(land, () -> {
            Vec3 c = path.core(land);
            float r = com.shinobiarts.fx.ChibakuPath.FINAL_RADIUS;
            for (LivingEntity e : JutsuUtil.inRadius(level, p, c, r + 8)) {
                if (e == p) continue;
                e.invulnerableTime = 0;
                e.hurt(ModDamage.jutsu(level, null, p), impact);
                Vec3 away = e.position().subtract(c);
                away = away.lengthSqr() < 1e-4 ? new Vec3(0, 1, 0) : away.normalize();
                JutsuUtil.push(e, away.scale(2.2).add(0, 0.8, 0));
            }
            level.explode(null, c.x, c.y, c.z, 12f,
                    JutsuUtil.griefing(level, p) ? net.minecraft.world.level.Level.ExplosionInteraction.TNT : net.minecraft.world.level.Level.ExplosionInteraction.NONE);
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 8, r, r, r, 0);
            level.sendParticles(new net.minecraft.core.particles.BlockParticleOption(ParticleTypes.BLOCK,
                    net.minecraft.world.level.block.Blocks.STONE.defaultBlockState()), c.x, c.y, c.z, 500, r, r, r, 0.6);
            level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, c.x, c.y, c.z, 80, r + 2, r, r + 2, 0.05);
            JutsuUtil.sound(level, c, SoundEvents.GENERIC_EXPLODE, 6.0f, 0.4f);
            JutsuUtil.sound(level, c, SoundEvents.DRAGON_FIREBALL_EXPLODE, 4.0f, 0.5f);
        });
        JutsuUtil.sound(level, path.start(), SoundEvents.WARDEN_SONIC_CHARGE, 1.5f, 0.5f);
        JutsuUtil.sound(level, ground, SoundEvents.GENERIC_EXPLODE, 1.0f, 0.4f);
        return true;
    }

    // ---------------------------------------------------------------- Tengai Shinsei

    /** How long a meteor takes to fall (ticks). */
    private static final int METEOR_FALL = 160;

    /**
     * Tengai Shinsei (Planetary Shower): a meteor is pulled out of the sky onto where you look (up to 64 blocks). Its
     * shadow spreads over the ground and the air rumbles for three and a half seconds before it lands in a huge blast
     * (damage falling off toward the edge, everything thrown away from it). Then a second, bigger meteor follows. The
     * caster isn't hurt by their own meteors. Craters only if the config allows.
     */
    public static boolean tengaiShinsei(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 look = p.getLookAngle();
        BlockHitResult hit = JutsuUtil.rayBlock(p, 64);
        Vec3 target = hit.getType() == HitResult.Type.MISS ? p.getEyePosition().add(look.scale(40)) : hit.getLocation();
        int top = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(target.x), (int) Math.floor(target.z));
        if (hit.getType() == HitResult.Type.MISS || target.y > top + 1) target = new Vec3(target.x, top, target.z);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : flat.normalize();
        Vec3 side = new Vec3(-flat.z, 0, flat.x);
        showEyes(p, d, METEOR_FALL * 2 + 60);
        JutsuUtil.sound(level, p.position(), SoundEvents.WARDEN_SONIC_CHARGE, 1.5f, 0.5f);
        JutsuUtil.sound(level, p.position(), SoundEvents.BEACON_ACTIVATE, 1.2f, 0.4f);
        meteor(p, level, target, flat, side, 1f, 0);
        if (Config.b(Config.TENGAI_SECOND)) {
            meteor(p, level, target.add(flat.scale(5)).add(side.scale(4)), flat, side, 1.5f, 45);
        }
        return true;
    }

    /** One meteor: it comes in from high behind the caster, over their head, and lands on {@code impact}. */
    private static void meteor(ServerPlayer p, ServerLevel level, Vec3 impact, Vec3 flat, Vec3 side, float scale, int delay) {
        float r = 7f * scale;
        // it comes from the very top of the sky, almost straight down, slowly
        double top = level.getMaxBuildHeight() + 120 + 20 * scale;
        Vec3 start = new Vec3(impact.x, top, impact.z).add(flat.scale(-35 - 8 * scale)).add(side.scale(10 * (scale - 1.2)));
        Scheduler.later(delay, () -> {
            Fx.line(level, Fx.Visual.TENGAI_METEOR, start, impact, r, METEOR_FALL);
            for (int k = 0; k < METEOR_FALL / 20; k++) {               // the sky rumbling as it comes down
                int kk = k;
                Scheduler.later(k * 20, () -> JutsuUtil.sound(level, impact, SoundEvents.LIGHTNING_BOLT_THUNDER, 2.5f + kk * 0.5f, 0.4f));
            }
            Scheduler.later(METEOR_FALL, () -> meteorImpact(p, level, impact, r, scale));
        });
    }

    private static void meteorImpact(ServerPlayer p, ServerLevel level, Vec3 at, float r, float scale) {
        double radius = r + 9 * scale;
        float damage = dmg(Config.f(Config.TENGAI_DAMAGE)) * scale;
        Fx.at(level, Fx.Visual.TENGAI_IMPACT, at, (float) radius, 50);
        for (LivingEntity e : JutsuUtil.inRadius(level, p, at, radius)) {
            if (e == p) continue;
            Vec3 away = e.position().subtract(at);
            double dist = away.length();
            double k = Math.max(0.25, 1 - dist / radius);
            e.invulnerableTime = 0;
            e.hurt(ModDamage.jutsu(level, p, p), (float) (damage * k));
            Vec3 dir = dist < 1e-3 ? new Vec3(0, 1, 0) : away.scale(1 / dist);
            JutsuUtil.push(e, dir.scale(1.5 + 2.5 * k).add(0, 0.8 + 0.8 * k, 0));
        }
        if (Config.b(Config.TENGAI_BREAKS_BLOCKS)) {
            level.explode(null, at.x, at.y, at.z, 5f * scale, net.minecraft.world.level.Level.ExplosionInteraction.TNT);
        }
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, at.x, at.y + 1, at.z, 3, r * 0.4, 0.5, r * 0.4, 0);
        level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, at.x, at.y + 1, at.z, 80, radius * 0.4, 1.0, radius * 0.4, 0.05);
        JutsuUtil.sound(level, at, SoundEvents.GENERIC_EXPLODE, 6.0f, 0.4f);
        JutsuUtil.sound(level, at, SoundEvents.WARDEN_SONIC_BOOM, 4.0f, 0.5f);
        JutsuUtil.sound(level, at, SoundEvents.DRAGON_FIREBALL_EXPLODE, 4.0f, 0.5f);
    }
}
