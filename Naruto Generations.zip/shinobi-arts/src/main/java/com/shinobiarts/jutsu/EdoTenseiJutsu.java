package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.util.Scheduler;
import com.shinobiarts.entity.EdoTensei;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.pvp.ShinobiRecords;
import com.shinobiarts.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * Summoning: Impure World Reincarnation (Edo Tensei). Brings back the souls of the ninja you killed most recently.
 * <p>
 * Each soul needs a living sacrifice (any ordinary mob near you, unless the config says otherwise): the sacrifice is
 * wrapped in flakes of dust until there's nothing of it left, the dust streams to a spot in front of you, and a coffin
 * comes up out of the ground there. Its lid falls forward and the soul steps out, its body cracked like dry clay,
 * the whites of its eyes black. With no souls to call, a nameless one answers.
 * <p>
 * Cast it again while your souls are out (or right-click one) to release them.
 */
public final class EdoTenseiJutsu {
    private EdoTenseiJutsu() {}

    /** How long the sacrifice takes to be swallowed by the dust, and the dust to reach the coffin's spot. */
    private static final int WRAP = 24, STREAM = 14;

    public static boolean cast(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        List<EdoTensei> mine = level.getEntitiesOfClass(EdoTensei.class, p.getBoundingBox().inflate(128),
                e -> p.getUUID().equals(e.getOwnerUUID()));
        if (!mine.isEmpty()) {                                    // Kai: release the ones already out
            mine.forEach(EdoTensei::release);
            p.displayClientMessage(Component.translatable("message.shinobiarts.edo_released", mine.size()), true);
            return false;
        }

        // the souls: the ninja you killed most recently (not anyone who's out already), or a nameless one
        List<NinjaData.Soul> souls = new ArrayList<>(d.getSouls());
        int count = Math.max(1, Math.min(Config.i(Config.EDO_MAX), souls.size()));
        List<LivingEntity> sacrifices = new ArrayList<>();
        if (Config.b(Config.EDO_SACRIFICE)) {
            sacrifices = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(10), EdoTenseiJutsu::canSacrifice);
            sacrifices.sort(Comparator.comparingDouble(p::distanceToSqr));
            if (sacrifices.isEmpty()) {
                p.displayClientMessage(Component.translatable("message.shinobiarts.edo_no_sacrifice").withStyle(ChatFormatting.RED), true);
                return false;
            }
            count = Math.min(count, sacrifices.size());
        }

        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : flat.normalize();
        Vec3 side = new Vec3(-flat.z, 0, flat.x);
        int seconds = Config.i(Config.EDO_SECONDS);
        JutsuUtil.sound(level, p.position(), SoundEvents.EVOKER_PREPARE_SUMMON, 1.2f, 0.6f);
        level.sendParticles(ParticleTypes.ASH, p.getX(), p.getY() + 0.1, p.getZ(), 40, 1.2, 0.05, 1.2, 0.01);
        for (int i = 0; i < count; i++) {
            NinjaData.Soul soul = i < souls.size() ? souls.get(i) : null;
            double offset = (i - (count - 1) / 2.0) * 1.8;
            Vec3 spot = ground(level, p.position().add(flat.scale(3.5)).add(side.scale(offset)), p.getY());
            LivingEntity sacrifice = sacrifices.isEmpty() ? null : sacrifices.get(i);
            int delay = i * 6;
            Vec3 facing = spot.subtract(flat);                    // the coffin faces back toward the caster
            if (sacrifice != null) {
                Fx.on(level, Fx.Visual.EDO_SACRIFICE, sacrifice, null, sacrifice.getBbWidth(), WRAP);
                if (sacrifice instanceof Mob mob) mob.setNoAi(true);
                Scheduler.later(WRAP, () -> {
                    if (!sacrifice.isAlive()) return;
                    Vec3 from = sacrifice.position().add(0, sacrifice.getBbHeight() / 2, 0);
                    level.sendParticles(ParticleTypes.ASH, from.x, from.y, from.z, 50, 0.3, 0.5, 0.3, 0.02);
                    JutsuUtil.sound(level, from, SoundEvents.SAND_BREAK, 1.0f, 0.5f);
                    sacrifice.discard();
                    Fx.line(level, Fx.Visual.EDO_DUST, from, spot.add(0, 1, 0), 1f, STREAM + 6);
                });
            }
            int rise = (sacrifice != null ? WRAP + STREAM : 4) + delay;
            Scheduler.later(rise, () -> summon(p, soul, spot, facing, seconds));
        }
        return true;
    }

    /** The coffin comes up at {@code spot} with the soul inside it. */
    private static void summon(ServerPlayer p, @Nullable NinjaData.Soul soul, Vec3 spot, Vec3 facing, int seconds) {
        if (!p.isAlive() || p.hasDisconnected()) return;
        ServerLevel level = p.serverLevel();
        EdoTensei edo = ModEntities.EDO_TENSEI.get().create(level);
        if (edo == null) return;
        Vec3 dir = facing.subtract(spot);
        float yaw = (float) (Math.toDegrees(Math.atan2(-dir.x, dir.z)));
        edo.moveTo(spot.x, spot.y, spot.z, yaw, 0f);
        edo.setYHeadRot(yaw);
        edo.setYBodyRot(yaw);
        UUID id = soul == null ? null : soul.id();
        String name = soul == null ? Component.translatable("entity.shinobiarts.edo_tensei.nameless").getString() : soul.name();
        edo.setup(p, id, name, soulLevel(p, id), seconds * 20);
        level.addFreshEntity(edo);
        Fx.line(level, Fx.Visual.EDO_COFFIN, spot, facing, 1f, EdoTensei.FREE + 40);
        JutsuUtil.sound(level, spot, SoundEvents.ROOTED_DIRT_BREAK, 1.4f, 0.5f);
        JutsuUtil.sound(level, spot, SoundEvents.GRAVEL_BREAK, 1.2f, 0.6f);
        level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, spot.x, spot.y + 0.1, spot.z, 6, 0.5, 0.02, 0.4, 0.01);
        Scheduler.later(EdoTensei.LID, () -> JutsuUtil.sound(level, spot, SoundEvents.WOOD_FALL, 1.5f, 0.6f));
        Scheduler.later(EdoTensei.LID + 9, () -> {
            JutsuUtil.sound(level, spot, SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR, 0.9f, 0.6f);
            level.sendParticles(ParticleTypes.CLOUD, spot.x + (facing.x - spot.x) * 1.2, spot.y + 0.1, spot.z + (facing.z - spot.z) * 1.2,
                    14, 0.5, 0.05, 0.5, 0.02);
        });
        if (soul != null) {
            ServerPlayer living = p.server.getPlayerList().getPlayer(soul.id());
            if (living != null) {
                living.displayClientMessage(Component.translatable("message.shinobiarts.edo_soul_called", p.getGameProfile().getName())
                        .withStyle(ChatFormatting.DARK_GRAY), false);
            }
        }
    }

    /** The level the soul had when they died (their shinobi record), or 0 for a nameless one. */
    private static int soulLevel(ServerPlayer p, @Nullable UUID id) {
        if (id == null) return 0;
        for (ShinobiRecords.Record r : ShinobiRecords.get(p.server).records()) {
            if (r.id.equals(id)) return r.level;
        }
        return 0;
    }

    /** Any ordinary living mob will do; never players, bosses, tamed pets, named mobs, or jutsu. */
    private static boolean canSacrifice(LivingEntity e) {
        if (!(e instanceof Mob) || !e.isAlive() || e.hasCustomName()) return false;
        if (e instanceof EdoTensei || e instanceof ShadowClone) return false;
        if (e instanceof TamableAnimal pet && pet.isTame()) return false;
        if (e.getType().is(Tags.EntityTypes.BOSSES)) return false;
        return !(e instanceof Mob mob && mob.isNoAi());
    }

    /** The ground at {@code at} (a few blocks up or down from the caster's feet), so coffins stand on something. */
    private static Vec3 ground(ServerLevel level, Vec3 at, double feetY) {
        int x = (int) Math.floor(at.x), z = (int) Math.floor(at.z);
        int base = (int) Math.floor(feetY);
        for (int dy = 2; dy >= -4; dy--) {
            BlockPos pos = new BlockPos(x, base + dy, z);
            if (level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), net.minecraft.core.Direction.UP)
                    && level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
                    && level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty()) {
                return new Vec3(x + 0.5, pos.getY(), z + 0.5);
            }
        }
        return new Vec3(x + 0.5, feetY, z + 0.5);
    }
}
