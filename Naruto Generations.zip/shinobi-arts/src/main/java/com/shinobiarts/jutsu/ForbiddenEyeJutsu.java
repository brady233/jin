package com.shinobiarts.jutsu;

import com.shinobiarts.fx.Fx;
import com.shinobiarts.item.SharinganEyeItem;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Afflictions;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.KekkeiGenkai;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.registry.ModItems;
import com.shinobiarts.util.Scheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Eye Extraction (Medical Ninjutsu), Izanagi and Izanami (Uchiha, with the Mangekyou).
 */
public final class ForbiddenEyeJutsu {
    private ForbiddenEyeJutsu() {}

    private static final DustParticleOptions BLOOD = new DustParticleOptions(new Vector3f(0.55f, 0.02f, 0.03f), 1.0f);
    private static final DustParticleOptions HEAL = new DustParticleOptions(new Vector3f(0.4f, 1.0f, 0.6f), 0.8f);

    // ---------------------------------------------------------------- Eye Extraction

    /** How long the extraction takes (the caster has to keep at it), in ticks. */
    private static final int EXTRACT_TICKS = 60;

    /**
     * Eye Extraction: a medical ninja takes the Sharingan (or Byakugan) out of someone they've beaten. The target has to be
     * within reach and helpless: stunned, or under a third of their health. It takes three seconds; it fails if either of
     * them gets away or the medic is hurt. The Eternal Mangekyou and the Rinnegan can never be taken.
     * The eye comes out as an item that can be implanted. A born Uchiha (or Hyuga) keeps their bloodline eye.
     */
    public static boolean eyeExtraction(ServerPlayer p, NinjaData d) {
        LivingEntity aimed = JutsuUtil.rayTarget(p, 3.5);
        if (!(aimed instanceof ServerPlayer target)) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.extract_need_player").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        NinjaData td = NinjaData.get(target);
        if (td == null) return false;
        if (td.hasRinnegan() || td.hasEternal()) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.extract_impossible").withStyle(ChatFormatting.DARK_RED), true);
            return false;
        }
        boolean sharingan = td.getSharinganStage() > 0, byakugan = td.hasByakugan();
        if (!sharingan && !byakugan) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.extract_no_eyes", target.getDisplayName()).withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        boolean helpless = Afflictions.isStunned(target) || target.getHealth() <= target.getMaxHealth() / 3f;
        if (!helpless) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.extract_resists", target.getDisplayName()).withStyle(ChatFormatting.RED), true);
            return false;
        }
        ServerLevel level = p.serverLevel();
        float startHealth = p.getHealth();
        Afflictions.stun(target, EXTRACT_TICKS + 10, Afflictions.STUN_NONE);
        target.sendSystemMessage(Component.translatable("message.shinobiarts.extract_victim", p.getDisplayName()).withStyle(ChatFormatting.DARK_RED));
        p.displayClientMessage(Component.translatable("message.shinobiarts.extract_start").withStyle(ChatFormatting.GREEN), true);
        JutsuUtil.sound(level, target.getEyePosition(), SoundEvents.BEACON_POWER_SELECT, 0.6f, 1.8f);
        Scheduler.repeat(0, 5, EXTRACT_TICKS / 5, i -> {
            if (!p.isAlive() || !target.isAlive()) return;
            Vec3 hand = p.getEyePosition().add(p.getLookAngle().scale(0.6)).add(0, -0.4, 0);
            level.sendParticles(HEAL, hand.x, hand.y, hand.z, 6, 0.08, 0.08, 0.08, 0.0);
            Vec3 eye = target.getEyePosition();
            level.sendParticles(HEAL, eye.x, eye.y, eye.z, 4, 0.12, 0.08, 0.12, 0.0);
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 8, 4, false, false));
        });
        Scheduler.later(EXTRACT_TICKS, () -> {
            if (!p.isAlive() || p.hasDisconnected() || !target.isAlive() || target.hasDisconnected()) return;
            if (p.distanceTo(target) > 4.5 || p.getHealth() < startHealth - 0.5f) {
                p.displayClientMessage(Component.translatable("message.shinobiarts.extract_broken").withStyle(ChatFormatting.RED), true);
                return;
            }
            NinjaData now = NinjaData.get(target);
            if (now == null || now.hasRinnegan() || now.hasEternal()) return;
            ItemStack eye;
            Component what;
            if (now.getSharinganStage() > 0) {
                int stage = now.getSharinganStage();
                eye = SharinganEyeItem.create(stage, target.getGameProfile().getName(), now.getBaseMangekyouDesign());
                what = Component.literal(Dojutsu.sharinganName(stage).getString());
                if (now.getClan() != Clan.UCHIHA) {
                    now.setSharinganStage(0);
                    now.removeBloodline("sharingan");
                    if (now.getActiveDojutsu() == Dojutsu.SHARINGAN) now.setActiveDojutsu(Dojutsu.NONE);
                }
            } else {
                eye = new ItemStack(ModItems.DNA.get(KekkeiGenkai.BYAKUGAN).get());
                what = Component.translatable("dojutsu.shinobiarts.byakugan");
                if (now.getClan() != Clan.HYUGA) {
                    now.removeBloodline("byakugan");
                    if (now.getActiveDojutsu() == Dojutsu.BYAKUGAN) now.setActiveDojutsu(Dojutsu.NONE);
                }
            }
            if (!p.getInventory().add(eye)) p.drop(eye, false);
            target.hurt(target.damageSources().magic(), 4f);
            target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 200, 0));
            Vec3 at = target.getEyePosition();
            level.sendParticles(BLOOD, at.x, at.y, at.z, 30, 0.15, 0.1, 0.15, 0.0);
            JutsuUtil.sound(level, at, SoundEvents.HONEY_BLOCK_BREAK, 1.0f, 0.6f);
            p.sendSystemMessage(Component.translatable("message.shinobiarts.extract_done", what, target.getDisplayName()).withStyle(ChatFormatting.DARK_RED));
            target.sendSystemMessage(Component.translatable("message.shinobiarts.eye_lost", p.getGameProfile().getName()).withStyle(ChatFormatting.DARK_RED));
            ModNetwork.sync(target);
            SharinganManager.updateLook(target);
            SharinganManager.broadcastEyes(target);
        });
        return true;
    }

    // ---------------------------------------------------------------- Izanagi

    /** How long Izanagi bends reality, and how long the eye that paid for it stays blind. */
    private static final int IZANAGI_TICKS = 200, BLIND_TICKS = 20 * 60 * 10;

    private record Snapshot(Vec3 pos, float yaw, float pitch, float health, int food, long until) {}

    private static final Map<UUID, Snapshot> IZANAGI = new HashMap<>();

    private static boolean mangekyouActive(ServerPlayer p, NinjaData d) {
        if (d.isEyeBlind(p.level().getGameTime())) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.eye_blind",
                    (d.getEyeBlindUntil() - p.level().getGameTime()) / 20).withStyle(ChatFormatting.DARK_RED), true);
            return false;
        }
        if (d.getActiveDojutsu() != Dojutsu.SHARINGAN || d.getSharinganStage() < Dojutsu.MANGEKYOU) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.need_mangekyou_on").withStyle(ChatFormatting.RED), true);
            return false;
        }
        return true;
    }

    /** Pays for Izanagi or Izanami: the eye goes dark (Sharingan unusable) for ten minutes. */
    private static void blindEye(ServerPlayer p, NinjaData d) {
        d.setEyeBlindUntil(p.level().getGameTime() + BLIND_TICKS);
        d.setActiveDojutsu(Dojutsu.NONE);
        p.sendSystemMessage(Component.translatable("message.shinobiarts.eye_sacrificed", BLIND_TICKS / 1200).withStyle(ChatFormatting.DARK_RED));
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
        SharinganManager.broadcastEyes(p);
    }

    /**
     * Izanagi: for ten seconds, reality bends to the caster. Anything that would kill them in that time doesn't happen:
     * they're back where they stood and as healthy as they were when it began. When it ends (used or not), the eye
     * that paid for it goes blind for ten minutes.
     */
    public static boolean izanagi(ServerPlayer p, NinjaData d) {
        if (!mangekyouActive(p, d)) return false;
        long now = p.level().getGameTime();
        IZANAGI.put(p.getUUID(), new Snapshot(p.position(), p.getYRot(), p.getXRot(), p.getHealth(), p.getFoodData().getFoodLevel(), now + IZANAGI_TICKS));
        Fx.on(p.serverLevel(), Fx.Visual.IZANAGI, p, null, 1f, IZANAGI_TICKS);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.BEACON_ACTIVATE, 1.0f, 0.6f);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ELDER_GUARDIAN_CURSE, 0.4f, 1.6f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.izanagi_on").withStyle(ChatFormatting.DARK_RED), true);
        Scheduler.later(IZANAGI_TICKS, () -> {
            if (IZANAGI.remove(p.getUUID()) != null && p.isAlive() && !p.hasDisconnected()) {
                NinjaData nd = NinjaData.get(p);
                if (nd != null) blindEye(p, nd);
            }
        });
        return true;
    }

    /** Called when a player would die (LivingDeathEvent): if Izanagi is bending reality for them, it didn't happen. */
    public static boolean izanagiSaves(ServerPlayer p) {
        Snapshot s = IZANAGI.get(p.getUUID());
        if (s == null || p.level().getGameTime() > s.until) return false;
        IZANAGI.remove(p.getUUID());
        ServerLevel level = p.serverLevel();
        Vec3 from = p.position();
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, from.x, from.y + 1, from.z, 60, 0.4, 0.8, 0.4, 0.05);
        p.setHealth(Math.max(1f, s.health));
        p.getFoodData().setFoodLevel(Math.max(p.getFoodData().getFoodLevel(), s.food));
        p.removeAllEffects();
        p.clearFire();
        p.teleportTo(s.pos.x, s.pos.y, s.pos.z);
        p.setYRot(s.yaw);
        p.setXRot(s.pitch);
        p.setDeltaMovement(Vec3.ZERO);
        p.resetFallDistance();
        p.invulnerableTime = 40;
        Fx.at(level, Fx.Visual.IZANAGI_REWRITE, s.pos.add(0, 1, 0), 1f, 30);
        JutsuUtil.sound(level, s.pos, SoundEvents.ENDERMAN_TELEPORT, 1.0f, 0.5f);
        JutsuUtil.sound(level, s.pos, SoundEvents.BELL_RESONATE, 1.0f, 0.6f);
        p.sendSystemMessage(Component.translatable("message.shinobiarts.izanagi_saved").withStyle(ChatFormatting.DARK_RED));
        NinjaData d = NinjaData.get(p);
        if (d != null) blindEye(p, d);
        return true;
    }

    // ---------------------------------------------------------------- Izanami

    private static final int IZANAMI_TICKS = 300, LOOP_TICKS = 60, ACCEPT_TICKS = 60;

    private static final class Loop {
        final Vec3 pos;
        final float yaw, pitch;
        final long until;
        int stillFor;

        Loop(Vec3 pos, float yaw, float pitch, long until) {
            this.pos = pos;
            this.yaw = yaw;
            this.pitch = pitch;
            this.until = until;
        }
    }

    private static final Map<UUID, Loop> IZANAMI = new HashMap<>();

    /**
     * Izanami: the target you're looking at is caught in a loop. For fifteen seconds, every three seconds, they're thrown
     * back to the moment it began (where they stood and the way they faced), over and over, dizzy and slowed. The only
     * way out early: stop fighting it, stand still and crouch for three seconds, accepting it. Costs the eye's sight
     * for ten minutes, like Izanagi.
     */
    public static boolean izanami(ServerPlayer p, NinjaData d) {
        if (!mangekyouActive(p, d)) return false;
        LivingEntity target = JutsuUtil.rayTarget(p, 20);
        if (target == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.no_target").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        Loop loop = new Loop(target.position(), target.getYRot(), target.getXRot(), now + IZANAMI_TICKS);
        IZANAMI.put(target.getUUID(), loop);
        Fx.at(level, Fx.Visual.IZANAMI_LOOP, loop.pos.add(0, 0.05, 0), 1f, IZANAMI_TICKS);
        JutsuUtil.sound(level, target.position(), SoundEvents.BELL_BLOCK, 1.0f, 0.5f);
        if (target instanceof ServerPlayer tp) {
            tp.sendSystemMessage(Component.translatable("message.shinobiarts.izanami_caught", p.getDisplayName()).withStyle(ChatFormatting.DARK_RED));
        }
        Scheduler.repeat(1, 1, IZANAMI_TICKS, i -> {
            Loop l = IZANAMI.get(target.getUUID());
            if (l != loop || !target.isAlive()) return;
            // accepting it: crouched and not moving
            boolean still = target.getDeltaMovement().horizontalDistanceSqr() < 0.0004 && target.isShiftKeyDown();
            l.stillFor = still ? l.stillFor + 1 : 0;
            if (l.stillFor >= ACCEPT_TICKS || level.getGameTime() >= l.until) {
                IZANAMI.remove(target.getUUID());
                target.removeEffect(MobEffects.CONFUSION);
                if (l.stillFor >= ACCEPT_TICKS && target instanceof ServerPlayer tp) {
                    tp.sendSystemMessage(Component.translatable("message.shinobiarts.izanami_accepted").withStyle(ChatFormatting.GRAY));
                    tp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
                }
                return;
            }
            if (i % LOOP_TICKS == 0) {                                    // the loop closes: back to the start
                Vec3 from = target.position();
                level.sendParticles(ParticleTypes.REVERSE_PORTAL, from.x, from.y + 1, from.z, 20, 0.3, 0.6, 0.3, 0.02);
                target.teleportTo(l.pos.x, l.pos.y, l.pos.z);
                target.setYRot(l.yaw);
                target.setXRot(l.pitch);
                target.setYHeadRot(l.yaw);
                target.setDeltaMovement(Vec3.ZERO);
                target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, LOOP_TICKS + 20, 0, false, false));
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, LOOP_TICKS, 1, false, false));
                JutsuUtil.sound(level, l.pos, SoundEvents.BELL_RESONATE, 0.8f, 0.7f);
            }
        });
        blindEye(p, d);
        return true;
    }
}
