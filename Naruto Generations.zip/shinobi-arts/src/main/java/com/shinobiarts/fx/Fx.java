package com.shinobiarts.fx;

import com.shinobiarts.network.FxPacket;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

/**
 * Jutsu visuals that play out over time (the shapes, not the gameplay): the server says what, where and for how long,
 * and every player nearby draws it (client/fx). Each effect has two points ({@code a}, {@code b}), up to two creatures
 * it follows ({@code entityA}, {@code entityB}, -1 for none), a size, a length in ticks and a random seed so every
 * player sees the same shapes.
 */
public final class Fx {
    public enum Visual {
        GALE_PALM, VACUUM_BLADE, BREAKTHROUGH,
        CHIDORI, BOLT, THUNDER,
        EARTH_RISE,
        HELL_VIEWING, MIND_FOG, MYSTICAL_PALM, VITALITY_BURST,
        WOOD_BIND, FOREST,
        ICE_PRISON, ICE_MIRRORS, ICE_NEEDLE_FLY, ICE_SHATTER,
        IRON_RAIN, IRON_COFFIN, IRON_WORLD,
        BONE_FOREST,
        BARRIER, CHAINS, FIVE_SEAL,
        SHINRA, BANSHO, CHIBAKU, ASH_CLOUD,
        CROWS, WATER_BURST, POISON_MIST, HEAL, CELL_ACTIVATION, RASEN_SPHERE,
        FIRE_DRAGON, WIND_BULLET, SICKLE_WEASEL, KIRIN, BLACK_PANTHER, FALSE_DARKNESS, LIGHTNING_HOUND,
        BEAST_BOMB_CHARGE, BEAST_BOMB, BEAST_BLAST,
        EARTH_SPEAR, EARTH_DRAGON, MUD_BULLET, EARTH_SANDWICH, ROCK_GOLEM, MIST,
        BYAKUGAN_ON, BYAKUGAN_SIGHT, GENTLE_FIST, TRIGRAM_FIELD, PALM_FLURRY, PALM_FINISH, AIR_PALM, PALM_ROTATION,
        LAVA_ROCK, QUICKLIME, LIME_SHELL, MELTING_APPARITION, LASER_HALO, LASER_BEAM, STORM_CLOUD, STORM_BEAM,
        ACID_MIST, STEAM_ARMOR, STEAM_BURST, SCORCH_ORB, SCORCH_ORBIT, SCORCH_LAUNCH,
        FLYING_THUNDER_GOD, TENGAI_METEOR, TENGAI_IMPACT, KAMUI_SWIRL, KAMUI_ARRIVE,
        SMOKE_BOMB, WIRE_BIND, EDO_COFFIN, EDO_SACRIFICE, EDO_DUST, EDO_CRUMBLE, EDO_RELEASE, FIRE_SEA, CHIDORI_HAND, GATES_FLAME, CHAKRA_AURA, YIN_SLASH, YANG_BURST, IZANAGI, IZANAGI_REWRITE, IZANAMI_LOOP, SHARK_JAW;

        private static final Visual[] VALUES = values();

        public static Visual byId(int id) {
            return id >= 0 && id < VALUES.length ? VALUES[id] : null;
        }
    }

    /** How far away players still get sent an effect. */
    private static final double RANGE = 128;

    private Fx() {}

    public static void send(ServerLevel level, Visual type, Vec3 a, Vec3 b, int entityA, int entityB, float size, int ticks) {
        size *= com.shinobiarts.jutsu.JutsuUtil.size();                    // an overcharged jutsu looks as big as it hits
        FxPacket packet = new FxPacket(type.ordinal(), a, b, entityA, entityB, size, ticks, level.getRandom().nextInt());
        ModNetwork.CHANNEL.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(a.x, a.y, a.z, RANGE, level.dimension())),
                packet);
    }

    /** An effect at a spot. */
    public static void at(ServerLevel level, Visual type, Vec3 a, float size, int ticks) {
        send(level, type, a, a, -1, -1, size, ticks);
    }

    /** An effect from one spot to another. */
    public static void line(ServerLevel level, Visual type, Vec3 a, Vec3 b, float size, int ticks) {
        send(level, type, a, b, -1, -1, size, ticks);
    }

    /** An effect on a creature (and optionally a second one), following them. */
    public static void on(ServerLevel level, Visual type, Entity a, Entity b, float size, int ticks) {
        send(level, type, a.position(), b == null ? a.position() : b.position(), a.getId(), b == null ? -1 : b.getId(), size, ticks);
    }
}
