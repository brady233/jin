package com.shinobiarts.entity;

import com.shinobiarts.Config;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.registry.ModEntities;
import com.shinobiarts.registry.ModItems;
import com.shinobiarts.util.Scheduler;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * A wire trap: a near-invisible steel wire strung between two blocks. The first creature that runs into it (not the
 * one who set it) is caught: wound up in the wire and held fast for a few seconds, then the wire's spent. Hitting the
 * wire cuts it (it drops back as an item). Wires that are never sprung rust away after a while.
 */
public class WireTrapEntity extends Entity {
    private static final EntityDataAccessor<Vector3f> END = SynchedEntityData.defineId(WireTrapEntity.class, EntityDataSerializers.VECTOR3);
    @Nullable
    private UUID owner;
    private int age;

    public WireTrapEntity(EntityType<? extends WireTrapEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
    }

    public static WireTrapEntity create(Level level, Vec3 from, Vec3 to, Player owner) {
        WireTrapEntity w = new WireTrapEntity(ModEntities.WIRE_TRAP.get(), level);
        w.setPos(from);
        w.entityData.set(END, new Vector3f((float) (to.x - from.x), (float) (to.y - from.y), (float) (to.z - from.z)));
        w.owner = owner.getUUID();
        return w;
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(END, new Vector3f());
    }

    /** The far end of the wire, relative to this end. */
    public Vec3 span() {
        Vector3f v = entityData.get(END);
        return new Vec3(v.x(), v.y(), v.z());
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (++age > Config.i(Config.WIRE_SECONDS) * 20) {
            discard();
            return;
        }
        if (age % 2 != 0) return;
        Vec3 a = position(), b = a.add(span());
        AABB box = new AABB(a, b).inflate(0.5);
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, box, e -> e.isAlive() && !e.isSpectator())) {
            if (owner != null && owner.equals(e.getUUID())) continue;
            if (e instanceof Player p && p.isCreative()) continue;
            if (!crosses(e.getBoundingBox(), a, b)) continue;
            spring((ServerLevel) level(), e);
            discard();
            return;
        }
    }

    /** Whether the wire from a to b passes through the box. */
    private static boolean crosses(AABB box, Vec3 a, Vec3 b) {
        return box.inflate(0.1).clip(a, b).isPresent() || box.contains(a) || box.contains(b);
    }

    private void spring(ServerLevel level, LivingEntity e) {
        int ticks = Config.i(Config.WIRE_HOLD_SECONDS) * 20;
        e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 10, false, false));
        e.addEffect(new MobEffectInstance(MobEffects.JUMP, ticks, 200, false, false));    // jump boost 200 = can't jump
        e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 1, false, false));
        e.hurt(level.damageSources().generic(), 2.0f);
        Vec3 hold = e.position();
        Scheduler.repeat(0, 1, ticks, i -> {
            if (!e.isAlive()) return;
            e.setDeltaMovement(0, Math.min(0, e.getDeltaMovement().y), 0);
            if (e.position().distanceToSqr(hold) > 0.25) e.teleportTo(hold.x, e.getY(), hold.z);
            e.hurtMarked = true;
        });
        Fx.on(level, Fx.Visual.WIRE_BIND, e, null, Math.max(0.6f, e.getBbWidth()), ticks);
        level.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 1.2f, 1.4f);
        level.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.TRIPWIRE_CLICK_ON, SoundSource.PLAYERS, 1.0f, 0.8f);
        if (e instanceof ServerPlayer sp) {
            sp.displayClientMessage(Component.translatable("message.shinobiarts.wire_caught"), true);
        }
        if (owner != null && level.getPlayerByUUID(owner) instanceof ServerPlayer o) {
            o.displayClientMessage(Component.translatable("message.shinobiarts.wire_sprung", e.getDisplayName()), true);
        }
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved()) return false;
        if (source.getEntity() instanceof Player p) {
            if (!p.isCreative()) spawnAtLocation(new ItemStack(ModItems.WIRE_TRAP.get()), 0.1f);
            level().playSound(null, getX(), getY(), getZ(), SoundEvents.SHEEP_SHEAR, SoundSource.PLAYERS, 1.0f, 1.2f);
            discard();
            return true;
        }
        return false;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double dist) {
        return dist < 64 * 64;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(END, new Vector3f(tag.getFloat("EX"), tag.getFloat("EY"), tag.getFloat("EZ")));
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
        age = tag.getInt("Age");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        Vector3f v = entityData.get(END);
        tag.putFloat("EX", v.x());
        tag.putFloat("EY", v.y());
        tag.putFloat("EZ", v.z());
        if (owner != null) tag.putUUID("Owner", owner);
        tag.putInt("Age", age);
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}
