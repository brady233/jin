"""
Tengai Shinsei's meteor rock (textures/entity/rinnegan/meteor.png, wrapped round the meteor's sphere): dark, charred,
pitted stone, split all over by glowing cracks of molten rock, the way a meteor looks burning in.
Run: python3 tools/make_meteor.py
"""
import math
import os
import random

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures", "entity", "rinnegan", "meteor.png")
W, H = 256, 128


def noise(rng, octaves=5):
    out = np.zeros((H, W))
    for o in range(octaves):
        s = 4 * 2 ** o
        g = rng.random((s // 2 + 1, s + 1))
        g[:, -1] = g[:, 0]                                    # wraps round the sphere
        img = Image.fromarray((g * 255).astype(np.uint8)).resize((W, H), Image.BICUBIC)
        out += np.asarray(img).astype(float) / 255 / (o + 1)
    return out / sum(1 / (o + 1) for o in range(octaves))


def main():
    rng = np.random.default_rng(7)
    n = noise(rng)
    rock = np.zeros((H, W, 3))
    base = np.array([58, 50, 46])
    rock[:] = base * (0.55 + 0.9 * n[..., None])
    # pits and craters
    yy, xx = np.mgrid[0:H, 0:W]
    for _ in range(40):
        cx, cy, r = rng.uniform(0, W), rng.uniform(0, H), rng.uniform(2, 9)
        d = np.hypot(np.minimum(abs(xx - cx), W - abs(xx - cx)), yy - cy)
        rock *= (1 - 0.45 * np.exp(-(d / r) ** 2))[..., None]
        rock += (np.exp(-((d - r) / 1.2) ** 2) * 18)[..., None]
    # glowing cracks of molten rock
    cracks = Image.new("L", (W, H), 0)
    dr = ImageDraw.Draw(cracks)
    rnd = random.Random(3)
    for _ in range(26):
        x, y = rnd.uniform(0, W), rnd.uniform(0, H)
        a = rnd.uniform(0, math.pi * 2)
        pts = [(x, y)]
        for _ in range(rnd.randint(8, 22)):
            a += rnd.uniform(-0.7, 0.7)
            x += math.cos(a) * 3.5
            y += math.sin(a) * 3.5
            pts.append((x % W, y))
            if len(pts) > 1 and abs(pts[-1][0] - pts[-2][0]) > W / 2:
                pts = [pts[-1]]
                continue
            dr.line(pts[-2:], fill=255, width=rnd.choice((1, 2, 2)))
    glow = np.asarray(cracks.filter(ImageFilter.GaussianBlur(2.2))).astype(float) / 255
    core = np.asarray(cracks).astype(float) / 255
    hot = np.array([255, 120, 25])
    white = np.array([255, 220, 140])
    img = rock * (1 - np.clip(glow * 1.6, 0, 1)[..., None]) + hot * np.clip(glow * 1.6, 0, 1)[..., None]
    img = img * (1 - core[..., None]) + white * core[..., None]
    out = np.dstack([np.clip(img, 0, 255), np.full((H, W), 255)])
    Image.fromarray(out.astype(np.uint8), "RGBA").save(OUT)


if __name__ == "__main__":
    main()
