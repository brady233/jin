"""A small glTF (.glb) reader standing in for pygltflib + trimesh in tools/convert_models.py."""
import io, json, struct
from types import SimpleNamespace
import numpy as np
from PIL import Image

CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}

def read(path):
    b = open(path, "rb").read()
    jl = struct.unpack("<I", b[12:16])[0]
    j = json.loads(b[20:20 + jl])
    off = 20 + jl
    bl = struct.unpack("<I", b[off:off + 4])[0]
    blob = b[off + 8: off + 8 + bl]
    return j, blob

def accessor(j, blob, i):
    a = j["accessors"][i]; bv = j["bufferViews"][a["bufferView"]]
    dt = np.dtype(CT[a["componentType"]]).newbyteorder("<"); n = NC[a["type"]]
    start = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = bv.get("byteStride", 0) or dt.itemsize * n
    raw = np.frombuffer(blob, dtype=np.uint8, count=stride * (a["count"] - 1) + dt.itemsize * n, offset=start)
    out = np.lib.stride_tricks.as_strided(raw, shape=(a["count"], dt.itemsize * n), strides=(stride, 1)).copy()
    return out.view(dt).reshape(a["count"], n).astype(np.float64 if dt.kind == "f" else np.int64)

def node_matrix(n):
    if "matrix" in n:
        return np.array(n["matrix"], dtype=float).reshape(4, 4).T
    t = np.array(n.get("translation", [0, 0, 0])); s = np.array(n.get("scale", [1, 1, 1]))
    x, y, z, w = n.get("rotation", [0, 0, 0, 1])
    r = np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                  [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                  [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
    m = np.eye(4); m[:3, :3] = r * s; m[:3, 3] = t
    return m

def load_parts(path, parts):
    j, blob = read(path)
    images = []
    for im in j.get("images", []):
        bv = j["bufferViews"][im["bufferView"]]
        images.append(Image.open(io.BytesIO(blob[bv.get("byteOffset", 0): bv.get("byteOffset", 0) + bv["byteLength"]])).convert("RGBA"))
    mat_images = {}
    for mi, m in enumerate(j.get("materials", [])):
        pbr = m.get("pbrMetallicRoughness", {})
        if "baseColorTexture" in pbr:
            mat_images[mi] = images[j["textures"][pbr["baseColorTexture"]["index"]]["source"]]
        else:
            mat_images[mi] = Image.new("RGBA", (16, 16), tuple(int(255 * c) for c in pbr.get("baseColorFactor", [1, 1, 1, 1])))
    out = []
    def walk(ni, parent):
        n = j["nodes"][ni]; m = parent @ node_matrix(n)
        if "mesh" in n:
            mesh = j["meshes"][n["mesh"]]
            name = mesh.get("name", n.get("name"))
            if parts is None or name in parts:
                for p in mesh["primitives"]:
                    pos = accessor(j, blob, p["attributes"]["POSITION"])
                    nrm = accessor(j, blob, p["attributes"]["NORMAL"])
                    uv = accessor(j, blob, p["attributes"]["TEXCOORD_0"])
                    idx = accessor(j, blob, p["indices"]).reshape(-1, 3)
                    v = (np.c_[pos, np.ones(len(pos))] @ m.T)[:, :3]
                    nm = np.linalg.inv(m[:3, :3]).T
                    nn = nrm @ nm.T; nn /= np.linalg.norm(nn, axis=1, keepdims=True) + 1e-12
                    uv2 = np.column_stack([uv[:, 0], 1.0 - uv[:, 1]])   # trimesh-style bottom-up V
                    out.append((name, SimpleNamespace(vertices=v, faces=idx, vertex_normals=nn, visual=SimpleNamespace(uv=uv2)),
                                p.get("material", 0)))
        for c in n.get("children", []):
            walk(c, m)
    for root in j["scenes"][j.get("scene", 0)]["nodes"]:
        walk(root, np.eye(4))
    return out, mat_images
