"""
Draws all the eye art (Sharingan, Mangekyou patterns, Byakugan, Rinnegan) in a sharp anime style: an upturned almond
eye with a thin inked upper lid that flicks out past the outer corner, a light lower lid, a big shaded iris tucked
under the lid, and a thick angled brow that slopes down toward the nose:
  textures/models/eyes/sharingan_<1-4>.png  - eyes drawn on the face of a player/clone with the Sharingan on
                                              (2048x1024 = the 64x32 armor layout x32; transparent except the eyes)
                                              1-3 = tomoe, 4 = Mangekyou (Itachi's pattern)
  textures/models/eyes/sharingan_4_<sasuke|obito|eternal>.png - the other Mangekyou patterns, using the irises in
                                              tools/source_art/sharingan (from the asset pack)
  textures/gui/sharingan_flash_<1-4>.png    - the big pair of eyes that flashes across the screen
  textures/gui/sharingan_flash_4_<pattern>.png
  textures/item/sharingan.png               - Sharingan helmet icon
  textures/item/sharingan_eye.png           - a taken Sharingan eye
  textures/gui/sharingan_icon_<1-4>.png     - the round iris shown in the HUD's eye slot (and byakugan_icon.png)
  textures/models/eyes/byakugan.png, textures/gui/byakugan_flash.png   - the Byakugan on the face / in the flash
  textures/models/eyes/rinnegan.png, textures/gui/rinnegan_flash.png   - the Rinnegan (iris from the user's picture)
Eyes sit where most skins have them (Steve's eye row). Run: python3 tools/make_sharingan.py
"""
import math
import os

from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts")
EYES = os.path.join(ASSETS, "textures", "models", "eyes")
ARMOR = os.path.join(ASSETS, "textures", "models", "armor")
GUI = os.path.join(ASSETS, "textures", "gui")
ITEM = os.path.join(ASSETS, "textures", "item")
IRIS_ART = os.path.join(HERE, "source_art", "sharingan")
# Mangekyou patterns drawn from irises (Itachi's from the user's picture; the others from the asset pack)
DESIGN_IRIS = {"sasuke": "mangekyosharingan_sasuke.png", "obito": "mangekyosharingan_obito.png",
               "eternal": "mangekyosharingan_eterna.png"}
RINNEGAN_IRIS = "rinnegan.png"   # redrawn from the user's reference picture


ITACHI_IRIS = "mangekyosharingan_itachi.png"


def shift_eyes(img, dx=14):
    """The eyes sit 14 texture pixels closer together than drawn (the face's centre is at x=384 of 2048)."""
    out = Image.new("RGBA", img.size, (0, 0, 0, 0))
    out.alpha_composite(img.crop((0, 0, 384, img.height)), (dx, 0))
    out.alpha_composite(img.crop((384, 0, img.width, img.height)), (384 - dx, 0))
    return out


def iris_image(design):
    return Image.open(os.path.join(IRIS_ART, DESIGN_IRIS[design])).convert("RGBA") if design in DESIGN_IRIS else None

SCALE = 32              # texture pixels per skin pixel in the face textures
SS = 3                  # supersampling
FACE_U, FACE_V = 8, 8   # the head's front face in the 64x32 armor layout

RED, RED_DARK, RED_LIGHT = (205, 16, 24), (105, 4, 10), (240, 60, 60)
INK, WHITE, WHITE_SHADE = (12, 6, 8), (250, 248, 246), (214, 208, 210)
BROW = (35, 31, 42)
CARUNCLE = (226, 140, 150)
BYAKU_IRIS, BYAKU_RIM, BYAKU_VEIN = (240, 238, 250), (196, 188, 226), (126, 106, 150)


def bezier(p0, p1, p2, n=24):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]) for t in (i / n for i in range(n + 1))]


def bezier3(p0, p1, p2, p3, n=28):
    out = []
    for i in range(n + 1):
        t = i / n
        a, b, c, d = (1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t * t, t ** 3
        out.append((a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0], a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]))
    return out


def eye_shape(cx, cy, w, h, inner_left):
    """An upturned almond: the outer corner sits higher and comes to a sharp point, the upper lid rises steeply from
    the inner corner and runs almost straight to the outer one, the lower lid is a shallow curve."""
    s = -1 if inner_left else 1      # +1: inner corner on the right (the viewer's left eye)
    inner = (cx + s * w / 2, cy + h * 0.22)
    outer = (cx - s * w / 2, cy - h * 0.10)
    upper = bezier3(inner, (cx + s * w * 0.36, cy - h * 0.66), (cx - s * w * 0.18, cy - h * 0.86), outer)
    lower = bezier3(outer, (cx - s * w * 0.22, cy + h * 0.62), (cx + s * w * 0.22, cy + h * 0.70), inner)
    return upper, lower, inner, outer


def draw_brow(d, cx, cy, w, h, inner_left, alpha=255):
    """A thick, blade-like brow: low and heavy just above the inner corner, rising in a nearly straight line and
    tapering to a sharp point past the outer corner, so it slopes down toward the nose."""
    s = -1 if inner_left else 1
    o = h * 0.10                                         # sits close above the eye
    bottom = bezier3((cx + s * w * 0.46, cy - h * 0.66 + o), (cx + s * w * 0.15, cy - h * 0.86 + o), (cx - s * w * 0.30, cy - h * 1.06 + o),
                     (cx - s * w * 0.68, cy - h * 1.24 + o), 18)
    top = bezier3((cx - s * w * 0.68, cy - h * 1.24 + o), (cx - s * w * 0.32, cy - h * 1.30 + o), (cx + s * w * 0.10, cy - h * 1.22 + o),
                  (cx + s * w * 0.42, cy - h * 1.04 + o), 18)
    d.polygon(bottom + top + [(cx + s * w * 0.47, cy - h * 0.86 + o)], fill=BROW + (alpha,))


def byakugan_veins(d, cx, cy, w, h, inner_left, width_scale=1.0):
    """The veins that stand out around the eyes while the Byakugan is on: toward the temple and the bridge of the nose."""
    s = -1 if inner_left else 1
    lw = max(1, round(h * 0.07 * width_scale))
    outer = (cx - s * w * 0.52, cy - h * 0.08)
    inner = (cx + s * w * 0.52, cy + h * 0.15)
    for dx, dy in ((-0.22, -0.55), (-0.30, -0.10), (-0.20, 0.38)):
        mid = (outer[0] + s * dx * w * 0.5, outer[1] + dy * h * 0.5)
        end = (outer[0] + s * dx * w, outer[1] + dy * h)
        d.line([outer, mid, end], fill=BYAKU_VEIN + (210,), width=lw)
    for dx, dy in ((0.05, -0.45),):
        d.line([inner, (inner[0] + s * dx * w, inner[1] + dy * h)], fill=BYAKU_VEIN + (170,), width=lw)


def draw_byakugan_iris(d, cx, cy, r):
    """Pale and pupil-less, with a soft lavender rim and a faint inner ring."""
    for i in range(14, 0, -1):
        t = i / 14
        col = tuple(round(BYAKU_RIM[k] + (BYAKU_IRIS[k] - BYAKU_RIM[k]) * (1 - t) ** 0.7) for k in range(3))
        d.ellipse([cx - r * t, cy - r * t, cx + r * t, cy + r * t], fill=col)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(150, 138, 186), width=max(1, round(r * 0.07)))
    rr = r * 0.55
    d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], outline=(214, 206, 238), width=max(1, round(r * 0.04)))


def draw_iris(d, cx, cy, r, stage):
    if stage == "byakugan":
        draw_byakugan_iris(d, cx, cy, r)
        return
    for i in range(14, 0, -1):  # radial gradient: dark rim to bright middle
        t = i / 14
        col = tuple(round(RED_DARK[k] + (RED[k] - RED_DARK[k]) * (1 - t) ** 0.6) for k in range(3))
        d.ellipse([cx - r * t, cy - r * t, cx + r * t, cy + r * t], fill=col)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=INK, width=max(2, round(r * 0.11)))
    if stage == 4:
        draw_mangekyou(d, cx, cy, r)
    else:
        tr = r * 0.58
        d.ellipse([cx - tr, cy - tr, cx + tr, cy + tr], outline=(55, 0, 4), width=max(1, round(r * 0.05)))
        for k in range(stage):
            a = math.radians(-90 + k * (360 / stage if stage > 1 else 0))
            dot = r * 0.16
            for sidx in range(12):  # the comma's tail, sweeping along the ring
                b = a + math.radians(6 + sidx * 5)
                wdt = dot * (1 - sidx / 12) ** 1.2
                px, py = cx + tr * math.cos(b), cy + tr * math.sin(b)
                d.ellipse([px - wdt, py - wdt, px + wdt, py + wdt], fill=INK)
            tx, ty = cx + tr * math.cos(a), cy + tr * math.sin(a)
            d.ellipse([tx - dot, ty - dot, tx + dot, ty + dot], fill=INK)
        p = r * 0.2
        d.ellipse([cx - p, cy - p, cx + p, cy + p], fill=INK)


def draw_mangekyou(d, cx, cy, r):
    """A three-bladed pinwheel (in the style of the Mangekyou) around a black center."""
    for k in range(3):
        a0 = math.radians(-90 + k * 120)
        pts = []
        for i in range(17):      # leading edge: center -> rim, curving
            t = i / 16
            ang = a0 + math.radians(75) * t ** 0.8
            rad = r * (0.22 + 0.72 * t)
            pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
        for i in range(17):      # trailing edge: rim -> center, curving the other way
            t = 1 - i / 16
            ang = a0 + math.radians(75) * t ** 0.8 + math.radians(48) * (1 - t) ** 0.5 * (t > 0)
            rad = r * (0.22 + 0.62 * t)
            pts.append((cx + rad * math.cos(ang + math.radians(30) * (1 - t)), cy + rad * math.sin(ang + math.radians(30) * (1 - t))))
        d.polygon(pts, fill=INK)
    c = r * 0.3
    d.ellipse([cx - c, cy - c, cx + c, cy + c], fill=INK)
    dot = r * 0.08
    d.ellipse([cx - dot, cy - dot, cx + dot, cy + dot], fill=RED)


def paste_iris(layer, cx, cy, r, iris):
    """A Mangekyou pattern from the asset pack, scaled into the iris circle, with the same little shine."""
    size = max(2, round(r * 2))
    pic = iris.resize((size, size), Image.LANCZOS)
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse([0, 0, size - 1, size - 1], fill=255)
    alpha = Image.composite(pic.split()[3], Image.new("L", (size, size), 0), mask)
    layer.paste(pic, (round(cx - size / 2), round(cy - size / 2)), alpha)


def draw_eye(img, cx, cy, w, h, inner_left, stage, lids=1.0, iris=None):
    """One eye onto an RGBA image (all sizes in pixels). stage: 1-4 (Sharingan), "byakugan", or 4 with an iris picture."""
    d = ImageDraw.Draw(img)
    upper, lower, inner, outer = eye_shape(cx, cy, w, h, inner_left)
    shape = upper + lower
    s = -1 if inner_left else 1
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).polygon(shape, fill=255)
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    ld.polygon(shape, fill=WHITE + (255,))
    # a big iris, its top tucked under the upper lid
    ix, iy, ir = cx - s * w * 0.02, cy + h * 0.08, h * 0.63
    if iris is not None:
        paste_iris(layer, ix, iy, ir, iris)
    else:
        draw_iris(ld, ix, iy, ir, stage)
    # the shadow the upper lid casts across the white and the iris
    shadow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    lid_low = [(x, y + h * 0.22) for x, y in upper]
    ImageDraw.Draw(shadow).polygon(upper + lid_low[::-1], fill=(40, 20, 40, 55))
    layer.alpha_composite(shadow)
    hl = h * 0.075                                       # a small highlight
    ImageDraw.Draw(layer).ellipse([ix + s * ir * 0.38 - hl, iy - ir * 0.30 - hl, ix + s * ir * 0.38 + hl, iy - ir * 0.30 + hl],
                                  fill=(255, 255, 255, 235))
    img.paste(layer, (0, 0), Image.composite(layer.split()[3], Image.new("L", img.size, 0), mask))
    # pink inner corner
    d.polygon([inner, (inner[0] - s * w * 0.09, inner[1] - h * 0.18), (inner[0] - s * w * 0.11, inner[1] + h * 0.06)],
              fill=CARUNCLE + (255,))
    # thin inked upper lid, thickest toward the outer corner, flicking out past it like eyeliner
    thick = h * 0.13 * lids
    band = []
    for i, (x, y) in enumerate(upper):
        t = i / (len(upper) - 1)                         # 0 at the inner corner, 1 at the outer corner
        band.append((x, y - thick * (0.25 + 0.75 * math.sin(math.pi / 2 * min(1.0, t * 1.15)))))
    wing = (outer[0] - s * w * 0.15, outer[1] - h * 0.14)
    d.polygon(upper + [wing] + band[::-1], fill=INK + (255,))
    # light lower lid along the outer two thirds
    n = len(lower)
    d.line(lower[: int(n * 0.68)], fill=INK + (215,), width=max(1, round(h * 0.05 * lids)))
    return upper


def face_texture(stage, design=None, iris=None):
    unit = SCALE * SS
    img = Image.new("RGBA", (64 * unit, 32 * unit), (0, 0, 0, 0))
    iris = iris if iris is not None else iris_image(design)
    d = ImageDraw.Draw(img)
    for fx, inner_left in ((2.0, False), (6.0, True)):   # viewer's left eye has its inner corner on the right
        cx, cy = (FACE_U + fx) * unit, (FACE_V + 4.5) * unit
        w, h = 2.4 * unit, 1.15 * unit
        if stage == "byakugan":
            byakugan_veins(d, cx, cy, w, h, inner_left)
        draw_eye(img, cx, cy, w, h, inner_left, stage, iris=iris)
        draw_brow(d, cx, cy, w, h, inner_left)
    return img.resize((64 * SCALE, 32 * SCALE), Image.LANCZOS)


def flash_texture(stage, design=None, iris=None):
    w, h = 512 * SS, 160 * SS
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    iris = iris if iris is not None else iris_image(design)
    for cx, inner_left in ((w * 0.27, False), (w * 0.73, True)):
        ew, eh = w * 0.36, h * 0.40
        cy = h * 0.66
        if stage == "byakugan":
            byakugan_veins(d, cx, cy, ew, eh, inner_left, 0.6)
        upper = draw_eye(img, cx, cy, ew, eh, inner_left, stage, lids=1.15, iris=iris)
        crease = [(x, y - eh * 0.26) for x, y in upper[6:-4]]          # a soft crease above the lid
        d.line(crease, fill=INK + (150,), width=round(eh * 0.035))
        draw_brow(d, cx, cy, ew, eh, inner_left, 240)
    return img.resize((512, 160), Image.LANCZOS)


def helmet_icon():
    s = 32 * 8
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    draw_eye(img, s / 2, s * 0.54, s * 0.92, s * 0.44, False, 3, lids=1.1)
    return img.resize((32, 32), Image.LANCZOS)


def eye_item_icon():
    s = 32 * 8
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    r = s * 0.42
    cx, cy = s / 2, s / 2
    for i in range(16, 0, -1):  # eyeball: white with soft shading
        t = i / 16
        v = round(196 + 58 * (1 - t))
        d.ellipse([cx - r * t + s * 0.03 * (1 - t), cy - r * t - s * 0.03 * (1 - t),
                   cx + r * t + s * 0.03 * (1 - t), cy + r * t - s * 0.03 * (1 - t)], fill=(v, v - 6, v - 6, 255))
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(120, 60, 60, 255), width=round(s * 0.025))
    for ang in (200, 250, 300, 20, 110):  # a few veins
        a = math.radians(ang)
        d.line([(cx + r * 0.95 * math.cos(a), cy + r * 0.95 * math.sin(a)),
                (cx + r * 0.62 * math.cos(a + 0.2), cy + r * 0.62 * math.sin(a + 0.2))], fill=(200, 60, 60, 255), width=round(s * 0.012))
    draw_iris(d, cx - s * 0.02, cy + s * 0.01, r * 0.55, 3)
    return img.resize((32, 32), Image.LANCZOS)


def hud_icon(stage):
    """Just the iris, filling the icon: what the HUD's eye slot shows."""
    s = 64 * 8
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    draw_iris(d, s / 2, s / 2, s * 0.46, stage)
    return img.resize((64, 64), Image.LANCZOS)


def byakugan_icon():
    """A pale, pupil-less Byakugan iris with veins around it."""
    s = 64 * 8
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = cy = s / 2
    r = s * 0.46
    for i in range(14, 0, -1):
        t = i / 14
        v = (round(200 + 50 * (1 - t)), round(196 + 50 * (1 - t)), round(226 + 28 * (1 - t)))
        d.ellipse([cx - r * t, cy - r * t, cx + r * t, cy + r * t], fill=v)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(120, 110, 160), width=round(r * 0.08))
    for k in range(3):
        rr = r * (0.3 + k * 0.18)
        d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], outline=(205, 198, 232), width=round(r * 0.03))
    for k in range(10):  # veins pushing in from the rim
        a = math.radians(k * 36 + 10)
        d.line([(cx + r * 0.98 * math.cos(a), cy + r * 0.98 * math.sin(a)),
                (cx + r * 0.7 * math.cos(a + 0.12), cy + r * 0.7 * math.sin(a + 0.12))], fill=(150, 130, 190), width=round(r * 0.04))
    return img.resize((64, 64), Image.LANCZOS)


def main():
    for folder in (EYES, GUI):
        os.makedirs(folder, exist_ok=True)
    itachi = Image.open(os.path.join(IRIS_ART, ITACHI_IRIS)).convert("RGBA")
    for stage in range(1, 5):
        iris = itachi if stage == 4 else None
        shift_eyes(face_texture(stage, iris=iris)).save(os.path.join(EYES, f"sharingan_{stage}.png"))
        flash_texture(stage, iris=iris).save(os.path.join(GUI, f"sharingan_flash_{stage}.png"))
    for design in DESIGN_IRIS:
        shift_eyes(face_texture(4, design)).save(os.path.join(EYES, f"sharingan_4_{design}.png"))
        flash_texture(4, design).save(os.path.join(GUI, f"sharingan_flash_4_{design}.png"))
    helmet_icon().save(os.path.join(ITEM, "sharingan.png"))
    eye_item_icon().save(os.path.join(ITEM, "sharingan_eye.png"))
    for stage in range(1, 4):
        hud_icon(stage).save(os.path.join(GUI, f"sharingan_icon_{stage}.png"))
    icon = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
    paste_iris(icon, 256, 256, 512 * 0.46, itachi)
    icon.resize((64, 64), Image.LANCZOS).save(os.path.join(GUI, "sharingan_icon_4.png"))
    byakugan_icon().save(os.path.join(GUI, "byakugan_icon.png"))
    shift_eyes(face_texture("byakugan")).save(os.path.join(EYES, "byakugan.png"))
    flash_texture("byakugan").save(os.path.join(GUI, "byakugan_flash.png"))
    rinnegan = Image.open(os.path.join(IRIS_ART, RINNEGAN_IRIS)).convert("RGBA")
    shift_eyes(face_texture(4, iris=rinnegan)).save(os.path.join(EYES, "rinnegan.png"))
    flash_texture(4, iris=rinnegan).save(os.path.join(GUI, "rinnegan_flash.png"))
    print("sharingan art written")


if __name__ == "__main__":
    main()
